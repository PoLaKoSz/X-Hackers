<div id="clan" class="horizontal_center">
	<div class="fLeft">Klán név:</div>
	<div class="fLeft"><?php echo $this->clanInfo['clan_name']; ?></div>
		<div class="clear"></div>
	<div class="fLeft">Alapítás dátuma:</div>
	<div class="fLeft"><?php  echo $this->clanInfo['clan_start_date']; ?></div>
		<div class="clear"></div>
	<div class="fLeft">Tagok</div>
	<div class="fLeft">
						<?php
								while ( $row = $this->clanMembers->fetch_assoc() )
								{
									echo '<a href="#"><img src="images/message.png"></a> <a href="#">' . $row["clan_member_name"] . '</a><br>';
								}
						?>
 	</div>
		<div class="clear"></div>
		<a href="#">Kilépés a(z) <?php echo $this->clanInfo['clan_name']; ?> nevű klánból</a>
</div>