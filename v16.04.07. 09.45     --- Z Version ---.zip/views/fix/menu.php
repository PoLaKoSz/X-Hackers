<?php
	$exp_bar = $_SESSION['current_exp']*100/$_SESSION['full_exp'];
	$curr_exp = $_SESSION['current_exp']."/".$_SESSION['full_exp'];
?>
<html>
	<head>
		<title>X-Hackers</title>
		
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />
		
		<link rel="stylesheet" type="text/css" href="./css/default_design.css">
		<link rel="stylesheet" type="text/css" href="./css/min_830px_style.css">
		<link rel="stylesheet" type="text/css" href="./css/mobile.css">
		<link rel="stylesheet" type="text/css" href="./css/nice-table.css">
		<style> /* EXP-BAR -hoz*/
			@-webkit-keyframes example {
				from {width: 0px;}
				to {width: <?php echo $exp_bar; ?>%;}
			}
			
			@keyframes example {
				from {width: 0px;}
				to {width: <?php echo $exp_bar; ?>%;}
			}
		</style>

		<script src="./js/jquery-2.2.0.min.js"></script>
	</head>
	
	<body onresize="resizeEvent()">
		<div id="exp_bar" alt="Jelenlegi EXP-d: <?php echo $curr_exp; ?>" title="Jelenlegi EXP-d: <?php echo $curr_exp; ?>">
			<div class="expCol fLeft"></div>
			<div class="expCol fLeft"></div>
			<div class="expCol fLeft"></div>
			<div class="expCol fLeft"></div>
			<div class="expCol fLeft"></div>
			<div class="expCol fLeft"></div>
			<div class="expCol fLeft"></div>
			<div class="expCol fLeft"></div>
			<div class="expCol fLeft"></div>
			<div class="clear"></div>

			<div class="exp_line"></div>
		</div>
		
		<div id="menu" class="horizontal_center borderedBox">
			<div id="menuList" class="horizontal_center">
				<a href="index.php?url=home"><div class="menuItem">Kezdõlap</div></a>
				<div class="menuItem dropdown" onClick="findParentNode('body', this);">
					Áttekintés
						<div class="dropdown-content borderedBox">
							<a href="index.php?url=overview/softwares"><p>Szoftverek</p></a>
							<a href="index.php?url=overview/hardwares"><p>Hardverek</p></a>
							<a href="index.php?url=overview/skills"><p>Képességek</p></a>
						</div>
				</div>
				<div class="menuItem dropdown">
					Munkák
						<div class="dropdown-content borderedBox">
							<a href="index.php?url=work/legal"><p>Legális Munka</p></a>
							<a href="index.php?url=work/missions"><p>Küldetések</p></a>
						</div>
				</div>
				<div class="menuItem dropdown">
					Klán
						<div class="dropdown-content borderedBox">
							<a href="index.php?url=clan/overview"><p>Áttekintés</p></a>
							<a href="index.php?url=clan/pc"><p>Klán számítógép</p></a>
							<a href="index.php?url=clan/missions"><p>Klán küldetések</p></a>
						</div>
				</div>
				<div class="menuItem dropdown new_message">
					Üzenetek
						<div class="dropdown-content borderedBox">
							<a href="index.php?url=messages/received"><p>Beérkező</p></a>
							<a href="index.php?url=messages/sent"><p>Elküldött</p></a>
						</div>
				</div>
				<a href="index.php?url=profile"><div class="menuItem">Profil (+)</div></a>
				<a href="index.php?url=options"><div class="menuItem">Beállítások</div></a>
				<a href="index.php?url=logout"><div class="menuItem">Kilépés</div></a>
				
				<div class="clear"></div>
			</div>
			<div class="clear"></div>
				
			<div id="mobile-menu"></div>
		</div>
		
		<div id="admin_button" class="borderedBox"><a href="index.php?url=admin/index">A</a>
		
	</div>
		
	<div id="content" class="horizontal_center borderedBox">