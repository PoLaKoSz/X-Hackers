			<!-- /views/fix/footer.php -->
			</div>
			<p id="screen">
			<script>
			/*
				// http://stackoverflow.com/a/10795029 cm => px			px => cm
				var width = $(window).width();
				var height = $(window).height();
				$("#screen").append(width+"px X "+height+"px");

				$(window).resize(function() {
					width = $(window).width();
					height = $(window).height();
					
					$("#screen").html(width+"px X "+height+"px");
				});*/
			</script>
			
			
			
		</div>
		
		<div id="footer" class="horizontal_center">
			&copy 2015-2016. Minden jog fenntartva. Dizájnolta és szkriptelte: <a href="https://www.facebook.com/polakosztamas" target="_blank">PoLáKoSz Tom</a>
		</div>
		
		
		<script src="./js/default_functions.js"></script>
		<script src="./js/mobile_menu.js"></script>

		<script src="./js/nice-table.js"></script>

		<script src="./js/getParent.js"></script>
		<script type="text/javascript">
			function resizeEvent() {
				var time = new Date();
				console.log(time.getHours()+":"+time.getMinutes()+":"+time.getSeconds()+":"+time.getMilliseconds() + " ---- "+window.innerWidth+"px X "+window.innerHeight+"px");
			}
		</script>
	</body>
</html>