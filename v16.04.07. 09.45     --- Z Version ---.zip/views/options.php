<form action="index.php?url=options" method="POST" class="content_center horizontal_center small-table margin_bottom">
	<div class="cell-6 fLeft">
		Jelenlegi jelszó:
	</div>
	<div class="cell-6 fLeft">
		<input type="password" name="curr_PW">
	</div>
	 <div class="cell-6 fLeft">
		Új jelszó:
	</div>
	<div class="cell-6 fLeft">
		<input type="password" name="newPW1">
	</div>
	<div class="cell-6 fLeft">
		Új jelszó ismét:
	</div>
	<div class="cell-6 fLeft">
		<input type="password" name="newPW2">
	</div>
	<input type="submit" name="changePassword" value="Mentés">
</form>


<form action="#" method="POST" class="content_center horizontal_center small-table margin_bottom">
	 <div class="cell-6 fLeft">
		Fiók felfüggesztése (<a href="#">?</a>)
	</div>
	<div class="cell-6 fLeft">
		<input type="checkbox" name="acc_pause">
	</div>
	<div class="cell-6 fLeft">
		Jelenlegi jelszó:
	</div>
	<div class="cell-6 fLeft">
		<input type="password" name="curr_PW">
	</div>
	<input type="submit" name="account_holiday" value="Fiók felfüggesztése">
</form>


<form action="#" method="POST" class="content_center horizontal_center small-table">
	<div class="cell-6 fLeft">
		Fiók törlése (<a href="#">?</a>)
	</div>
	<div class="cell-6 fLeft">
		<input type="checkbox" name="acc_delete">
	</div>
	<div class="cell-6 fLeft">
		Jelenlegi jelszó:
	</div>
	<div class="cell-6 fLeft">
		<input type="password" name="curr_PW">
	</div>
	<input type="submit" name="account_delete" value="Fiók törlése">
</form>