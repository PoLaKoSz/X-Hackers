<?php

class Missions
{
	public function __construct()
	{
		require_once 'views/clan/missions.php';
	}
}