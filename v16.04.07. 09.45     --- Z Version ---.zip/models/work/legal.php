<?php

class LegalDB extends DataBase
{
	public function __construct() {}

	public function listJobs()
	{
		$this->connect();

			$result = $this->query("CALL listJobs(" . $_SESSION['account_id'] . ", " . $_SESSION['current_level'] . ")");

		$this->close();

		return $result;
	}
}