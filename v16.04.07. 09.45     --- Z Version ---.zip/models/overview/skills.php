<?php

class SkillsDB extends DataBase
{
	public function __construct() {}

	public function getSkills()
	{
		$this->connect();
			$result = $this->query(
			"
			SELECT
				skill_table.skill_id,skill_table.skill_tooltip,skill_table.skill_description, account_skills.skill_level AS SK_curr_level,skill_table.skill_level AS SK_next_level, skill_table.price,
				skill_table.requirement_skill_level, skill_table.changing, skill_table.changing_value
			FROM skill_table
			LEFT JOIN account_skills ON skill_table.skill_id = account_skills.skill_id AND skill_table.skill_level = account_skills.skill_level + 1
			LEFT JOIN skill_list ON skill_table.skill_id = skill_list.skill_id
			WHERE account_skills.account_id = " . $_SESSION['account_id'] . " OR account_skills.account_id IS NULL AND skill_table.requirement_skill <= (SELECT COALESCE(MAX(skill_id), 0) FROM account_skills)
			GROUP BY skill_list.order
			");

		$this->close();

		return $result;
	}
	
	public function getOneSkill( $skill_id, $skill_level )
	{
		$this->connect();

			$skill_id = $this->escape( $skill_id );
			$skill_level = $this->escape( $skill_level );

			$result = $this->query(
			"
			SELECT
				skill_table.skill_id,skill_table.skill_description, skill_table.skill_level, skill_table.price
			FROM skill_table
			LEFT JOIN account_skills ON skill_table.skill_id = account_skills.skill_id AND skill_table.skill_level = account_skills.skill_level
			WHERE account_skills.account_id = " . $_SESSION['account_id'] . " AND skill_table.skill_id = " . $skill_id . " AND skill_table.skill_level = " . $skill_level . " LIMIT 1
			");

		$this->close();

		return $result;
	}

	public function getSkillPrice( $skill_id )
	{
		$this->connect();
		
			$result = $this->query(
			"
			SELECT
				price
			FROM skill_table
			LEFT JOIN account_skills ON skill_table.skill_id = account_skills.skill_id
			WHERE skill_table.skill_id = " . $skill_id . " AND skill_table.skill_level = COALESCE(account_skills.skill_level + 1, 1)
			LIMIT 1
			")->fetch_assoc();

		$this->close();

		return $result;
	}

	public function upgradeSkill( $skill_id )
	{
		$this->connect();
			$result = $this->query("CALL updateSkill(" . $_SESSION['account_id'] . ", " . $skill_id . ");");

		$this->close();

		return $result;
	}

	public function getLanguages()
	{
		$this->connect();
		
			$result = $this->query(
			"
			SELECT
				language_table.language_id,language_table.language_description, account_languages.language_level AS SK_curr_level,language_table.language_level AS SK_next_level, language_table.price,
				language_table.requirement_language_level, language_table.changing, language_table.changing_value
			FROM language_table
			LEFT JOIN account_languages ON language_table.language_id = account_languages.language_id AND language_table.language_level = account_languages.language_level + 1
			LEFT JOIN language_list ON language_table.language_id = language_list.language_id
			WHERE account_languages.account_id = " . $_SESSION['account_id'] . " OR account_languages.account_id IS NULL
			GROUP BY language_list.order
			");

		$this->close();

		return $result;
	}

	public function getLanguagePrice( $language_id )
	{
		$this->connect();
		
			$result = $this->query(
			"
			SELECT
				price
			FROM language_table
			LEFT JOIN account_languages ON language_table.language_id = account_languages.language_id
			WHERE language_table.language_id = " . $language_id . " AND language_table.language_level = COALESCE(account_languages.language_level + 1, 1)
			LIMIT 1
			")->fetch_assoc();

		$this->close();

		return $result;
	}

	public function upgradeLanguage( $language_id )
	{
		$this->connect();
			$result = $this->query("CALL updateLanguage(" . $_SESSION['account_id'] . ", " . $language_id . ");");

		$this->close();

		return $result;
	}
}