<?php

class Options
{
	public function __construct()
	{
		require_once 'models/options.php';

		if ( isset( $_POST['changePassword'] ) && strcmp( $_POST['newPW1'], $_POST['newPW2'] ) === 0 )
		{
			require_once 'models/options.php';
			$db = new OptionsDB( $_POST['curr_PW'] );
			$db->changePassword( $_POST['newPW1']);
		}
		else if ( isset( $_POST['account_holiday'] ) )
		{
			//echo "fiók felfüggesztése";
		}
		else if ( isset( $_POST['account_delete'] ) )
		{
			//echo "fiók törlése";
		}

		require_once 'views/options.php';
	}
}