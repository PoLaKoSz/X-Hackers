<?php
	session_start();

	require_once '../database.php';
	require_once 'skill_list.php';

	$db = new SkillListDB;
	$result = $db->updateOneRow( $_POST['skill_id'], $_POST['skill_level'], $_POST['skill_tooltip'], $_POST['skill_description'], $_POST['price'], $_POST['requirement_skill'], $_POST['requirement_skill_level'], $_POST['changing'], $_POST['changing_value'] );
	
	echo json_encode($result);