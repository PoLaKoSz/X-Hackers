<h3>Munkák</h3>
<div class="nice-table">
	<?php
		while ( $row = $job_result->fetch_assoc() )
		{
			/*if ( $row['requirement_skill_level'] == -2)    // <--- ezt atirni arra, amivel jelolni fogom a befejezett munkakat
			{
				$imgORUpgrade = "<img src='images/tick.png' class='status'>";
			}
			else
			{
				$imgORUpgrade = '<input type="submit" ' . $disable . ' name="' . $row['skill_id'] . '" value="' . formatInt( $row['price'] ) .'Ft">';
			}*/
			
			echo '
			<form action="index.php?url=work/legal" method="POST">
				<div id="container" data-id="' . $row['job_id'] . '">
					<input type="text" hidden name="skill_id" value="' . $row['job_id'] . '">
						<div class="m_top_title"><div class="title">' . $row['employer'] . '</div></div>
					<div class="row-1">( <a class="tooltip"> ? </a>) | ' . $row['employer'] . '</div>
					<div class="content">' . $row['description'] . '</div>
						<div class="m_details"><p>' . $row['money'] . ' Ft</p><p><img src="images/EXP.png">' . $row['exp'] . '</p><p><img src="images/TIME.png">' . $row['time'] . '</p></div>
					<div class="row-2">
						<span class="money">' . formatInt( $row['money'] ) . ' Ft</span>
						<p class="exp"><img src="images/EXP.png">' . $row['exp'] . '</p>
						<span class="time"><img src="images/TIME.png">' . $row['time'] . '</span>
						<input type="submit" value="Elfogad"> <img class="delete" src="images/delete.png"></div>
				</div>
			</form>
			';
		}
	?>
</div>

<!--
	10 feladatot general (account_id, job_id, megrendelo, tooltip, money, time, EXP, generated_time
	job_finish TABLE (job_id, deadline)

	profilban lesz egy opcio, hogy munkak 5 percenkenti automatikus frissitese

	SQL procedure:
		torli az 5 percnel regebbi generated_time-mal rendelkezo accounthoz tartozo kuldiket
		lekerdezi a jobs_finish tablaval osszefesult jobs tabla tartalmat account_id-vel szurve
		ha ez kevesebb, mint 10, akkor generalnia kell

	( ? ) -ben lesz a feladat leirasa: pl.: segits egy baratodnak weblapot kesziteni
	( ? ) Cegnev       20.000Ft     TIME 10perc    EXP 500   Elfogad (button) IMG kuka (feladat torlese)
				ha mar visszaszamol (dolgozik, akkor legyen egy kuka jel a munka megszakitasahoz (elkezdi a munkat, feluton abbahagyja, meg benne marad a listaban, de visszaszamol, mert addig el a munka szamara