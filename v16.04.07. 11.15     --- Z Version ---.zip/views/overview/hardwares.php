<h3>Hardverek</h3>
<div class="nice-table">
	<?php
		while ( $row = $hardware_result->fetch_assoc() )
		{
			if ( $_SESSION['current_money'] < $row['price'] )
			{
				$disable = 'disable';
			}

			if ( $row['requirement_hardware_level'] == -2)
			{
				$imgORUpgrade = "<img src='images/tick.png' class='status'>";
			}
			else
			{
				$imgORUpgrade = '<input type="submit" ' . $disable . ' value="' . formatInt( $row['price'] ) .'Ft">';
			}
			
			echo '
			<form action="index.php?url=overview/hardwares" method="POST">
				<div id="container" data-id="' . $row['hardware_id'] . '">
					<input type="text" hidden name="hardware_id" value="' . $row['hardware_id'] . '">
					<div class="m_top_title"><div class="title">' . $row['SK_curr_level'] . ' -> ' . $row['SK_next_level'] . ' | ' . $row['hardware_description'] . '</div>' . $imgORUpgrade . '</div>
					<div class="row-1">( <a class="tooltip"> ? </a>) | ' . $row['SK_curr_level'] . ' -> ' . $row['SK_next_level'] . ' | ' . $row['hardware_description'] . '</div>
					<div class="content">' . $row['hardware_tooltip'] . '</div>
					<div class="m_details"><p>30.000 Ft</p><p>592 EXP</p><p>84 sec</p></div>
					<div class="row-2"><img src="images/' . $row['changing'] . '.png" alt="' . $row['changing'] . '" title="' . $row['changing'] . '">' . $row['changing_value'] . ' ' . $imgORUpgrade . '</div>
				</div>
			</form>
			';
		}
	?>
</div>