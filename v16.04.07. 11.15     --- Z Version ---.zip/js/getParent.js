/*
function findParentNode(parentName, childObj) {
    var testObj = childObj.parentNode;
    var count = 1;

    while(testObj.getAttribute('name') != parentName) {
        console.log('My name ID ' + testObj.getAttribute('id'));
        testObj = testObj.parentNode;
        count++;
    }
    console.log('Finally found ' + testObj.getAttribute('id') + ' after going up ' + count + ' level(s) through the DOM tree');
}
*/

function findParentNode(parentName, childObj) {
    var testObj = childObj.parentNode;
    var count = 1;

    while(testObj.getAttribute('name') != parentName) {

        var clockTime = time > 12 ? 'PM' : 'AM' ;
        
        console.log(clockTime);

        console.log('My name ID ' + testObj.getAttribute('id'));
        testObj = testObj.parentNode;
        count++;
    }
    console.log('Finally found ' + testObj.getAttribute('id') + ' after going up ' + count + ' level(s) through the DOM tree');
}