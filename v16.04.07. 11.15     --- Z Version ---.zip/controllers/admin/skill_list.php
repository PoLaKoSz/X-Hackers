<?php

class Skill_List
{
	public function __construct ()
	{
		require_once 'models/admin/skill_list.php';
		$db = new SkillListDB;

		$result = $db->getSkillsList( $_POST['skill_id'], $_POST['skill_level'], $_POST['price'], $_POST['requirement_skill'], $_POST['requirement_skill_level'], $_POST['changing'], $_POST['changing_value'], $_POST['order_by'] );		//	 nem progbléma, ha null-t adunk neki

		require_once 'views/admin/skill_list.php';
	}
}
