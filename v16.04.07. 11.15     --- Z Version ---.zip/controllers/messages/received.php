<?php

class Received
{
	public function __construct ()
	{
		$messages = new MessagesDB;
		$result = $messages->getReceived();

		#teszt üzenet küldés
		//$messages->sendMessage(12, date());

		require_once 'views/messages/received.php';								// továbbirányítás a megfelelő oldalra
	}
}