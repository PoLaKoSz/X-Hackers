<?php

class Softwares
{
	public function __construct ()
	{
		require_once 'models/overview/softwares.php';
			$softwares = new SoftwaresDB;

			if ( isset( $_POST['software_id'] ) )
			{
				if ( $this->checkSoftware( $softwares, $_POST['software_id'] ) )
				{
					$this->updateSoftware( $softwares, $_POST['software_id'] );
				}
			}

			$software_result = $softwares->getSoftwares();
		require_once 'views/overview/softwares.php';								// továbbirányítás a megfelelő oldalra
	}

	protected function checkSoftware( $softwares, $software_id )
	{
		if ( $result = $softwares->getSoftwarePrice( $software_id ) )
		{
			if ( $result['price'] < $_SESSION['current_money'] )
			{
				return true;
			}
		}
		return false;
	}

	protected function updateSoftware( $softwares, $software_id )
	{
		$softwares->upgradeSoftware( $software_id );
	}
}