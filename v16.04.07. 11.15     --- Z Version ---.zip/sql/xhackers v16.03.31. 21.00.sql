CREATE DATABASE IF NOT EXISTS `xhackers` DEFAULT CHARACTER SET utf8 COLLATE utf8_hungarian_ci;
USE `xhackers`;

DELIMITER $$
DROP PROCEDURE IF EXISTS `listJobs`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `listJobs`(IN `IN_accound_id` INT UNSIGNED, IN `current_level` INT UNSIGNED)
    NO SQL
    DETERMINISTIC
BEGIN
	DECLARE result int;
    
	DELETE FROM jobs WHERE account_id = IN_accound_id AND generated_time < DATE_SUB(now(), INTERVAL 5 MINUTE);
    
    SET result = (SELECT COUNT(job_id) FROM jobs WHERE account_id = IN_accound_id);
    
    WHILE (result < 10 ) DO
    	INSERT INTO jobs VALUES (1,NULL,(SELECT ROUND((RAND() * (58)))),(SELECT ROUND((RAND() * (10)))),(SELECT ROUND((RAND() * (999))+999)),(SELECT DATE_ADD(NOW(), INTERVAL ROUND((RAND() * (3600))+60) SECOND)),(SELECT ROUND((RAND() * (current_level * 500))+current_level * 300)),NOW());
        
        SET result = result + 1;
    END WHILE;
    
    SELECT jobs.job_id, job_employers.employer, job_descriptions.description, jobs.money, jobs.time, jobs.exp FROM jobs LEFT JOIN job_employers ON jobs.employer = job_employers.id LEFT JOIN job_descriptions ON jobs.description_id = job_descriptions.id WHERE jobs.account_id = 1;
END$$

DROP PROCEDURE IF EXISTS `updateHardware`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `updateHardware`(IN `acc_id` INT UNSIGNED, IN `IN_hardware_id` INT UNSIGNED)
    NO SQL
BEGIN
	DECLARE result INT;
	SET result = (SELECT hardware_level FROM account_hardwares WHERE hardware_id = IN_hardware_id);

	CASE
		WHEN result > 0 THEN
			UPDATE account_hardwares SET hardware_level = hardware_level + 1 WHERE account_id = acc_id AND hardware_id = IN_hardware_id;
		WHEN result = -2 THEN
			SET result = 2;
		ELSE
			INSERT INTO account_hardwares VALUES (1, IN_hardware_id, 1);
	END CASE;
END$$

DROP PROCEDURE IF EXISTS `updateLanguage`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `updateLanguage`(IN `acc_id` INT UNSIGNED, IN `IN_language_id` INT UNSIGNED)
    NO SQL
BEGIN
	DECLARE result INT;
	SET result = (SELECT language_level FROM account_languages WHERE language_id = IN_language_id);
	SELECT result;

	CASE
		WHEN result > 0 THEN
			UPDATE account_languages SET language_level = language_level + 1 WHERE account_id = acc_id AND language_id = IN_language_id;
		WHEN result = -2 THEN
			SET result = 2;
		ELSE
			INSERT INTO account_languages VALUES (1, IN_language_id, 1);
	END CASE;
END$$

DROP PROCEDURE IF EXISTS `updateSkill`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `updateSkill`(IN `acc_id` MEDIUMINT UNSIGNED, IN `IN_skill_id` TINYINT UNSIGNED)
    NO SQL
    DETERMINISTIC
BEGIN
	DECLARE result INT;
	SET result = (SELECT skill_level FROM account_skills WHERE skill_id = IN_skill_id);

	CASE
		WHEN result > 0 THEN
			UPDATE account_skills SET skill_level = skill_level + 1 WHERE account_id = acc_id AND skill_id = IN_skill_id;
		WHEN result = -2 THEN
			SET result = 2;
		ELSE
			INSERT INTO account_skills VALUES (1, IN_skill_id, 1);
	END CASE;
END$$

DROP PROCEDURE IF EXISTS `updateSoftware`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `updateSoftware`(IN `acc_id` MEDIUMINT UNSIGNED, IN `IN_software_id` TINYINT UNSIGNED)
    NO SQL
    DETERMINISTIC
BEGIN
	DECLARE result INT;
	SET result = (SELECT software_level FROM account_softwares WHERE software_id = IN_software_id);

	CASE
		WHEN result > 0 THEN
			UPDATE account_softwares SET software_level = software_level + 1 WHERE account_id = acc_id AND software_id = IN_software_id;
		WHEN result = -2 THEN
			SET result = 2;
		ELSE
			INSERT INTO account_softwares VALUES (1, IN_software_id, 1);
	END CASE;
END$$

DROP FUNCTION IF EXISTS `updatePassword`$$
CREATE DEFINER=`root`@`localhost` FUNCTION `updatePassword`(`account_id` MEDIUMINT UNSIGNED, `current_password` VARCHAR(20) CHARSET utf8mb4, `new_password` VARCHAR(20) CHARSET utf8mb4) RETURNS tinyint(1)
    NO SQL
BEGIN
	DECLARE result INT;
	SET result = (SELECT COUNT(id) FROM accounts WHERE id = account_id AND password = PASSWORD(current_password) LIMIT 1);

	IF result = 1 THEN
		UPDATE accounts SET password = PASSWORD(new_password) WHERE id = account_id LIMIT 1;
        RETURN TRUE;
	ELSE
		RETURN FALSE;
	END IF;
END$$

DELIMITER ;

DROP TABLE IF EXISTS `accounts`;
CREATE TABLE IF NOT EXISTS `accounts` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(30) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `password` varchar(45) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT 'MD5 kódolás',
  `email` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `status` tinyint(3) unsigned NOT NULL COMMENT '0 = aktiválásra várva | 1 = aktív | 2 = bann',
  `current_level` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `current_exp` int(10) unsigned DEFAULT NULL,
  `current_money` mediumint(8) unsigned NOT NULL,
  `computer_id` smallint(5) unsigned DEFAULT NULL COMMENT 'aktiv PC-jenek az ID-je: computers.id kerul ide',
  `reg_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci AUTO_INCREMENT=11 ;

INSERT INTO `accounts` VALUES
(1, 'PoLáKoSz', '*4ACFE3202A5FF5CF467898FC58AAB1D615029441', 'polakosz@freemail.hu', 1, 2, 3450, 25000, NULL, '2016-01-23 00:00:00'),
(2, 'TesztElek', '*4ACFE3202A5FF5CF467898FC58AAB1D615029441', 'polakosz@freemail.hu', 1, 1, 9345, 0, NULL, '2016-03-09 00:00:00'),
(3, 'Exodus', '*4ACFE3202A5FF5CF467898FC58AAB1D615029441', 'asdk', 1, 1, 0, 0, NULL, '2016-03-10 00:00:00'),
(4, 'admin', '*4ACFE3202A5FF5CF467898FC58AAB1D615029441', 'info@xhackers.hu', 0, 1, 0, 0, NULL, '2015-01-01 00:00:00'),
(5, 'karcsi501', '*4ACFE3202A5FF5CF467898FC58AAB1D615029441', 'info@xhackers.hu', 0, 1, 0, 0, NULL, '2015-01-01 00:00:00'),
(6, 'Mikee012', '*4ACFE3202A5FF5CF467898FC58AAB1D615029441', 'info@xhackers.hu', 0, 1, 0, 0, NULL, '2015-01-01 00:00:00'),
(7, 'boldogan', '*4ACFE3202A5FF5CF467898FC58AAB1D615029441', 'info@xhackers.hu', 0, 1, 0, 0, NULL, '2015-01-01 00:00:00'),
(8, 'jovics2012', '*4ACFE3202A5FF5CF467898FC58AAB1D615029441', 'info@xhackers.hu', 0, 1, 0, 0, NULL, '2015-01-01 00:00:00'),
(9, 'dohanyos81', '*4ACFE3202A5FF5CF467898FC58AAB1D615029441', 'info@xhackers.hu', 0, 1, 0, 0, NULL, '2015-01-01 00:00:00'),
(10, 'avermedia', '*4ACFE3202A5FF5CF467898FC58AAB1D615029441', 'info@xhackers.hu', 0, 1, 0, 0, NULL, '2015-01-01 00:00:00');

DROP TABLE IF EXISTS `account_computers`;
CREATE TABLE IF NOT EXISTS `account_computers` (
  `account_id` smallint(5) unsigned NOT NULL,
  `computer_id` smallint(5) unsigned NOT NULL COMMENT 'rakni kell ra UNIQUE dolgot'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

DROP TABLE IF EXISTS `account_hardwares`;
CREATE TABLE IF NOT EXISTS `account_hardwares` (
  `account_id` smallint(5) unsigned NOT NULL,
  `hardware_id` tinyint(3) unsigned NOT NULL,
  `hardware_level` tinyint(3) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

INSERT INTO `account_hardwares` VALUES
(1, 1, 10),
(1, 2, 10),
(1, 3, 5),
(1, 0, 1),
(1, 4, 3),
(1, 5, 1),
(1, 6, 1);

DROP TABLE IF EXISTS `account_languages`;
CREATE TABLE IF NOT EXISTS `account_languages` (
  `account_id` smallint(10) unsigned NOT NULL,
  `language_id` tinyint(3) unsigned NOT NULL,
  `language_level` tinyint(3) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

DROP TABLE IF EXISTS `account_skills`;
CREATE TABLE IF NOT EXISTS `account_skills` (
  `account_id` smallint(5) unsigned NOT NULL,
  `skill_id` tinyint(3) unsigned NOT NULL,
  `skill_level` tinyint(3) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

INSERT INTO `account_skills` VALUES
(1, 1, 10),
(1, 2, 3);

DROP TABLE IF EXISTS `account_softwares`;
CREATE TABLE IF NOT EXISTS `account_softwares` (
  `account_id` smallint(5) unsigned NOT NULL,
  `software_id` tinyint(3) unsigned NOT NULL,
  `software_level` tinyint(3) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

INSERT INTO `account_softwares` VALUES
(1, 1, 10),
(1, 2, 10),
(1, 3, 3),
(1, 0, 1),
(1, 4, 2);

DROP TABLE IF EXISTS `clans`;
CREATE TABLE IF NOT EXISTS `clans` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `clan_name` varchar(20) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `clan_start_date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci AUTO_INCREMENT=3 ;

INSERT INTO `clans` VALUES
(1, '[Admin]Team', '2016-03-10'),
(2, 'PlayerTeam', '2016-03-10');

DROP TABLE IF EXISTS `clan_members`;
CREATE TABLE IF NOT EXISTS `clan_members` (
  `clan_id` smallint(5) unsigned NOT NULL,
  `account_id` smallint(5) unsigned NOT NULL,
  `joined_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

INSERT INTO `clan_members` VALUES
(1, 1, '2016-03-10'),
(1, 2, '2017-04-04'),
(1, 3, '2016-03-10');

DROP TABLE IF EXISTS `computers`;
CREATE TABLE IF NOT EXISTS `computers` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `vga` tinyint(3) unsigned NOT NULL,
  `vga_level` tinyint(3) unsigned NOT NULL,
  `cpu` tinyint(3) unsigned NOT NULL,
  `cpu_level` tinyint(3) unsigned NOT NULL,
  `ram` tinyint(3) unsigned NOT NULL,
  `ram_level` tinyint(3) unsigned NOT NULL,
  `ssd` tinyint(3) unsigned NOT NULL,
  `ssd_level` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci AUTO_INCREMENT=1 ;

DROP TABLE IF EXISTS `computer_table`;
CREATE TABLE IF NOT EXISTS `computer_table` (
  `hardware_id` tinyint(3) unsigned NOT NULL,
  `hardware_level` tinyint(3) unsigned NOT NULL,
  `changing` varchar(4) COLLATE utf8_hungarian_ci NOT NULL,
  `changing_value` tinyint(3) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

DROP TABLE IF EXISTS `hacker_name`;
CREATE TABLE IF NOT EXISTS `hacker_name` (
  `acc_id` smallint(5) unsigned NOT NULL,
  `hacker_name` varchar(20) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `change_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

INSERT INTO `hacker_name` VALUES
(1, '[Admin] Mr. PoLáKoSz', '2016-03-10 00:00:00'),
(1, '[Mr] Admin[KA]', '2016-03-29 05:27:46'),
(1, 'asdasd', '2016-03-29 20:29:17'),
(1, 'adfgsdfgsd', '2016-03-29 20:29:24'),
(1, 'NOW()', '2016-03-29 20:29:41'),
(1, 'KJHASdhdskjgkjskjdfd', '2016-03-29 20:30:08'),
(1, 'Pista', '2016-03-31 19:53:47'),
(1, 'Jóska', '2016-03-31 20:10:44');

DROP TABLE IF EXISTS `hardware_list`;
CREATE TABLE IF NOT EXISTS `hardware_list` (
  `order` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `hardware_id` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`order`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci AUTO_INCREMENT=16 ;

INSERT INTO `hardware_list` VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 14),
(5, 4),
(6, 5),
(7, 13),
(8, 6),
(9, 7),
(10, 8),
(11, 9),
(12, 10),
(13, 11),
(14, 12),
(15, 15);

DROP TABLE IF EXISTS `hardware_table`;
CREATE TABLE IF NOT EXISTS `hardware_table` (
  `hardware_id` tinyint(3) unsigned NOT NULL,
  `hardware_level` tinyint(3) unsigned NOT NULL COMMENT 'Jelen pillanatban, ha az érték 11, akkor fullos ez a hardware!!',
  `hardware_tooltip` varchar(2500) COLLATE utf8_hungarian_ci NOT NULL COMMENT 'Ez jelenik meg a ( ? ) jelnél',
  `hardware_description` varchar(255) COLLATE utf8_hungarian_ci NOT NULL,
  `price` mediumint(8) unsigned NOT NULL COMMENT 'Ft',
  `requirement_hardware` tinyint(3) unsigned NOT NULL COMMENT 'hardware_id-t kell megadni, 0 = nem szükséges hozzá követelmény (= requirement_hardware_level-nek is 0-nak kell lennie)',
  `requirement_hardware_level` tinyint(3) NOT NULL,
  `changing` varchar(4) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL COMMENT 'EXP - TIME - OFFense - DEFFense',
  `changing_value` tinyint(3) NOT NULL COMMENT 'időnél pl mínusz érték, mert csökken a feladat teljesítésének ideje'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

INSERT INTO `hardware_table` VALUES
(1, 1, '#1 | HTML --- ', 'HTML --- ', 1000, 0, 0, 'TIME', -1),
(1, 2, '#2 | HTML --- ', 'HTML --- ', 2000, 0, 0, 'TIME', -2),
(1, 3, '#3 | HTML --- ', 'HTML --- ', 3000, 0, 0, 'TIME', -3),
(1, 4, '#4 | HTML --- ', 'HTML --- ', 4000, 0, 0, 'TIME', -4),
(1, 5, '#5 | HTML --- ', 'HTML --- ', 5000, 0, 0, 'TIME', -5),
(1, 6, '#6 | HTML --- ', 'HTML --- ', 6000, 0, 0, 'TIME', -6),
(1, 7, '#7 | HTML --- ', 'HTML --- ', 7000, 0, 0, 'TIME', -7),
(1, 8, '#8 | HTML --- ', 'HTML --- ', 8000, 0, 0, 'TIME', -8),
(1, 9, '#9 | HTML --- ', 'HTML --- ', 9000, 0, 0, 'TIME', -9),
(1, 10, '#10 | HTML --- ', 'HTML --- ', 10000, 0, 0, 'TIME', -10),
(1, 11, '#11 | HTML --- ', 'HTML --- ', 1, 0, -2, 'TIME', -11),
(2, 1, '#1 | CSS --- ', 'CSS --- ', 1000, 1, 0, 'TIME', -1),
(2, 2, '#2 | CSS --- ', 'CSS --- ', 2000, 1, 0, 'TIME', -2),
(2, 3, '#3 | CSS --- ', 'CSS --- ', 3000, 1, 0, 'TIME', -3),
(2, 4, '#4 | CSS --- ', 'CSS --- ', 4000, 1, 0, 'TIME', -4),
(2, 5, '#5 | CSS --- ', 'CSS --- ', 5000, 1, 0, 'TIME', -5),
(2, 6, '#6 | CSS --- ', 'CSS --- ', 6000, 1, 0, 'TIME', -6),
(2, 7, '#7 | CSS --- ', 'CSS --- ', 7000, 1, 0, 'TIME', -7),
(2, 8, '#8 | CSS --- ', 'CSS --- ', 8000, 1, 0, 'TIME', -8),
(2, 9, '#9 | CSS --- ', 'CSS --- ', 9000, 1, 0, 'TIME', -9),
(2, 10, '#10 | CSS --- ', 'CSS --- ', 10000, 1, 0, 'TIME', -10),
(2, 11, '#11 | CSS --- ', 'CSS --- ', 1, 1, -2, 'TIME', -11),
(3, 1, '#1 | JavaScript --- ', 'JavaScript --- ', 1000, 2, 0, 'TIME', -1),
(3, 2, '#2 | JavaScript --- ', 'JavaScript --- ', 2000, 2, 0, 'TIME', -2),
(3, 3, '#3 | JavaScript --- ', 'JavaScript --- ', 3000, 2, 0, 'TIME', -3),
(3, 4, '#4 | JavaScript --- ', 'JavaScript --- ', 4000, 2, 0, 'TIME', -4),
(3, 5, '#5 | JavaScript --- ', 'JavaScript --- ', 5000, 2, 0, 'TIME', -5),
(3, 6, '#6 | JavaScript --- ', 'JavaScript --- ', 6000, 2, 0, 'TIME', -6),
(3, 7, '#7 | JavaScript --- ', 'JavaScript --- ', 7000, 2, 0, 'TIME', -7),
(3, 8, '#8 | JavaScript --- ', 'JavaScript --- ', 8000, 2, 0, 'TIME', -8),
(3, 9, '#9 | JavaScript --- ', 'JavaScript --- ', 9000, 2, 0, 'TIME', -9),
(3, 10, '#10 | JavaScript --- ', 'JavaScript --- ', 10000, 2, 0, 'TIME', -10),
(3, 11, '#11 | JavaScript --- ', 'JavaScript --- ', 1, 2, -2, 'TIME', -11),
(4, 1, '#1 | PHP --- ', 'PHP --- ', 1000, 3, 0, 'TIME', -1),
(4, 2, '#2 | PHP --- ', 'PHP --- ', 2000, 3, 0, 'TIME', -2),
(4, 3, '#3 | PHP --- ', 'PHP --- ', 3000, 3, 0, 'TIME', -3),
(4, 4, '#4 | PHP --- ', 'PHP --- ', 4000, 3, 0, 'TIME', -4),
(4, 5, '#5 | PHP --- ', 'PHP --- ', 5000, 3, 0, 'TIME', -5),
(4, 6, '#6 | PHP --- ', 'PHP --- ', 6000, 3, 0, 'TIME', -6),
(4, 7, '#7 | PHP --- ', 'PHP --- ', 7000, 3, 0, 'TIME', -7),
(4, 8, '#8 | PHP --- ', 'PHP --- ', 8000, 3, 0, 'TIME', -8),
(4, 9, '#9 | PHP --- ', 'PHP --- ', 9000, 3, 0, 'TIME', -9),
(4, 10, '#10 | PHP --- ', 'PHP --- ', 10000, 3, 0, 'TIME', -10),
(4, 11, '#11 | PHP --- ', 'PHP --- ', 1, 3, -2, 'TIME', -11),
(5, 1, '#1 | SQL --- ', 'SQL --- ', 1000, 4, 0, 'TIME', -1),
(5, 2, '#2 | SQL --- ', 'SQL --- ', 2000, 4, 0, 'TIME', -2),
(5, 3, '#3 | SQL --- ', 'SQL --- ', 3000, 4, 0, 'TIME', -3),
(5, 4, '#4 | SQL --- ', 'SQL --- ', 5000, 4, 0, 'TIME', -4),
(5, 5, '#5 | SQL --- ', 'SQL --- ', 5000, 4, 0, 'TIME', -5),
(5, 6, '#6 | SQL --- ', 'SQL --- ', 6000, 4, 0, 'TIME', -6),
(5, 7, '#7 | SQL --- ', 'SQL --- ', 7000, 4, 0, 'TIME', -7),
(5, 8, '#8 | SQL --- ', 'SQL --- ', 8000, 4, 0, 'TIME', -8),
(5, 9, '#9 | SQL --- ', 'SQL --- ', 9000, 4, 0, 'TIME', -9),
(5, 10, '#10 | SQL --- ', 'SQL --- ', 10000, 4, 0, 'TIME', -10),
(5, 11, '#11 | SQL --- ', 'SQL --- ', 1, 4, -2, 'TIME', -11),
(6, 1, '#1 | C# --- ', 'C# --- ', 1000, 5, 0, 'TIME', -1),
(6, 2, '#2 | C# --- ', 'C# --- ', 2000, 5, 0, 'TIME', -2),
(6, 3, '#3 | C# --- ', 'C# --- ', 3000, 5, 0, 'TIME', -3),
(6, 4, '#4 | C# --- ', 'C# --- ', 5000, 5, 0, 'TIME', -4),
(6, 5, '#5 | C# --- ', 'C# --- ', 5000, 5, 0, 'TIME', -5),
(6, 6, '#6 | C# --- ', 'C# --- ', 6000, 5, 0, 'TIME', -6),
(6, 7, '#7 | C# --- ', 'C# --- ', 7000, 5, 0, 'TIME', -7),
(6, 8, '#8 | C# --- ', 'C# --- ', 8000, 5, 0, 'TIME', -8),
(6, 9, '#9 | C# --- ', 'C# --- ', 9000, 5, 0, 'TIME', -9),
(6, 10, '#10 | C# --- ', 'C# --- ', 10000, 5, 0, 'TIME', -10),
(6, 11, '#11 | C# --- ', 'C# --- ', 1, 5, -2, 'TIME', -11),
(7, 1, '#1 | Java --- ', 'Java --- ', 1000, 6, 0, 'TIME', -1),
(7, 2, '#2 | Java --- ', 'Java --- ', 2000, 6, 0, 'TIME', -2),
(7, 3, '#3 | Java --- ', 'Java --- ', 3000, 6, 0, 'TIME', -3),
(7, 4, '#4 | Java --- ', 'Java --- ', 5000, 6, 0, 'TIME', -4),
(7, 5, '#5 | Java --- ', 'Java --- ', 5000, 6, 0, 'TIME', -5),
(7, 6, '#6 | Java --- ', 'Java --- ', 6000, 6, 0, 'TIME', -6),
(7, 7, '#7 | Java --- ', 'Java --- ', 7000, 6, 0, 'TIME', -7),
(7, 8, '#8 | Java --- ', 'Java --- ', 8000, 6, 0, 'TIME', -8),
(7, 9, '#9 | Java --- ', 'Java --- ', 9000, 6, 0, 'TIME', -9),
(7, 10, '#10 | Java --- ', 'Java --- ', 10000, 6, 0, 'TIME', -10),
(7, 11, '#11 | Java --- ', 'Java --- ', 1, 6, -2, 'TIME', -11),
(8, 1, '#1 | Assembly --- ', 'Assembly --- ', 1000, 6, 0, 'TIME', -1),
(8, 2, '#2 | Assembly --- ', 'Assembly --- ', 2000, 6, 0, 'TIME', -2),
(8, 3, '#3 | Assembly --- ', 'Assembly --- ', 3000, 6, 0, 'TIME', -3),
(8, 4, '#4 | Assembly --- ', 'Assembly --- ', 5000, 6, 0, 'TIME', -4),
(8, 5, '#5 | Assembly --- ', 'Assembly --- ', 5000, 6, 0, 'TIME', -5),
(8, 6, '#6 | Assembly --- ', 'Assembly --- ', 6000, 6, 0, 'TIME', -6),
(8, 7, '#7 | Assembly --- ', 'Assembly --- ', 7000, 6, 0, 'TIME', -7),
(8, 8, '#8 | Assembly --- ', 'Assembly --- ', 8000, 6, 0, 'TIME', -8),
(8, 9, '#9 | Assembly --- ', 'Assembly --- ', 9000, 6, 0, 'TIME', -9),
(8, 10, '#10 | Assembly --- ', 'Assembly --- ', 10000, 6, 0, 'TIME', -10),
(8, 11, '#11 | Assembly --- ', 'Assembly --- ', 1, 6, -2, 'TIME', -11),
(9, 1, '#1 | 2-es számrendszer --- ', '2-es számrendszer --- ', 1000, 8, 0, 'TIME', -1),
(9, 2, '#2 | 2-es számrendszer --- ', '2-es számrendszer --- ', 2000, 8, 0, 'TIME', -2),
(9, 3, '#3 | 2-es számrendszer --- ', '2-es számrendszer --- ', 3000, 8, 0, 'TIME', -3),
(9, 4, '#4 | 2-es számrendszer --- ', '2-es számrendszer --- ', 5000, 8, 0, 'TIME', -4),
(9, 5, '#5 | 2-es számrendszer --- ', '2-es számrendszer --- ', 5000, 8, 0, 'TIME', -5),
(9, 6, '#6 | 2-es számrendszer --- ', '2-es számrendszer --- ', 6000, 8, 0, 'TIME', -6),
(9, 7, '#7 | 2-es számrendszer --- ', '2-es számrendszer --- ', 7000, 8, 0, 'TIME', -7),
(9, 8, '#8 | 2-es számrendszer --- ', '2-es számrendszer --- ', 8000, 8, 0, 'TIME', -8),
(9, 9, '#9 | 2-es számrendszer --- ', '2-es számrendszer --- ', 9000, 8, 0, 'TIME', -9),
(9, 10, '#10 | 2-es számrendszer --- ', '2-es számrendszer --- ', 10000, 8, 0, 'TIME', -10),
(9, 11, '#11 | 2-es számrendszer --- ', '2-es számrendszer --- ', 1, 8, -2, 'TIME', -11),
(10, 1, '#1 | 16-os számrendszer --- ', '16-os számrendszer --- ', 1000, 6, 0, 'TIME', -1),
(10, 2, '#2 | 16-os számrendszer --- ', '16-os számrendszer --- ', 2000, 6, 0, 'TIME', -2),
(10, 3, '#3 | 16-os számrendszer --- ', '16-os számrendszer --- ', 3000, 6, 0, 'TIME', -3),
(10, 4, '#4 | 16-os számrendszer --- ', '16-os számrendszer --- ', 5000, 6, 0, 'TIME', -4),
(10, 5, '#5 | 16-os számrendszer --- ', '16-os számrendszer --- ', 5000, 6, 0, 'TIME', -5),
(10, 6, '#6 | 16-os számrendszer --- ', '16-os számrendszer --- ', 6000, 6, 0, 'TIME', -6),
(10, 7, '#7 | 16-os számrendszer --- ', '16-os számrendszer --- ', 7000, 6, 0, 'TIME', -7),
(10, 8, '#8 | 16-os számrendszer --- ', '16-os számrendszer --- ', 8000, 6, 0, 'TIME', -8),
(10, 9, '#9 | 16-os számrendszer --- ', '16-os számrendszer --- ', 9000, 6, 0, 'TIME', -9),
(10, 10, '#10 | 16-os számrendszer --- ', '16-os számrendszer --- ', 10000, 6, 0, 'TIME', -10),
(10, 11, '#11 | 16-os számrendszer --- ', '16-os számrendszer --- ', 1, 6, -2, 'TIME', -11),
(11, 1, '#1 | PowerShell --- ', 'PowerShell --- ', 1000, 10, 0, 'TIME', -1),
(11, 2, '#2 | PowerShell --- ', 'PowerShell --- ', 2000, 10, 0, 'TIME', -2),
(11, 3, '#3 | PowerShell --- ', 'PowerShell --- ', 3000, 10, 0, 'TIME', -3),
(11, 4, '#4 | PowerShell --- ', 'PowerShell --- ', 5000, 10, 0, 'TIME', -4),
(11, 5, '#5 | PowerShell --- ', 'PowerShell --- ', 5000, 10, 0, 'TIME', -5),
(11, 6, '#6 | PowerShell --- ', 'PowerShell --- ', 6000, 10, 0, 'TIME', -6),
(11, 7, '#7 | PowerShell --- ', 'PowerShell --- ', 7000, 10, 0, 'TIME', -7),
(11, 8, '#8 | PowerShell --- ', 'PowerShell --- ', 8000, 10, 0, 'TIME', -8),
(11, 9, '#9 | PowerShell --- ', 'PowerShell --- ', 9000, 10, 0, 'TIME', -9),
(11, 10, '#10 | PowerShell --- ', 'PowerShell --- ', 10000, 10, 0, 'TIME', -10),
(11, 11, '#11 | PowerShell --- ', 'PowerShell --- ', 1, 10, -2, 'TIME', -11),
(12, 1, '#1 | Python --- ', 'Python --- ', 1000, 11, 0, 'TIME', -1),
(12, 2, '#2 | Python --- ', 'Python --- ', 2000, 11, 0, 'TIME', -2),
(12, 3, '#3 | Python --- ', 'Python --- ', 3000, 11, 0, 'TIME', -3),
(12, 4, '#4 | Python --- ', 'Python --- ', 5000, 11, 0, 'TIME', -4),
(12, 5, '#5 | Python --- ', 'Python --- ', 5000, 11, 0, 'TIME', -5),
(12, 6, '#6 | Python --- ', 'Python --- ', 6000, 11, 0, 'TIME', -6),
(12, 7, '#7 | Python --- ', 'Python --- ', 7000, 11, 0, 'TIME', -7),
(12, 8, '#8 | Python --- ', 'Python --- ', 8000, 11, 0, 'TIME', -8),
(12, 9, '#9 | Python --- ', 'Python --- ', 9000, 11, 0, 'TIME', -9),
(12, 10, '#10 | Python --- ', 'Python --- ', 10000, 11, 0, 'TIME', -10),
(12, 11, '#11 | Python --- ', 'Python --- ', 1, 11, -2, 'TIME', -11),
(13, 1, '#1 | Ajax --- ', 'Ajax --- ', 1000, 12, 0, 'TIME', -1),
(13, 2, '#2 | Ajax --- ', 'Ajax --- ', 2000, 12, 0, 'TIME', -2),
(13, 3, '#3 | Ajax --- ', 'Ajax --- ', 3000, 12, 0, 'TIME', -3),
(13, 4, '#4 | Ajax --- ', 'Ajax --- ', 5000, 12, 0, 'TIME', -4),
(13, 5, '#5 | Ajax --- ', 'Ajax --- ', 5000, 12, 0, 'TIME', -5),
(13, 6, '#6 | Ajax --- ', 'Ajax --- ', 6000, 12, 0, 'TIME', -6),
(13, 7, '#7 | Ajax --- ', 'Ajax --- ', 7000, 12, 0, 'TIME', -7),
(13, 8, '#8 | Ajax --- ', 'Ajax --- ', 8000, 12, 0, 'TIME', -8),
(13, 9, '#9 | Ajax --- ', 'Ajax --- ', 9000, 12, 0, 'TIME', -9),
(13, 10, '#10 | Ajax --- ', 'Ajax --- ', 10000, 12, 0, 'TIME', -10),
(13, 11, '#11 | Ajax --- ', 'Ajax --- ', 1, 12, -2, 'TIME', -11),
(14, 1, '#1 | jQuery --- ', 'jQuery --- ', 1000, 13, 0, 'TIME', -1),
(14, 2, '#2 | jQuery --- ', 'jQuery --- ', 2000, 13, 0, 'TIME', -2),
(14, 3, '#3 | jQuery --- ', 'jQuery --- ', 3000, 13, 0, 'TIME', -3),
(14, 4, '#4 | jQuery --- ', 'jQuery --- ', 5000, 13, 0, 'TIME', -4),
(14, 5, '#5 | jQuery --- ', 'jQuery --- ', 5000, 13, 0, 'TIME', -5),
(14, 6, '#6 | jQuery --- ', 'jQuery --- ', 6000, 13, 0, 'TIME', -6),
(14, 7, '#7 | jQuery --- ', 'jQuery --- ', 7000, 13, 0, 'TIME', -7),
(14, 8, '#8 | jQuery --- ', 'jQuery --- ', 8000, 13, 0, 'TIME', -8),
(14, 9, '#9 | jQuery --- ', 'jQuery --- ', 9000, 13, 0, 'TIME', -9),
(14, 10, '#10 | jQuery --- ', 'jQuery --- ', 10000, 13, 0, 'TIME', -10),
(14, 11, '#11 | jQuery --- ', 'jQuery --- ', 1, 13, -2, 'TIME', -11),
(15, 1, '#1 | Android --- ', 'Android --- ', 1000, 14, 0, 'TIME', -1),
(15, 2, '#2 | Android --- ', 'Android --- ', 2000, 14, 0, 'TIME', -2),
(15, 3, '#3 | Android --- ', 'Android --- ', 3000, 14, 0, 'TIME', -3),
(15, 4, '#4 | Android --- ', 'Android --- ', 5000, 14, 0, 'TIME', -4),
(15, 5, '#5 | Android --- ', 'Android --- ', 5000, 14, 0, 'TIME', -5),
(15, 6, '#6 | Android --- ', 'Android --- ', 6000, 14, 0, 'TIME', -6),
(15, 7, '#7 | Android --- ', 'Android --- ', 7000, 14, 0, 'TIME', -7),
(15, 8, '#8 | Android --- ', 'Android --- ', 8000, 14, 0, 'TIME', -8),
(15, 9, '#9 | Android --- ', 'Android --- ', 9000, 14, 0, 'TIME', -9),
(15, 10, '#10 | Android --- ', 'Android --- ', 10000, 14, 0, 'TIME', -10),
(15, 11, '#11 | Android --- ', 'Android --- ', 1, 14, -2, 'TIME', -11);

DROP TABLE IF EXISTS `jobs`;
CREATE TABLE IF NOT EXISTS `jobs` (
  `account_id` mediumint(8) unsigned NOT NULL,
  `job_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `employer` tinyint(3) unsigned NOT NULL,
  `description_id` tinyint(3) unsigned NOT NULL,
  `money` mediumint(8) unsigned NOT NULL,
  `time` datetime NOT NULL COMMENT 'munka teljesitesenek ideje',
  `exp` smallint(5) unsigned NOT NULL,
  `generated_time` datetime NOT NULL,
  PRIMARY KEY (`job_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci AUTO_INCREMENT=221 ;

INSERT INTO `jobs` VALUES
(1, 211, 27, 8, 1685, '2016-03-31 21:30:58', 1387, '2016-03-31 20:31:47'),
(1, 212, 1, 8, 1763, '2016-03-31 21:03:56', 901, '2016-03-31 20:31:47'),
(1, 213, 55, 8, 1329, '2016-03-31 20:41:43', 1352, '2016-03-31 20:31:47'),
(1, 214, 18, 3, 1644, '2016-03-31 20:49:09', 1028, '2016-03-31 20:31:47'),
(1, 215, 19, 3, 1630, '2016-03-31 20:44:59', 722, '2016-03-31 20:31:47'),
(1, 216, 58, 6, 1125, '2016-03-31 21:18:23', 1021, '2016-03-31 20:31:47'),
(1, 217, 48, 9, 1832, '2016-03-31 21:07:50', 1019, '2016-03-31 20:31:47'),
(1, 218, 20, 5, 1234, '2016-03-31 21:22:05', 1002, '2016-03-31 20:31:47'),
(1, 219, 32, 5, 1948, '2016-03-31 20:44:42', 744, '2016-03-31 20:31:47'),
(1, 220, 7, 2, 1559, '2016-03-31 20:47:19', 1130, '2016-03-31 20:31:48');

DROP TABLE IF EXISTS `jobs_finished`;
CREATE TABLE IF NOT EXISTS `jobs_finished` (
  `job_id` smallint(5) unsigned NOT NULL,
  `deadline` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

DROP TABLE IF EXISTS `job_descriptions`;
CREATE TABLE IF NOT EXISTS `job_descriptions` (
  `id` int(3) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(255) COLLATE utf8_bin NOT NULL,
  `require_skill` int(2) unsigned DEFAULT NULL COMMENT 'skill_id kerül ide',
  `require_skill_level` int(2) unsigned DEFAULT NULL COMMENT 'természetesen a skill-nek a szintje kerül ide',
  `require_language` int(2) unsigned DEFAULT NULL COMMENT 'language_id kerül ide',
  `require_language_level` int(2) unsigned DEFAULT NULL COMMENT 'természetesen a language-nek a szintje kerül ide',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=11 ;

INSERT INTO `job_descriptions` VALUES
(1, 'Készíts egy szimpla HTML, CSS weblapot!', 2, 6, NULL, NULL),
(2, 'Készíts a cégnek weblapot, ami tartalmaz cikkírás, cikkmódosítás, cikktörlést, az ehhez tartozó adminisztrátori belépés mellé', 1, 3, NULL, NULL),
(3, 'Teszteld, hogy fel lehet-e törni', 3, 2, NULL, NULL),
(4, 'Keress 0-day hibát a cég új alkalmazásában', 3, 2, NULL, NULL),
(5, 'Fordítsd le az oldalt angolra!', NULL, NULL, 1, 5),
(6, 'Fordítsd le az oldalt németre!', NULL, NULL, 2, 5),
(7, 'Készíts C# programot', 7, 5, NULL, NULL),
(8, 'Készíts Android-on egy Hello Word-öt!', 16, 1, NULL, NULL),
(9, 'Lopd el valakinek a személyazonosságát (ugye ez valószínűleg Gray vagy Black). Úgy kéne, hogy "megtalál" valamilyen felhasználót, és betör a nevével valahova.', NULL, NULL, NULL, NULL),
(10, 'Segíts a barátodnak egy szimpla HTML CSS form elkészítésében.', 2, 3, NULL, NULL);

DROP TABLE IF EXISTS `job_employers`;
CREATE TABLE IF NOT EXISTS `job_employers` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `employer` varchar(255) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=59 ;

INSERT INTO `job_employers` VALUES
(1, 'ABAHÁZY Bt. - Fordítóiroda'),
(2, 'Alicehair fodrászat'),
(3, 'Amtech Rendszerház Kft.'),
(4, 'ANDREZOL-NET Kft.'),
(5, 'BalatonQuality Rendezvényszervező Iroda'),
(6, 'Brush Bt.'),
(7, 'Cikloid Kft.'),
(8, 'Cromkontakt Galvánipari Kft.'),
(9, 'Design I Do'),
(10, 'DMA Management Academy'),
(11, 'DomyPack & Press Kft.'),
(12, 'Eladó Lakás Kft.'),
(13, 'Electro-Heating Pro Kft.'),
(14, 'Ezüst Kaméleon Kft.'),
(15, 'Füzéri Vár és Látogatóközpont'),
(16, 'GÁZ-ÁRAM Energia Tanácsadó Kft.'),
(17, 'Gipszpalace Bau Kft.'),
(18, 'Gránátalmalé bolt'),
(19, 'Gyógyforrás Gyógycentrum'),
(20, 'Gyurján Kft.'),
(21, 'Harisnya Outlet Kft.'),
(22, 'Haus Tipp-Topp Bt.'),
(23, 'Ház-Mester 2006 Bt.'),
(24, 'HBOMEDICAL'),
(25, 'Homoktövis webáruház'),
(26, 'Humanum Auxilium'),
(27, 'Hungária Költöztetés'),
(28, 'In-Ga Társasházkezelő Kft.'),
(29, 'KataPorta'),
(30, 'Kati-Szalon'),
(31, 'Kék-Suli Oktatóközpont'),
(32, 'Kispál Sándor bútorasztalos mester'),
(33, 'Kiss József EV'),
(34, 'Kölyökvarázs'),
(35, 'KSKNet Kft.'),
(36, 'Kulcs fordítócsoport - KataPorta'),
(37, 'Lomtalanítás Budapest'),
(38, 'M1 Karosszéria Tata'),
(39, 'Molnár Levente és Társa Bt.'),
(40, 'Novaweb Kft.'),
(41, 'Pan-Gica Design'),
(42, 'Patronos bolt'),
(43, 'Perbit HR Magyarország Kft.'),
(44, 'PiperePatika Kft'),
(45, 'Pova Bt.'),
(46, 'REGIO Játékkereskedelmi Kft.'),
(47, 'RPE Kft.'),
(48, 'Stáb Építőipari Szolgáltató Bt.'),
(49, 'T-Creativ.hu'),
(50, 'Takács Gergely'),
(51, 'Tolcsvai kastély látogatóközpont'),
(52, 'Tóvizi Ferenc'),
(53, 'VILLANYÁRAM Energia Tanácsadó Bt.'),
(54, 'VIP Partners Kft.'),
(55, 'VipIT Group Kft.'),
(56, 'VITAX Bt.'),
(57, 'Xt System Épületgépészeti Kft.'),
(58, 'ZöldZóna Kertépítő, Karbantartó Szolg.');

DROP TABLE IF EXISTS `language_list`;
CREATE TABLE IF NOT EXISTS `language_list` (
  `order` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `language_id` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`order`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci AUTO_INCREMENT=4 ;

INSERT INTO `language_list` VALUES
(1, 1),
(2, 2),
(3, 3);

DROP TABLE IF EXISTS `language_table`;
CREATE TABLE IF NOT EXISTS `language_table` (
  `language_id` tinyint(3) unsigned NOT NULL,
  `language_level` tinyint(3) NOT NULL COMMENT 'Jelen pillanatban, ha az érték 11, akkor fullos ez a skill!!',
  `language_description` varchar(255) COLLATE utf8_hungarian_ci NOT NULL,
  `price` mediumint(3) NOT NULL COMMENT 'Ft',
  `requirement_language` tinyint(3) DEFAULT NULL COMMENT 'skill_id-t kell megadni, 0 = nem szükséges hozzá követelmény (= requirement_skill_level-nek is 0-nak kell lennie)',
  `requirement_language_level` tinyint(3) DEFAULT NULL,
  `changing` varchar(4) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL COMMENT 'EXP - TIME - OFFense - DEFFense',
  `changing_value` tinyint(3) DEFAULT NULL COMMENT 'időnél pl mínusz érték, mert csökken a feladat teljesítésének ideje'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

INSERT INTO `language_table` VALUES
(1, 1, 'Angol ---- ', 1000, 0, NULL, 'TIME', -1),
(1, 2, 'Angol ---- ', 2000, 1, NULL, 'TIME', -2),
(1, 3, 'Angol ---- ', 3000, 1, NULL, 'TIME', -3),
(1, 3, 'Angol ---- ', 3000, 1, NULL, 'TIME', -3),
(1, 5, 'Angol ---- ', 5000, 1, NULL, 'TIME', -5),
(1, 6, 'Angol ---- ', 6000, 1, NULL, 'TIME', -6),
(1, 7, 'Angol ---- ', 7000, 1, NULL, 'TIME', -7),
(1, 8, 'Angol ---- ', 8000, 1, NULL, 'TIME', -8),
(1, 9, 'Angol ---- ', 9000, 1, NULL, 'TIME', -9),
(1, 10, 'Angol ---- ', 10000, 1, NULL, 'TIME', -10),
(1, 11, 'Angol --- ', 11000, 0, -2, 'TIME', -11),
(2, 1, 'Német --- ', 1000, 1, NULL, 'TIME', -1),
(2, 2, 'Német --- ', 2000, 2, NULL, 'TIME', -2),
(2, 3, 'Német --- ', 3000, 2, NULL, 'TIME', -3),
(2, 4, 'Német --- ', 4000, 2, NULL, 'TIME', -4),
(2, 5, 'Német --- ', 5000, 2, NULL, 'TIME', -5),
(2, 6, 'Német --- ', 6000, 2, NULL, 'TIME', -6),
(2, 7, 'Német --- ', 7000, 2, NULL, 'TIME', -7),
(2, 8, 'Német --- ', 8000, 2, NULL, 'TIME', -8),
(2, 9, 'Német --- ', 9000, 2, NULL, 'TIME', -9),
(2, 10, 'Német --- ', 10000, 2, NULL, 'TIME', -10),
(2, 11, 'Német --- ', 11000, 0, -2, 'TIME', -11),
(3, 1, 'Orosz --- ', 1000, 1, NULL, 'TIME', -1),
(3, 2, 'Orosz --- ', 2000, 3, NULL, 'TIME', -2),
(3, 3, 'Orosz --- ', 3000, 3, NULL, 'TIME', -3),
(3, 4, 'Orosz --- ', 4000, 3, NULL, 'TIME', -4),
(3, 5, 'Orosz --- ', 5000, 3, NULL, 'TIME', -5),
(3, 6, 'Orosz --- ', 6000, 3, NULL, 'TIME', -6),
(3, 7, 'Orosz --- ', 7000, 3, NULL, 'TIME', -7),
(3, 8, 'Orosz --- ', 8000, 3, NULL, 'TIME', -8),
(3, 9, 'Orosz --- ', 9000, 3, NULL, 'TIME', -9),
(3, 10, 'Orosz --- ', 10000, 3, NULL, 'TIME', -10),
(3, 11, 'Orosz --- ', 11000, 0, -2, 'TIME', -11),
(1, 4, 'sfdgdfg', 4000, 1, NULL, 'TIME', -4);

DROP TABLE IF EXISTS `levels`;
CREATE TABLE IF NOT EXISTS `levels` (
  `level` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `exp` mediumint(8) unsigned NOT NULL COMMENT 'Következő szint eléréséhez szükséges EXP-t mutatja               |               round(abs(8559/51+11-2-(93-52)-93/92/79+(36)+95/97+83/1747-31+30/15-(3/12)-7*671-36/99*1004-20/4961+(3652)) * 9.4591836734694 * $i)',
  PRIMARY KEY (`level`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci AUTO_INCREMENT=21 ;

INSERT INTO `levels` VALUES
(1, 11980),
(2, 23960),
(3, 35940),
(4, 47921),
(5, 59901),
(6, 71881),
(7, 83861),
(8, 95841),
(9, 107821),
(10, 119801),
(11, 131781),
(12, 143762),
(13, 155742),
(14, 167722),
(15, 179702),
(16, 191682),
(17, 203662),
(18, 215642),
(19, 227622),
(20, 239603);

DROP TABLE IF EXISTS `messages`;
CREATE TABLE IF NOT EXISTS `messages` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `msg_to` varchar(50) COLLATE utf8_hungarian_ci NOT NULL COMMENT 'account_id',
  `msg_from` varchar(50) COLLATE utf8_hungarian_ci NOT NULL COMMENT 'account_id',
  `message` varchar(255) COLLATE utf8_hungarian_ci NOT NULL,
  `date` datetime NOT NULL,
  `seen` tinyint(1) unsigned DEFAULT NULL COMMENT '0 = nem látta, 1 = látta',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci AUTO_INCREMENT=1 ;

DROP TABLE IF EXISTS `news`;
CREATE TABLE IF NOT EXISTS `news` (
  `text` varchar(255) COLLATE utf8_hungarian_ci NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

INSERT INTO `news` VALUES
('A szoftverspecifikáció, rendszerspecifikáció véglegesítésre került, a tervek (pl.\r\n\r\nadatmodell, objektum-hierarhia) bemutatásra kerültek, a tényleges fejlesztés\r\n\r\nmegkezdhető.', '2016-01-27 23:59:59'),
('A szoftver egy köztes fejlesztési állapotának bemutatása (egyes\r\n\r\nprogrammodulok már tesztelhetők, a szoftver felhasználói felülete kialakításra\r\n\r\nkerült). A dokumentáció struktúrájának a kialakítása megtörtént, a fejlesztési\r\n\r\ndokumentáció tervezéssel', '2016-02-17 23:59:59'),
('A szoftver összes fontos modulja működőképes, a modulok integrációja\r\n\r\nmegtörtént. A fejlesztői dokumentáció - a tesztelési dokumentáció kivételével\r\n\r\n- elkészült. A rendszer átfogó\r\n\r\nmegírása elkezdhető.', '2016-03-09 23:59:59'),
('A szoftver elkészült és tesztelésre került, a nyomtatott dokumentáció\r\n\r\nelkészült. A záródolgozat legkésőbb ezen a napon adható be, a konzulens\r\n\r\njóváhagyó nyilatkozatának a csatolásával.', '2016-03-30 23:59:59');

DROP TABLE IF EXISTS `skill_list`;
CREATE TABLE IF NOT EXISTS `skill_list` (
  `order` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `skill_id` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`order`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci AUTO_INCREMENT=16 ;

INSERT INTO `skill_list` VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 14),
(5, 4),
(6, 5),
(7, 13),
(8, 6),
(9, 7),
(10, 8),
(11, 9),
(12, 10),
(13, 11),
(14, 12),
(15, 15);

DROP TABLE IF EXISTS `skill_table`;
CREATE TABLE IF NOT EXISTS `skill_table` (
  `skill_id` tinyint(3) unsigned NOT NULL,
  `skill_level` tinyint(3) unsigned NOT NULL COMMENT 'Jelen pillanatban, ha az érték 11, akkor fullos ez a skill!!',
  `skill_tooltip` varchar(2500) COLLATE utf8_hungarian_ci NOT NULL COMMENT 'Ez jelenik meg a ( ? ) jelnél',
  `skill_description` varchar(255) COLLATE utf8_hungarian_ci NOT NULL,
  `price` mediumint(8) unsigned NOT NULL COMMENT 'Ft',
  `requirement_skill` tinyint(3) unsigned NOT NULL COMMENT 'skill_id-t kell megadni, 0 = nem szükséges hozzá követelmény (= requirement_skill_level-nek is 0-nak kell lennie)',
  `requirement_skill_level` tinyint(3) NOT NULL,
  `changing` varchar(4) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL COMMENT 'EXP - TIME - OFFense - DEFFense',
  `changing_value` tinyint(3) NOT NULL COMMENT 'időnél pl mínusz érték, mert csökken a feladat teljesítésének ideje'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

INSERT INTO `skill_table` VALUES
(1, 1, '#1 | HTML --- ', 'HTML --- ', 1000, 0, 0, 'TIME', -1),
(1, 2, '#2 | HTML --- ', 'HTML --- ', 2000, 0, 0, 'TIME', -2),
(1, 3, '#3 | HTML --- ', 'HTML --- ', 3000, 0, 0, 'TIME', -3),
(1, 4, '#4 | HTML --- ', 'HTML --- ', 4000, 0, 0, 'TIME', -4),
(1, 5, '#5 | HTML --- ', 'HTML --- ', 5000, 0, 0, 'TIME', -5),
(1, 6, '#6 | HTML --- ', 'HTML --- ', 6000, 0, 0, 'TIME', -6),
(1, 7, '#7 | HTML --- ', 'HTML --- ', 7000, 0, 0, 'TIME', -7),
(1, 8, '#8 | HTML --- ', 'HTML --- ', 8000, 0, 0, 'TIME', -8),
(1, 9, '#9 | HTML --- ', 'HTML --- ', 9000, 0, 0, 'TIME', -9),
(1, 10, '#10 | HTML --- ', 'HTML --- ', 10000, 0, 0, 'TIME', -10),
(1, 11, '#11 | HTML --- ', 'HTML --- ', 1, 0, -2, 'TIME', -11),
(2, 1, '#1 | CSS --- ', 'CSS --- ', 1000, 1, 0, 'TIME', -1),
(2, 2, '#2 | CSS --- ', 'CSS --- ', 2000, 1, 0, 'TIME', -2),
(2, 3, '#3 | CSS --- ', 'CSS --- ', 3000, 1, 0, 'TIME', -3),
(2, 4, '#4 | CSS --- ', 'CSS --- ', 4000, 1, 0, 'TIME', -4),
(2, 5, '#5 | CSS --- ', 'CSS --- ', 5000, 1, 0, 'TIME', -5),
(2, 6, '#6 | CSS --- ', 'CSS --- ', 6000, 1, 0, 'TIME', -6),
(2, 7, '#7 | CSS --- ', 'CSS --- ', 7000, 1, 0, 'TIME', -7),
(2, 8, '#8 | CSS --- ', 'CSS --- ', 8000, 1, 0, 'TIME', -8),
(2, 9, '#9 | CSS --- ', 'CSS --- ', 9000, 1, 0, 'TIME', -9),
(2, 10, '#10 | CSS --- ', 'CSS --- ', 10000, 1, 0, 'TIME', -10),
(2, 11, '#11 | CSS --- ', 'CSS --- ', 1, 1, -2, 'TIME', -11),
(3, 1, '#1 | JavaScript --- ', 'JavaScript --- ', 1000, 2, 0, 'TIME', -1),
(3, 2, '#2 | JavaScript --- ', 'JavaScript --- ', 2000, 2, 0, 'TIME', -2),
(3, 3, '#3 | JavaScript --- ', 'JavaScript --- ', 3000, 2, 0, 'TIME', -3),
(3, 4, '#4 | JavaScript --- ', 'JavaScript --- ', 4000, 2, 0, 'TIME', -4),
(3, 5, '#5 | JavaScript --- ', 'JavaScript --- ', 5000, 2, 0, 'TIME', -5),
(3, 6, '#6 | JavaScript --- ', 'JavaScript --- ', 6000, 2, 0, 'TIME', -6),
(3, 7, '#7 | JavaScript --- ', 'JavaScript --- ', 7000, 2, 0, 'TIME', -7),
(3, 8, '#8 | JavaScript --- ', 'JavaScript --- ', 8000, 2, 0, 'TIME', -8),
(3, 9, '#9 | JavaScript --- ', 'JavaScript --- ', 9000, 2, 0, 'TIME', -9),
(3, 10, '#10 | JavaScript --- ', 'JavaScript --- ', 10000, 2, 0, 'TIME', -10),
(3, 11, '#11 | JavaScript --- ', 'JavaScript --- ', 1, 2, -2, 'TIME', -11),
(4, 1, '#1 | PHP --- ', 'PHP --- ', 1000, 3, 0, 'TIME', -1),
(4, 2, '#2 | PHP --- ', 'PHP --- ', 2000, 3, 0, 'TIME', -2),
(4, 3, '#3 | PHP --- ', 'PHP --- ', 3000, 3, 0, 'TIME', -3),
(4, 4, '#4 | PHP --- ', 'PHP --- ', 4000, 3, 0, 'TIME', -4),
(4, 5, '#5 | PHP --- ', 'PHP --- ', 5000, 3, 0, 'TIME', -5),
(4, 6, '#6 | PHP --- ', 'PHP --- ', 6000, 3, 0, 'TIME', -6),
(4, 7, '#7 | PHP --- ', 'PHP --- ', 7000, 3, 0, 'TIME', -7),
(4, 8, '#8 | PHP --- ', 'PHP --- ', 8000, 3, 0, 'TIME', -8),
(4, 9, '#9 | PHP --- ', 'PHP --- ', 9000, 3, 0, 'TIME', -9),
(4, 10, '#10 | PHP --- ', 'PHP --- ', 10000, 3, 0, 'TIME', -10),
(4, 11, '#11 | PHP --- ', 'PHP --- ', 1, 3, -2, 'TIME', -11),
(5, 1, '#1 | SQL --- ', 'SQL --- ', 1000, 4, 0, 'TIME', -1),
(5, 2, '#2 | SQL --- ', 'SQL --- ', 2000, 4, 0, 'TIME', -2),
(5, 3, '#3 | SQL --- ', 'SQL --- ', 3000, 4, 0, 'TIME', -3),
(5, 4, '#4 | SQL --- ', 'SQL --- ', 5000, 4, 0, 'TIME', -4),
(5, 5, '#5 | SQL --- ', 'SQL --- ', 5000, 4, 0, 'TIME', -5),
(5, 6, '#6 | SQL --- ', 'SQL --- ', 6000, 4, 0, 'TIME', -6),
(5, 7, '#7 | SQL --- ', 'SQL --- ', 7000, 4, 0, 'TIME', -7),
(5, 8, '#8 | SQL --- ', 'SQL --- ', 8000, 4, 0, 'TIME', -8),
(5, 9, '#9 | SQL --- ', 'SQL --- ', 9000, 4, 0, 'TIME', -9),
(5, 10, '#10 | SQL --- ', 'SQL --- ', 10000, 4, 0, 'TIME', -10),
(5, 11, '#11 | SQL --- ', 'SQL --- ', 1, 4, -2, 'TIME', -11),
(6, 1, '#1 | C# --- ', 'C# --- ', 1000, 5, 0, 'TIME', -1),
(6, 2, '#2 | C# --- ', 'C# --- ', 2000, 5, 0, 'TIME', -2),
(6, 3, '#3 | C# --- ', 'C# --- ', 3000, 5, 0, 'TIME', -3),
(6, 4, '#4 | C# --- ', 'C# --- ', 5000, 5, 0, 'TIME', -4),
(6, 5, '#5 | C# --- ', 'C# --- ', 5000, 5, 0, 'TIME', -5),
(6, 6, '#6 | C# --- ', 'C# --- ', 6000, 5, 0, 'TIME', -6),
(6, 7, '#7 | C# --- ', 'C# --- ', 7000, 5, 0, 'TIME', -7),
(6, 8, '#8 | C# --- ', 'C# --- ', 8000, 5, 0, 'TIME', -8),
(6, 9, '#9 | C# --- ', 'C# --- ', 9000, 5, 0, 'TIME', -9),
(6, 10, '#10 | C# --- ', 'C# --- ', 10000, 5, 0, 'TIME', -10),
(6, 11, '#11 | C# --- ', 'C# --- ', 1, 5, -2, 'TIME', -11),
(7, 1, '#1 | Java --- ', 'Java --- ', 1000, 6, 0, 'TIME', -1),
(7, 2, '#2 | Java --- ', 'Java --- ', 2000, 6, 0, 'TIME', -2),
(7, 3, '#3 | Java --- ', 'Java --- ', 3000, 6, 0, 'TIME', -3),
(7, 4, '#4 | Java --- ', 'Java --- ', 5000, 6, 0, 'TIME', -4),
(7, 5, '#5 | Java --- ', 'Java --- ', 5000, 6, 0, 'TIME', -5),
(7, 6, '#6 | Java --- ', 'Java --- ', 6000, 6, 0, 'TIME', -6),
(7, 7, '#7 | Java --- ', 'Java --- ', 7000, 6, 0, 'TIME', -7),
(7, 8, '#8 | Java --- ', 'Java --- ', 8000, 6, 0, 'TIME', -8),
(7, 9, '#9 | Java --- ', 'Java --- ', 9000, 6, 0, 'TIME', -9),
(7, 10, '#10 | Java --- ', 'Java --- ', 10000, 6, 0, 'TIME', -10),
(7, 11, '#11 | Java --- ', 'Java --- ', 1, 6, -2, 'TIME', -11),
(8, 1, '#1 | Assembly --- ', 'Assembly --- ', 1000, 6, 0, 'TIME', -1),
(8, 2, '#2 | Assembly --- ', 'Assembly --- ', 2000, 6, 0, 'TIME', -2),
(8, 3, '#3 | Assembly --- ', 'Assembly --- ', 3000, 6, 0, 'TIME', -3),
(8, 4, '#4 | Assembly --- ', 'Assembly --- ', 5000, 6, 0, 'TIME', -4),
(8, 5, '#5 | Assembly --- ', 'Assembly --- ', 5000, 6, 0, 'TIME', -5),
(8, 6, '#6 | Assembly --- ', 'Assembly --- ', 6000, 6, 0, 'TIME', -6),
(8, 7, '#7 | Assembly --- ', 'Assembly --- ', 7000, 6, 0, 'TIME', -7),
(8, 8, '#8 | Assembly --- ', 'Assembly --- ', 8000, 6, 0, 'TIME', -8),
(8, 9, '#9 | Assembly --- ', 'Assembly --- ', 9000, 6, 0, 'TIME', -9),
(8, 10, '#10 | Assembly --- ', 'Assembly --- ', 10000, 6, 0, 'TIME', -10),
(8, 11, '#11 | Assembly --- ', 'Assembly --- ', 1, 6, -2, 'TIME', -11),
(9, 1, '#1 | 2-es számrendszer --- ', '2-es számrendszer --- ', 1000, 8, 0, 'TIME', -1),
(9, 2, '#2 | 2-es számrendszer --- ', '2-es számrendszer --- ', 2000, 8, 0, 'TIME', -2),
(9, 3, '#3 | 2-es számrendszer --- ', '2-es számrendszer --- ', 3000, 8, 0, 'TIME', -3),
(9, 4, '#4 | 2-es számrendszer --- ', '2-es számrendszer --- ', 5000, 8, 0, 'TIME', -4),
(9, 5, '#5 | 2-es számrendszer --- ', '2-es számrendszer --- ', 5000, 8, 0, 'TIME', -5),
(9, 6, '#6 | 2-es számrendszer --- ', '2-es számrendszer --- ', 6000, 8, 0, 'TIME', -6),
(9, 7, '#7 | 2-es számrendszer --- ', '2-es számrendszer --- ', 7000, 8, 0, 'TIME', -7),
(9, 8, '#8 | 2-es számrendszer --- ', '2-es számrendszer --- ', 8000, 8, 0, 'TIME', -8),
(9, 9, '#9 | 2-es számrendszer --- ', '2-es számrendszer --- ', 9000, 8, 0, 'TIME', -9),
(9, 10, '#10 | 2-es számrendszer --- ', '2-es számrendszer --- ', 10000, 8, 0, 'TIME', -10),
(9, 11, '#11 | 2-es számrendszer --- ', '2-es számrendszer --- ', 1, 8, -2, 'TIME', -11),
(10, 1, '#1 | 16-os számrendszer --- ', '16-os számrendszer --- ', 1000, 6, 0, 'TIME', -1),
(10, 2, '#2 | 16-os számrendszer --- ', '16-os számrendszer --- ', 2000, 6, 0, 'TIME', -2),
(10, 3, '#3 | 16-os számrendszer --- ', '16-os számrendszer --- ', 3000, 6, 0, 'TIME', -3),
(10, 4, '#4 | 16-os számrendszer --- ', '16-os számrendszer --- ', 5000, 6, 0, 'TIME', -4),
(10, 5, '#5 | 16-os számrendszer --- ', '16-os számrendszer --- ', 5000, 6, 0, 'TIME', -5),
(10, 6, '#6 | 16-os számrendszer --- ', '16-os számrendszer --- ', 6000, 6, 0, 'TIME', -6),
(10, 7, '#7 | 16-os számrendszer --- ', '16-os számrendszer --- ', 7000, 6, 0, 'TIME', -7),
(10, 8, '#8 | 16-os számrendszer --- ', '16-os számrendszer --- ', 8000, 6, 0, 'TIME', -8),
(10, 9, '#9 | 16-os számrendszer --- ', '16-os számrendszer --- ', 9000, 6, 0, 'TIME', -9),
(10, 10, '#10 | 16-os számrendszer --- ', '16-os számrendszer --- ', 10000, 6, 0, 'TIME', -10),
(10, 11, '#11 | 16-os számrendszer --- ', '16-os számrendszer --- ', 1, 6, -2, 'TIME', -11),
(11, 1, '#1 | PowerShell --- ', 'PowerShell --- ', 1000, 10, 0, 'TIME', -1),
(11, 2, '#2 | PowerShell --- ', 'PowerShell --- ', 2000, 10, 0, 'TIME', -2),
(11, 3, '#3 | PowerShell --- ', 'PowerShell --- ', 3000, 10, 0, 'TIME', -3),
(11, 4, '#4 | PowerShell --- ', 'PowerShell --- ', 5000, 10, 0, 'TIME', -4),
(11, 5, '#5 | PowerShell --- ', 'PowerShell --- ', 5000, 10, 0, 'TIME', -5),
(11, 6, '#6 | PowerShell --- ', 'PowerShell --- ', 6000, 10, 0, 'TIME', -6),
(11, 7, '#7 | PowerShell --- ', 'PowerShell --- ', 7000, 10, 0, 'TIME', -7),
(11, 8, '#8 | PowerShell --- ', 'PowerShell --- ', 8000, 10, 0, 'TIME', -8),
(11, 9, '#9 | PowerShell --- ', 'PowerShell --- ', 9000, 10, 0, 'TIME', -9),
(11, 10, '#10 | PowerShell --- ', 'PowerShell --- ', 10000, 10, 0, 'TIME', -10),
(11, 11, '#11 | PowerShell --- ', 'PowerShell --- ', 1, 10, -2, 'TIME', -11),
(12, 1, '#1 | Python --- ', 'Python --- ', 1000, 11, 0, 'TIME', -1),
(12, 2, '#2 | Python --- ', 'Python --- ', 2000, 11, 0, 'TIME', -2),
(12, 3, '#3 | Python --- ', 'Python --- ', 3000, 11, 0, 'TIME', -3),
(12, 4, '#4 | Python --- ', 'Python --- ', 5000, 11, 0, 'TIME', -4),
(12, 5, '#5 | Python --- ', 'Python --- ', 5000, 11, 0, 'TIME', -5),
(12, 6, '#6 | Python --- ', 'Python --- ', 6000, 11, 0, 'TIME', -6),
(12, 7, '#7 | Python --- ', 'Python --- ', 7000, 11, 0, 'TIME', -7),
(12, 8, '#8 | Python --- ', 'Python --- ', 8000, 11, 0, 'TIME', -8),
(12, 9, '#9 | Python --- ', 'Python --- ', 9000, 11, 0, 'TIME', -9),
(12, 10, '#10 | Python --- ', 'Python --- ', 10000, 11, 0, 'TIME', -10),
(12, 11, '#11 | Python --- ', 'Python --- ', 1, 11, -2, 'TIME', -11),
(13, 1, '#1 | Ajax --- ', 'Ajax --- ', 1000, 12, 0, 'TIME', -1),
(13, 2, '#2 | Ajax --- ', 'Ajax --- ', 2000, 12, 0, 'TIME', -2),
(13, 3, '#3 | Ajax --- ', 'Ajax --- ', 3000, 12, 0, 'TIME', -3),
(13, 4, '#4 | Ajax --- ', 'Ajax --- ', 5000, 12, 0, 'TIME', -4),
(13, 5, '#5 | Ajax --- ', 'Ajax --- ', 5000, 12, 0, 'TIME', -5),
(13, 6, '#6 | Ajax --- ', 'Ajax --- ', 6000, 12, 0, 'TIME', -6),
(13, 7, '#7 | Ajax --- ', 'Ajax --- ', 7000, 12, 0, 'TIME', -7),
(13, 8, '#8 | Ajax --- ', 'Ajax --- ', 8000, 12, 0, 'TIME', -8),
(13, 9, '#9 | Ajax --- ', 'Ajax --- ', 9000, 12, 0, 'TIME', -9),
(13, 10, '#10 | Ajax --- ', 'Ajax --- ', 10000, 12, 0, 'TIME', -10),
(13, 11, '#11 | Ajax --- ', 'Ajax --- ', 1, 12, -2, 'TIME', -11),
(14, 1, '#1 | jQuery --- ', 'jQuery --- ', 1000, 13, 0, 'TIME', -1),
(14, 2, '#2 | jQuery --- ', 'jQuery --- ', 2000, 13, 0, 'TIME', -2),
(14, 3, '#3 | jQuery --- ', 'jQuery --- ', 3000, 13, 0, 'TIME', -3),
(14, 4, '#4 | jQuery --- ', 'jQuery --- ', 5000, 13, 0, 'TIME', -4),
(14, 5, '#5 | jQuery --- ', 'jQuery --- ', 5000, 13, 0, 'TIME', -5),
(14, 6, '#6 | jQuery --- ', 'jQuery --- ', 6000, 13, 0, 'TIME', -6),
(14, 7, '#7 | jQuery --- ', 'jQuery --- ', 7000, 13, 0, 'TIME', -7),
(14, 8, '#8 | jQuery --- ', 'jQuery --- ', 8000, 13, 0, 'TIME', -8),
(14, 9, '#9 | jQuery --- ', 'jQuery --- ', 9000, 13, 0, 'TIME', -9),
(14, 10, '#10 | jQuery --- ', 'jQuery --- ', 10000, 13, 0, 'TIME', -10),
(14, 11, '#11 | jQuery --- ', 'jQuery --- ', 1, 13, -2, 'TIME', -11),
(15, 1, '#1 | Android --- ', 'Android --- ', 1000, 14, 0, 'TIME', -1),
(15, 2, '#2 | Android --- ', 'Android --- ', 2000, 14, 0, 'TIME', -2),
(15, 3, '#3 | Android --- ', 'Android --- ', 3000, 14, 0, 'TIME', -3),
(15, 4, '#4 | Android --- ', 'Android --- ', 5000, 14, 0, 'TIME', -4),
(15, 5, '#5 | Android --- ', 'Android --- ', 5000, 14, 0, 'TIME', -5),
(15, 6, '#6 | Android --- ', 'Android --- ', 6000, 14, 0, 'TIME', -6),
(15, 7, '#7 | Android --- ', 'Android --- ', 7000, 14, 0, 'TIME', -7),
(15, 8, '#8 | Android --- ', 'Android --- ', 8000, 14, 0, 'TIME', -8),
(15, 9, '#9 | Android --- ', 'Android --- ', 9000, 14, 0, 'TIME', -9),
(15, 10, '#10 | Android --- ', 'Android --- ', 10000, 14, 0, 'TIME', -10),
(15, 11, '#11 | Android --- ', 'Android --- ', 1, 14, -2, 'TIME', -11);

DROP TABLE IF EXISTS `software_list`;
CREATE TABLE IF NOT EXISTS `software_list` (
  `order` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `software_id` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`order`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci AUTO_INCREMENT=16 ;

INSERT INTO `software_list` VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 14),
(5, 4),
(6, 5),
(7, 13),
(8, 6),
(9, 7),
(10, 8),
(11, 9),
(12, 10),
(13, 11),
(14, 12),
(15, 15);

DROP TABLE IF EXISTS `software_table`;
CREATE TABLE IF NOT EXISTS `software_table` (
  `software_id` tinyint(3) unsigned NOT NULL,
  `software_level` tinyint(3) unsigned NOT NULL COMMENT 'Jelen pillanatban, ha az érték 11, akkor fullos ez a software!!',
  `software_tooltip` varchar(2500) COLLATE utf8_hungarian_ci NOT NULL COMMENT 'Ez jelenik meg a ( ? ) jelnél',
  `software_description` varchar(255) COLLATE utf8_hungarian_ci NOT NULL,
  `price` mediumint(8) unsigned NOT NULL COMMENT 'Ft',
  `requirement_software` tinyint(3) unsigned NOT NULL COMMENT 'software_id-t kell megadni, 0 = nem szükséges hozzá követelmény (= requirement_software_level-nek is 0-nak kell lennie)',
  `requirement_software_level` tinyint(3) NOT NULL,
  `changing` varchar(4) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL COMMENT 'EXP - TIME - OFFense - DEFFense',
  `changing_value` tinyint(3) NOT NULL COMMENT 'időnél pl mínusz érték, mert csökken a feladat teljesítésének ideje'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

INSERT INTO `software_table` VALUES
(1, 1, '#1 | HTML --- ', 'HTML --- ', 1000, 0, 0, 'TIME', -1),
(1, 2, '#2 | HTML --- ', 'HTML --- ', 2000, 0, 0, 'TIME', -2),
(1, 3, '#3 | HTML --- ', 'HTML --- ', 3000, 0, 0, 'TIME', -3),
(1, 4, '#4 | HTML --- ', 'HTML --- ', 4000, 0, 0, 'TIME', -4),
(1, 5, '#5 | HTML --- ', 'HTML --- ', 5000, 0, 0, 'TIME', -5),
(1, 6, '#6 | HTML --- ', 'HTML --- ', 6000, 0, 0, 'TIME', -6),
(1, 7, '#7 | HTML --- ', 'HTML --- ', 7000, 0, 0, 'TIME', -7),
(1, 8, '#8 | HTML --- ', 'HTML --- ', 8000, 0, 0, 'TIME', -8),
(1, 9, '#9 | HTML --- ', 'HTML --- ', 9000, 0, 0, 'TIME', -9),
(1, 10, '#10 | HTML --- ', 'HTML --- ', 10000, 0, 0, 'TIME', -10),
(1, 11, '#11 | HTML --- ', 'HTML --- ', 1, 0, -2, 'TIME', -11),
(2, 1, '#1 | CSS --- ', 'CSS --- ', 1000, 1, 0, 'TIME', -1),
(2, 2, '#2 | CSS --- ', 'CSS --- ', 2000, 1, 0, 'TIME', -2),
(2, 3, '#3 | CSS --- ', 'CSS --- ', 3000, 1, 0, 'TIME', -3),
(2, 4, '#4 | CSS --- ', 'CSS --- ', 4000, 1, 0, 'TIME', -4),
(2, 5, '#5 | CSS --- ', 'CSS --- ', 5000, 1, 0, 'TIME', -5),
(2, 6, '#6 | CSS --- ', 'CSS --- ', 6000, 1, 0, 'TIME', -6),
(2, 7, '#7 | CSS --- ', 'CSS --- ', 7000, 1, 0, 'TIME', -7),
(2, 8, '#8 | CSS --- ', 'CSS --- ', 8000, 1, 0, 'TIME', -8),
(2, 9, '#9 | CSS --- ', 'CSS --- ', 9000, 1, 0, 'TIME', -9),
(2, 10, '#10 | CSS --- ', 'CSS --- ', 10000, 1, 0, 'TIME', -10),
(2, 11, '#11 | CSS --- ', 'CSS --- ', 1, 1, -2, 'TIME', -11),
(3, 1, '#1 | JavaScript --- ', 'JavaScript --- ', 1000, 2, 0, 'TIME', -1),
(3, 2, '#2 | JavaScript --- ', 'JavaScript --- ', 2000, 2, 0, 'TIME', -2),
(3, 3, '#3 | JavaScript --- ', 'JavaScript --- ', 3000, 2, 0, 'TIME', -3),
(3, 4, '#4 | JavaScript --- ', 'JavaScript --- ', 4000, 2, 0, 'TIME', -4),
(3, 5, '#5 | JavaScript --- ', 'JavaScript --- ', 5000, 2, 0, 'TIME', -5),
(3, 6, '#6 | JavaScript --- ', 'JavaScript --- ', 6000, 2, 0, 'TIME', -6),
(3, 7, '#7 | JavaScript --- ', 'JavaScript --- ', 7000, 2, 0, 'TIME', -7),
(3, 8, '#8 | JavaScript --- ', 'JavaScript --- ', 8000, 2, 0, 'TIME', -8),
(3, 9, '#9 | JavaScript --- ', 'JavaScript --- ', 9000, 2, 0, 'TIME', -9),
(3, 10, '#10 | JavaScript --- ', 'JavaScript --- ', 10000, 2, 0, 'TIME', -10),
(3, 11, '#11 | JavaScript --- ', 'JavaScript --- ', 1, 2, -2, 'TIME', -11),
(4, 1, '#1 | PHP --- ', 'PHP --- ', 1000, 3, 0, 'TIME', -1),
(4, 2, '#2 | PHP --- ', 'PHP --- ', 2000, 3, 0, 'TIME', -2),
(4, 3, '#3 | PHP --- ', 'PHP --- ', 3000, 3, 0, 'TIME', -3),
(4, 4, '#4 | PHP --- ', 'PHP --- ', 4000, 3, 0, 'TIME', -4),
(4, 5, '#5 | PHP --- ', 'PHP --- ', 5000, 3, 0, 'TIME', -5),
(4, 6, '#6 | PHP --- ', 'PHP --- ', 6000, 3, 0, 'TIME', -6),
(4, 7, '#7 | PHP --- ', 'PHP --- ', 7000, 3, 0, 'TIME', -7),
(4, 8, '#8 | PHP --- ', 'PHP --- ', 8000, 3, 0, 'TIME', -8),
(4, 9, '#9 | PHP --- ', 'PHP --- ', 9000, 3, 0, 'TIME', -9),
(4, 10, '#10 | PHP --- ', 'PHP --- ', 10000, 3, 0, 'TIME', -10),
(4, 11, '#11 | PHP --- ', 'PHP --- ', 1, 3, -2, 'TIME', -11),
(5, 1, '#1 | SQL --- ', 'SQL --- ', 1000, 4, 0, 'TIME', -1),
(5, 2, '#2 | SQL --- ', 'SQL --- ', 2000, 4, 0, 'TIME', -2),
(5, 3, '#3 | SQL --- ', 'SQL --- ', 3000, 4, 0, 'TIME', -3),
(5, 4, '#4 | SQL --- ', 'SQL --- ', 5000, 4, 0, 'TIME', -4),
(5, 5, '#5 | SQL --- ', 'SQL --- ', 5000, 4, 0, 'TIME', -5),
(5, 6, '#6 | SQL --- ', 'SQL --- ', 6000, 4, 0, 'TIME', -6),
(5, 7, '#7 | SQL --- ', 'SQL --- ', 7000, 4, 0, 'TIME', -7),
(5, 8, '#8 | SQL --- ', 'SQL --- ', 8000, 4, 0, 'TIME', -8),
(5, 9, '#9 | SQL --- ', 'SQL --- ', 9000, 4, 0, 'TIME', -9),
(5, 10, '#10 | SQL --- ', 'SQL --- ', 10000, 4, 0, 'TIME', -10),
(5, 11, '#11 | SQL --- ', 'SQL --- ', 1, 4, -2, 'TIME', -11),
(6, 1, '#1 | C# --- ', 'C# --- ', 1000, 5, 0, 'TIME', -1),
(6, 2, '#2 | C# --- ', 'C# --- ', 2000, 5, 0, 'TIME', -2),
(6, 3, '#3 | C# --- ', 'C# --- ', 3000, 5, 0, 'TIME', -3),
(6, 4, '#4 | C# --- ', 'C# --- ', 5000, 5, 0, 'TIME', -4),
(6, 5, '#5 | C# --- ', 'C# --- ', 5000, 5, 0, 'TIME', -5),
(6, 6, '#6 | C# --- ', 'C# --- ', 6000, 5, 0, 'TIME', -6),
(6, 7, '#7 | C# --- ', 'C# --- ', 7000, 5, 0, 'TIME', -7),
(6, 8, '#8 | C# --- ', 'C# --- ', 8000, 5, 0, 'TIME', -8),
(6, 9, '#9 | C# --- ', 'C# --- ', 9000, 5, 0, 'TIME', -9),
(6, 10, '#10 | C# --- ', 'C# --- ', 10000, 5, 0, 'TIME', -10),
(6, 11, '#11 | C# --- ', 'C# --- ', 1, 5, -2, 'TIME', -11),
(7, 1, '#1 | Java --- ', 'Java --- ', 1000, 6, 0, 'TIME', -1),
(7, 2, '#2 | Java --- ', 'Java --- ', 2000, 6, 0, 'TIME', -2),
(7, 3, '#3 | Java --- ', 'Java --- ', 3000, 6, 0, 'TIME', -3),
(7, 4, '#4 | Java --- ', 'Java --- ', 5000, 6, 0, 'TIME', -4),
(7, 5, '#5 | Java --- ', 'Java --- ', 5000, 6, 0, 'TIME', -5),
(7, 6, '#6 | Java --- ', 'Java --- ', 6000, 6, 0, 'TIME', -6),
(7, 7, '#7 | Java --- ', 'Java --- ', 7000, 6, 0, 'TIME', -7),
(7, 8, '#8 | Java --- ', 'Java --- ', 8000, 6, 0, 'TIME', -8),
(7, 9, '#9 | Java --- ', 'Java --- ', 9000, 6, 0, 'TIME', -9),
(7, 10, '#10 | Java --- ', 'Java --- ', 10000, 6, 0, 'TIME', -10),
(7, 11, '#11 | Java --- ', 'Java --- ', 1, 6, -2, 'TIME', -11),
(8, 1, '#1 | Assembly --- ', 'Assembly --- ', 1000, 6, 0, 'TIME', -1),
(8, 2, '#2 | Assembly --- ', 'Assembly --- ', 2000, 6, 0, 'TIME', -2),
(8, 3, '#3 | Assembly --- ', 'Assembly --- ', 3000, 6, 0, 'TIME', -3),
(8, 4, '#4 | Assembly --- ', 'Assembly --- ', 5000, 6, 0, 'TIME', -4),
(8, 5, '#5 | Assembly --- ', 'Assembly --- ', 5000, 6, 0, 'TIME', -5),
(8, 6, '#6 | Assembly --- ', 'Assembly --- ', 6000, 6, 0, 'TIME', -6),
(8, 7, '#7 | Assembly --- ', 'Assembly --- ', 7000, 6, 0, 'TIME', -7),
(8, 8, '#8 | Assembly --- ', 'Assembly --- ', 8000, 6, 0, 'TIME', -8),
(8, 9, '#9 | Assembly --- ', 'Assembly --- ', 9000, 6, 0, 'TIME', -9),
(8, 10, '#10 | Assembly --- ', 'Assembly --- ', 10000, 6, 0, 'TIME', -10),
(8, 11, '#11 | Assembly --- ', 'Assembly --- ', 1, 6, -2, 'TIME', -11),
(9, 1, '#1 | 2-es számrendszer --- ', '2-es számrendszer --- ', 1000, 8, 0, 'TIME', -1),
(9, 2, '#2 | 2-es számrendszer --- ', '2-es számrendszer --- ', 2000, 8, 0, 'TIME', -2),
(9, 3, '#3 | 2-es számrendszer --- ', '2-es számrendszer --- ', 3000, 8, 0, 'TIME', -3),
(9, 4, '#4 | 2-es számrendszer --- ', '2-es számrendszer --- ', 5000, 8, 0, 'TIME', -4),
(9, 5, '#5 | 2-es számrendszer --- ', '2-es számrendszer --- ', 5000, 8, 0, 'TIME', -5),
(9, 6, '#6 | 2-es számrendszer --- ', '2-es számrendszer --- ', 6000, 8, 0, 'TIME', -6),
(9, 7, '#7 | 2-es számrendszer --- ', '2-es számrendszer --- ', 7000, 8, 0, 'TIME', -7),
(9, 8, '#8 | 2-es számrendszer --- ', '2-es számrendszer --- ', 8000, 8, 0, 'TIME', -8),
(9, 9, '#9 | 2-es számrendszer --- ', '2-es számrendszer --- ', 9000, 8, 0, 'TIME', -9),
(9, 10, '#10 | 2-es számrendszer --- ', '2-es számrendszer --- ', 10000, 8, 0, 'TIME', -10),
(9, 11, '#11 | 2-es számrendszer --- ', '2-es számrendszer --- ', 1, 8, -2, 'TIME', -11),
(10, 1, '#1 | 16-os számrendszer --- ', '16-os számrendszer --- ', 1000, 6, 0, 'TIME', -1),
(10, 2, '#2 | 16-os számrendszer --- ', '16-os számrendszer --- ', 2000, 6, 0, 'TIME', -2),
(10, 3, '#3 | 16-os számrendszer --- ', '16-os számrendszer --- ', 3000, 6, 0, 'TIME', -3),
(10, 4, '#4 | 16-os számrendszer --- ', '16-os számrendszer --- ', 5000, 6, 0, 'TIME', -4),
(10, 5, '#5 | 16-os számrendszer --- ', '16-os számrendszer --- ', 5000, 6, 0, 'TIME', -5),
(10, 6, '#6 | 16-os számrendszer --- ', '16-os számrendszer --- ', 6000, 6, 0, 'TIME', -6),
(10, 7, '#7 | 16-os számrendszer --- ', '16-os számrendszer --- ', 7000, 6, 0, 'TIME', -7),
(10, 8, '#8 | 16-os számrendszer --- ', '16-os számrendszer --- ', 8000, 6, 0, 'TIME', -8),
(10, 9, '#9 | 16-os számrendszer --- ', '16-os számrendszer --- ', 9000, 6, 0, 'TIME', -9),
(10, 10, '#10 | 16-os számrendszer --- ', '16-os számrendszer --- ', 10000, 6, 0, 'TIME', -10),
(10, 11, '#11 | 16-os számrendszer --- ', '16-os számrendszer --- ', 1, 6, -2, 'TIME', -11),
(11, 1, '#1 | PowerShell --- ', 'PowerShell --- ', 1000, 10, 0, 'TIME', -1),
(11, 2, '#2 | PowerShell --- ', 'PowerShell --- ', 2000, 10, 0, 'TIME', -2),
(11, 3, '#3 | PowerShell --- ', 'PowerShell --- ', 3000, 10, 0, 'TIME', -3),
(11, 4, '#4 | PowerShell --- ', 'PowerShell --- ', 5000, 10, 0, 'TIME', -4),
(11, 5, '#5 | PowerShell --- ', 'PowerShell --- ', 5000, 10, 0, 'TIME', -5),
(11, 6, '#6 | PowerShell --- ', 'PowerShell --- ', 6000, 10, 0, 'TIME', -6),
(11, 7, '#7 | PowerShell --- ', 'PowerShell --- ', 7000, 10, 0, 'TIME', -7),
(11, 8, '#8 | PowerShell --- ', 'PowerShell --- ', 8000, 10, 0, 'TIME', -8),
(11, 9, '#9 | PowerShell --- ', 'PowerShell --- ', 9000, 10, 0, 'TIME', -9),
(11, 10, '#10 | PowerShell --- ', 'PowerShell --- ', 10000, 10, 0, 'TIME', -10),
(11, 11, '#11 | PowerShell --- ', 'PowerShell --- ', 1, 10, -2, 'TIME', -11),
(12, 1, '#1 | Python --- ', 'Python --- ', 1000, 11, 0, 'TIME', -1),
(12, 2, '#2 | Python --- ', 'Python --- ', 2000, 11, 0, 'TIME', -2),
(12, 3, '#3 | Python --- ', 'Python --- ', 3000, 11, 0, 'TIME', -3),
(12, 4, '#4 | Python --- ', 'Python --- ', 5000, 11, 0, 'TIME', -4),
(12, 5, '#5 | Python --- ', 'Python --- ', 5000, 11, 0, 'TIME', -5),
(12, 6, '#6 | Python --- ', 'Python --- ', 6000, 11, 0, 'TIME', -6),
(12, 7, '#7 | Python --- ', 'Python --- ', 7000, 11, 0, 'TIME', -7),
(12, 8, '#8 | Python --- ', 'Python --- ', 8000, 11, 0, 'TIME', -8),
(12, 9, '#9 | Python --- ', 'Python --- ', 9000, 11, 0, 'TIME', -9),
(12, 10, '#10 | Python --- ', 'Python --- ', 10000, 11, 0, 'TIME', -10),
(12, 11, '#11 | Python --- ', 'Python --- ', 1, 11, -2, 'TIME', -11),
(13, 1, '#1 | Ajax --- ', 'Ajax --- ', 1000, 12, 0, 'TIME', -1),
(13, 2, '#2 | Ajax --- ', 'Ajax --- ', 2000, 12, 0, 'TIME', -2),
(13, 3, '#3 | Ajax --- ', 'Ajax --- ', 3000, 12, 0, 'TIME', -3),
(13, 4, '#4 | Ajax --- ', 'Ajax --- ', 5000, 12, 0, 'TIME', -4),
(13, 5, '#5 | Ajax --- ', 'Ajax --- ', 5000, 12, 0, 'TIME', -5),
(13, 6, '#6 | Ajax --- ', 'Ajax --- ', 6000, 12, 0, 'TIME', -6),
(13, 7, '#7 | Ajax --- ', 'Ajax --- ', 7000, 12, 0, 'TIME', -7),
(13, 8, '#8 | Ajax --- ', 'Ajax --- ', 8000, 12, 0, 'TIME', -8),
(13, 9, '#9 | Ajax --- ', 'Ajax --- ', 9000, 12, 0, 'TIME', -9),
(13, 10, '#10 | Ajax --- ', 'Ajax --- ', 10000, 12, 0, 'TIME', -10),
(13, 11, '#11 | Ajax --- ', 'Ajax --- ', 1, 12, -2, 'TIME', -11),
(14, 1, '#1 | jQuery --- ', 'jQuery --- ', 1000, 13, 0, 'TIME', -1),
(14, 2, '#2 | jQuery --- ', 'jQuery --- ', 2000, 13, 0, 'TIME', -2),
(14, 3, '#3 | jQuery --- ', 'jQuery --- ', 3000, 13, 0, 'TIME', -3),
(14, 4, '#4 | jQuery --- ', 'jQuery --- ', 5000, 13, 0, 'TIME', -4),
(14, 5, '#5 | jQuery --- ', 'jQuery --- ', 5000, 13, 0, 'TIME', -5),
(14, 6, '#6 | jQuery --- ', 'jQuery --- ', 6000, 13, 0, 'TIME', -6),
(14, 7, '#7 | jQuery --- ', 'jQuery --- ', 7000, 13, 0, 'TIME', -7),
(14, 8, '#8 | jQuery --- ', 'jQuery --- ', 8000, 13, 0, 'TIME', -8),
(14, 9, '#9 | jQuery --- ', 'jQuery --- ', 9000, 13, 0, 'TIME', -9),
(14, 10, '#10 | jQuery --- ', 'jQuery --- ', 10000, 13, 0, 'TIME', -10),
(14, 11, '#11 | jQuery --- ', 'jQuery --- ', 1, 13, -2, 'TIME', -11),
(15, 1, '#1 | Android --- ', 'Android --- ', 1000, 14, 0, 'TIME', -1),
(15, 2, '#2 | Android --- ', 'Android --- ', 2000, 14, 0, 'TIME', -2),
(15, 3, '#3 | Android --- ', 'Android --- ', 3000, 14, 0, 'TIME', -3),
(15, 4, '#4 | Android --- ', 'Android --- ', 5000, 14, 0, 'TIME', -4),
(15, 5, '#5 | Android --- ', 'Android --- ', 5000, 14, 0, 'TIME', -5),
(15, 6, '#6 | Android --- ', 'Android --- ', 6000, 14, 0, 'TIME', -6),
(15, 7, '#7 | Android --- ', 'Android --- ', 7000, 14, 0, 'TIME', -7),
(15, 8, '#8 | Android --- ', 'Android --- ', 8000, 14, 0, 'TIME', -8),
(15, 9, '#9 | Android --- ', 'Android --- ', 9000, 14, 0, 'TIME', -9),
(15, 10, '#10 | Android --- ', 'Android --- ', 10000, 14, 0, 'TIME', -10),
(15, 11, '#11 | Android --- ', 'Android --- ', 1, 14, -2, 'TIME', -11);