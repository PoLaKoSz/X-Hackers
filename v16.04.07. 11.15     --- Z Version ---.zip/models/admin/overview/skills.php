<?php

class SkillsDB extends DataBase
{
	protected $skill_id;
	protected $skill_level;
	protected $skill_description;
	protected $skill_tooltip;
	
	public function __construct() {}
	
	public function getSkills()
	{
		$this->connect();
			$result= $this->query("
			SELECT
				skill_table.skill_id,skill_table.skill_level,skill_table.skill_tooltip,skill_table.skill_description,skill_table.skill_level AS SK_next_level, skill_table.price,
				skill_table.requirement_skill_level, skill_table.changing, skill_table.changing_value
			FROM skill_table
			LEFT JOIN account_skills ON skill_table.skill_id = account_skills.skill_id AND skill_table.skill_level = account_skills.skill_level + 1
			LEFT JOIN skill_list ON skill_table.skill_id = skill_list.skill_id
			ORDER BY skill_list.order ASC, skill_table.skill_level ASC
			");
		$this->close();
		return $result;
	}
	
	public function updateSkill( $skill_id, $skill_level, $skill_description, $skill_tooltip )
	{
		$this->connect();

			$this->skill_id = $this->escape( $skill_id );
			$this->skill_level = $this->escape( $skill_level );
			$this->skill_description = $this->escape( $skill_description );
			$this->skill_tooltip = $this->escape( $skill_tooltip );

			$result = $this->query("
			UPDATE skill_table SET
				skill_tooltip = '" . $this->skill_tooltip . "', skill_description = '" . $this->skill_description . "'
			WHERE skill_id = " . $this->skill_id . " AND skill_level = " . $this->skill_level . "
			LIMIT 1
			");

		$this->close();

		return $result;
	}
}