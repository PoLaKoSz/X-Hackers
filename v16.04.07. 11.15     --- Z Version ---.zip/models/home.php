<?php

class HomeDB extends DataBase
{
	public function __construct() {}

	public function getNews()
	{
		$this->connect();

			$result = $this->query("SELECT * FROM news WHERE date > DATE_SUB(now(), INTERVAL 2 MONTH) ORDER BY date DESC");

		$this->close();

		return $result;
	}
}