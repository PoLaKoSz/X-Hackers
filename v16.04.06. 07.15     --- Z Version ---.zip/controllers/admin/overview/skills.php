<?php

class Skills
{
	public function __construct()
	{
		print_r($_POST);
		require_once 'models/admin/overview/skills.php';
		$db = new SkillsDB;
			if ( isset( $_POST['skill_id'] ) && isset( $_POST['skill_description'] ) && isset( $_POST['tooltip'] ) )
			{
				echo "POSTolunk";
				
			}
		$skill_result = $db->getSkills();
		require_once 'views/admin/overview/skills.php';
	}
}