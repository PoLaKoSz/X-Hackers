<?php

class Missions
{
	public function __construct ()
	{
		require_once 'views/work/missions.php';
	}
}