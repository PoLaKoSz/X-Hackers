<form action="index.php?url=profile" method="POST" class="content_center horizontal_center small-table">
	<div class="cell-6 fLeft teszt1">
    	Hacker név:
	</div>
	<div class="cell-6 fLeft teszt2">
		<input type="text" name="hacker_name">
	</div>
	
	<div class="clear"></div>

	<input type="submit" value="Mentés">
</form>