<?php

class RegistrationDB extends DataBase
{
	private $username;

	private $password;

	private $email;

	public function __construct( $username, $password, $email  )
	{
		$this->connect();

			$this->username = $this->escape( $username );
			$this->password = $this->escape( $password );
			$this->email = $this->escape( $email );
	}

	public function checkFreeUserName()
	{
			$result = $this->query("SELECT id FROM accounts WHERE username LIKE '" . $this->username . "' LIMIT 1")->num_rows;

		$this->close();

		return $result;
	}

	public function createUser()
	{
		$this->connect();

			$result = $this->query("INSERT INTO accounts VALUES ('', '" . $this->username . "', PASSWORD('" . $this->password . "'), '" . $this->email . "', '', 1, '', NOW())");
			
		$this->close();

		return $result;
	}
}