var width = $(window).width();
var visible_tooltip;

$(window).resize(function(){width = $(window).width();});

$('.nice-table .tooltip').click(function()
{
	if ( visible_tooltip == null)
	{
		$(this).parent().parent().find('.content').css("display","block");

		visible_tooltip = $(this).parent().parent().attr("data-id");

		return false;
	}

	$("div[data-id="+visible_tooltip+"]").find('.content').css("display","none");

	visible_tooltip = $(this).parent().parent().attr("data-id");

	$(this).parent().parent().find('.content').css("display","block");
});

$('.nice-table .content').click(function()
{
	if ( width >= 830)
	{
		$(this).css("display","none");
	}
});

$('.nice-table .title').click(function()
{
	if ( visible_tooltip == null)
	{
		visible_tooltip = $(this).parent().parent().attr("data-id");
		
		$(this).parent().parent().children('.content').animate({"height" : $(this).height()+50}, 400).css("display","block");
		return false;
	}
	
	$("div[data-id="+visible_tooltip+"]").find('.content').animate({"height" : 0}, 400).css("color","transparent");

	visible_tooltip = $(this).parent().parent().attr("data-id");

	$(this).parent().parent().children('.content').animate({"height" : $(this).height()+50}, 400).css({"display":"block","color":"white"});
});

$('.nice-table .edit').click(function()
{
	$(this).each(function() {
		$('input[type=text]').attr("disabled", false).css("background-color", "green");
	});
	alert("sjdjdj");
});