<?php

class Hardwares
{
	public function __construct ()
	{
		require_once 'models/overview/hardwares.php';
			$hardwares = new HardwaresDB;

			if ( isset( $_POST['hardware_id'] ) )
			{
				if ( $this->checkHardware( $hardwares, $_POST['hardware_id'] ) )
				{
					$this->updateHardware( $hardwares, $_POST['hardware_id'] );
				}
			}

			$hardware_result = $hardwares->gethardwares();
		require_once 'views/overview/hardwares.php';								// továbbirányítás a megfelelő oldalra
	}

	protected function checkHardware( $hardwares, $hardware_id )
	{
		if ( $result = $hardwares->gethardwarePrice( $hardware_id ) )
		{
			if ( $result['price'] < $_SESSION['current_money'] )
			{
				return true;
			}
		}
		return false;
	}

	protected function updateHardware( $hardwares, $hardware_id )
	{
		$hardwares->upgradehardware( $hardware_id );
	}
}