<?php

class Skills
{
	public function __construct ()
	{
		include_once 'models/overview/skills.php';
		
		$skills = new SkillsDB;

		if ( isset( $_POST['skill_id'] ) )
		{
			if ( $this->checkSkill( $skills, $_POST['skill_id'] ) )
			{
				$this->updateSkill( $skills, $_POST['skill_id'] );
			}
		}
		else if ( isset( $_POST['language_id'] ) )
		{
			if ( $this->checkLanguage( $skills, $_POST['language_id'] ) )
			{
				$this->updateLanguage( $skills, $_POST['language_id'] );
			}
		}

			$skill_result = $skills->getSkills();

			$language_result = $skills->getLanguages();

		require_once 'views/overview/skills.php';								// továbbirányítás a megfelelő oldalra
	}

	protected function checkSkill( $skills, $skill_id )
	{
		if ( $result = $skills->getSkillPrice( $skill_id ) )
		{
			if ( $result['price'] < $_SESSION['current_money'] )
			{
				return true;
			}
		}
		return false;
	}

	protected function updateSkill( $skills, $skill_id )
	{
		$skills->upgradeSkill( $skill_id );
	}

	protected function checkLanguage( $DB, $language_id )
	{
		if ( $result = $DB->getLanguagePrice( $language_id ) )
		{
			if ( $result['price'] < $_SESSION['current_money'] )
			{
				return true;
			}
		}
		return false;
	}

	protected function updateLanguage( $DB, $language_id )
	{
		$DB->upgradeLanguage( $language_id );
	}
}