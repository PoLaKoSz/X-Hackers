<?php

class FormValidating
{
	protected $string;

	protected $min;

	protected $max;

	public function __construct() {}

	protected function checkLength()						//	meglegyen a kellő hossz, illetve ne legyen több
	{
		if ( strlen( $this->string ) < $this->min || strlen( $this->string ) > $this->max )
		{
			return false;
		}
		return true;
	}

	protected function checkChars()						//	csak a megengedett karakterek szerepelhessenek benne
	{
		if ( !preg_match("/^[a-zA-ZáéíóöőúüűÁÉÍÓÖŐÚÜŰ0-9]*$/", $this->string ) )
		{
			return false;
		}
		return true;
	}
}