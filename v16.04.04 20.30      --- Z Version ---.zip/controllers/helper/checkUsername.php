<?php

class checkUsername extends FormValidating
{
	public function __construct( $string )
	{
		$this->string = $string;
		$this->min = 5;
		$this->max = 20;
	}

	public function checking()
	{
		if ( !$this->checkLength() )
		{
			return false;
		}
		if ( !$this->checkChars() )
		{
			return false;
		}
		return true;
	}
}