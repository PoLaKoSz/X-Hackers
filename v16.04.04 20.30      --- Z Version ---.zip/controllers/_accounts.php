<?php

class Accounts
{
	public function __construct()
	{
		include_once 'models/accounts.php';				// mint pl. Android-nál az import package
		
		$db = new AccountsDB;							// példányosítás, a konstruktor meghívása
		$result = $db->getAccountsList();				// accounts tábla kilistázása, az accounts modellen keresztül, ami a DataBase osztályból van származtatva
		$db->close();
		
		include_once 'views/accounts.php';
	}
}