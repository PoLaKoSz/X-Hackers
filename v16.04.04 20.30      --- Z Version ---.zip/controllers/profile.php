<?php

class Profile
{
	public function __construct()
	{
		if ( isset( $_POST['hacker_name'] ) && strlen( $_POST['hacker_name'] ) > 0 )
		{
			include_once 'models/profile.php';
			$db = new ProfileDB( $_POST['hacker_name'] );
			$db->changeHackerName();
		}

		include_once 'views/profile.php';
	}
}