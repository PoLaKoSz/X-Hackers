<ul>
	<a href="index.php?url=admin/overview/skills"><li>Skill lista</li></a>
</ul>