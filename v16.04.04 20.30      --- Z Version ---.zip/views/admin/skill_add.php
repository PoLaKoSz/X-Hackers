<table class="nice-table">
	<tr>
		<td> # </td>
		<td>skill_id</td>
		<td>skill_level</td>
		<td>skill_tooltipp</td>
		<td>skill_description</td>
	</tr>
	<tr>
		<td>
			<select name="order">
				<option name=1 value="Bevezető">
				<option name=2 value="HTML">
			</select>
			<select name="position">
				<option name="before" value="elé">
				<option name="after" value="után">
			</select>
		</td>
		<td><input type="text" name="skill_level"></td>
		<td><textarea name="skill_tooltipp"></textarea></td>
		<td><textarea name="skill_description"></textarea></td>
	</tr>
</table>
<input type="submit" name="add_skill" value="Hozzáad">