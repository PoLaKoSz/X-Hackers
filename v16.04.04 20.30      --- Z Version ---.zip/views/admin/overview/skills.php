<h3>Képességek</h3>
<div class="nice-table">
	<?php
		while ( $row = $skill_result->fetch_assoc() )
		{
			echo '
			<form action="index.php?url=admin/overview/skills" method="POST">
				<div id="container" data-id="' . $row['skill_id'] . '">
					<input type="text" hidden name="skill_id" value="' . $row['skill_id'] . '">
						<div class="m_top_title"><div><input type="text" disabled name="skill_description" value="' . $row['skill_description'] . '"></div> # ' . $row['SK_next_level'] . '<div class="edit">_______edit______</div><div class="title">_____open_____</div><input type="submit" value="Mentes"></div>
					<div class="row-1">( <a class="tooltip"> ? </a>) | ' . $row['skill_description'] . '</div>
					<div class="content"><input type="text" disabled name="tooltip" value="' . $row['skill_tooltip'] . '"></div>
						<div class="m_details"><p>' . $row['price'] . ' Ft</p><p>342 EXP</p><p>73 sec</p></div>
					<div class="row-2"><img src="images/' . $row['changing'] . '.png" alt="' . $row['changing'] . '" title="' . $row['changing'] . '">' . $row['changing_value'] . ' # ' . $row['SK_next_level'] . '</div>
				</div>
			</form>
			';
		}
	?>
</div>