<html>
	<head>
		<title>X-Hackers</title>
		
		<link rel="stylesheet" type="text/css" href="./css/default_design.css">
		<link rel="stylesheet" type="text/css" href="./css/min_830px_style.css">
		
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />
		
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	</head>
	
	<body>
		<div id="LoginRegPanel" class="full_center">
			<a href="index.php?url=login"><div class="menu_button login noselect">Belépés</div></a>
			<a href="#"><div class="menu_button reg noselect active">Regisztráció</div></a>
			
			<div class="clear"></div>
			
			<div id="regTartalom" class="loginBox borderedBox">
				<div class="<?php echo $this->status; ?>"><?php echo $this->message; ?></div>
				<form method="POST" action="index.php?url=registration">
					<label>
						Felhasználónév<br>
						<input type="text" name="username" value="PoLáKoSz" placeholder="a-Z, 0-9, ékezet, min. 5 max 20 karakter" maxlength="20"><br>
					</label>
					<label>
						Jelszó<br>
						<input type="password" name="password" value="admin" placeholder="a-Z, 0-9, ékezet, min. 5 max 20 karakter" maxlength="20"><br>
					</label>
					<label>
						E-mail<br>
						<input type="text" name="email" value="polakosz@freemail.hu" placeholder="max. 50 karakter" maxlength="50"><br>
					</label>
					
					<label>
						<input type="checkbox" checked>A regisztrációval elfogadod a <a href="#">Felhasználási feltételeket</a>!<br>
					</label>
					
					<input type="submit" name="registration" value="Regisztráció">
				</form>
			</div>
		</div>
		
		<script src="./js/jquery-2.2.0.min.js"></script>
		<script src="./js/loginPanel.js"></script>
		<script src="./js/validate.js"></script>
	</body>
</html>