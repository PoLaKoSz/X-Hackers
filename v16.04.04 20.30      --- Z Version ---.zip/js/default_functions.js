function popUpErrorMessage(errorCode) {
	alert("Hibakód: "+errorCode+" \n\n(kérlek küldd tovább az oldal adminjának a körülményekkel együtt!).");
}