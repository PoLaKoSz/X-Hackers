<?php

	session_start();
	error_reporting(E_ALL);
	header("Content-Type: text/html; charset=utf-8");
	
	$_SESSION['account_id'] = 1;$_SESSION['current_level'] = 38;$_SESSION['current_exp'] = 484848;$_SESSION['full_exp'] = 7474844;$_SESSION['current_money'] = 74893;$_SESSION['status'] = 0;$_SESSION['computer_id'] = 2;$_SESSION['sum_EXP_bon'] =474;$_SESSION['sum_TIME_bon'] =148;

	include_once 'models/database.php';				// mint pl. Android-nál az import package
	# csak azért példányosítunk, hogyha nincs szerver, akkor ne töltsön be tovább az oldal
	$db = new DataBase;
	$db->close();									// DB kapcsolat bezárása




	include_once 'DB_2_SQL_lib.php';
	$db = new ExportImport();
	$db->exportSQL( 'sql/mobil_xHackers_' . date("Y_m_d__H") );
	//$db->importSQL( 'sql/mobil_xHackers_2016_04_27__11.sql' );




	include_once 'core/Functions.php';				// mint pl. Android-nál az import package

	include_once 'core/Controller.php';				// mint pl. Android-nál az import package
	$controller = new Controller;					// példányosítás, a konstruktor meghívása