<?php

class HardwaresDB extends DataBase
{
	public function __construct() {}

	public function getHardwares()
	{
		$this->connect();
			$result = $this->query(
			"
			SELECT
				hardware_table.hardware_id,hardware_table.hardware_tooltip,hardware_table.hardware_description, account_hardwares.hardware_level AS SK_curr_level,hardware_table.hardware_level AS SK_next_level, hardware_table.price,
				hardware_table.requirement_hardware_level, hardware_table.changing, hardware_table.changing_value
			FROM hardware_table
			LEFT JOIN account_hardwares ON hardware_table.hardware_id = account_hardwares.hardware_id AND hardware_table.hardware_level = account_hardwares.hardware_level + 1
			LEFT JOIN hardware_list ON hardware_table.hardware_id = hardware_list.hardware_id
			WHERE account_hardwares.account_id = " . $_SESSION['account_id'] . " OR account_hardwares.account_id IS NULL AND hardware_table.requirement_hardware <= (SELECT COALESCE(MAX(hardware_id), 0) FROM account_hardwares)
			GROUP BY hardware_list.order
			");

		$this->close();

		return $result;
	}

	public function getHardwarePrice( $hardware_id )
	{
		$this->connect();
		
			$result = $this->query(
			"
			SELECT
				price
			FROM hardware_table
			LEFT JOIN account_hardwares ON hardware_table.hardware_id = account_hardwares.hardware_id
			WHERE hardware_table.hardware_id = " . $hardware_id . " AND hardware_table.hardware_level = COALESCE(account_hardwares.hardware_level + 1, 1)
			LIMIT 1
			")->fetch_assoc();

		$this->close();

		return $result;
	}

	public function upgradeHardware( $hardware_id )
	{
		$this->connect();
			$result = $this->query("CALL updateHardware(" . $_SESSION['account_id'] . ", " . $hardware_id . ");");

		$this->close();

		return $result;
	}
}