<?php

class LoginDB extends DataBase
{
	private $username;
	private $password;

	public $account_id;
	public $current_level;
	public $current_exp;
	public $full_exp;
	public $current_money;
	public $status;
	public $computer_id;
	public $sum_EXP_bon;
	public $sum_TIME_bon;

	public function __construct( $username, $password )
	{
		$this->connect();

			$this->username = $this->escape( $username );
			$this->password = $this->escape( $password );
	}

	public function logIn()
	{
			$result = $this->query("
			SELECT
				accounts.id, accounts.current_level, accounts.current_exp,
				levels.exp AS full_exp,
				accounts.current_money, accounts.status, accounts.computer_id
			FROM accounts
			LEFT JOIN levels ON accounts.current_level = levels.level
			WHERE username LIKE '" . $this->username . "' AND password LIKE PASSWORD( '" . $this->password . "' )
			LIMIT 1
			")->fetch_assoc();

			$sum_EXP = $this->query("
			SELECT
				SUM(
					COALESCE((
						SELECT
							SUM(skill_table.changing_value)
						FROM account_skills
						LEFT JOIN skill_table ON account_skills.skill_id = skill_table.skill_id AND account_skills.skill_level = skill_table.skill_level
						WHERE account_skills.account_id = " . $result['id'] . " AND skill_table.changing = 'EXP'
						GROUP BY skill_table.changing
					), 0) +
					COALESCE((
						SELECT
							SUM(language_table.changing_value)
						FROM account_languages
						LEFT JOIN language_table ON account_languages.language_id = language_table.language_id AND account_languages.language_level = language_table.language_level
						WHERE account_languages.account_id = " . $result['id'] . " AND language_table.changing = 'EXP'
						GROUP BY language_table.changing
					), 0)
				) AS oszes_EXP
			")->fetch_assoc();

			$sum_TIME = $this->query("
			SELECT
				SUM(
					COALESCE((
						SELECT
							SUM(skill_table.changing_value)
						FROM account_skills
						LEFT JOIN skill_table ON account_skills.skill_id = skill_table.skill_id AND account_skills.skill_level = skill_table.skill_level
						WHERE account_skills.account_id = " . $result['id'] . "  AND skill_table.changing = 'TIME'
						GROUP BY skill_table.changing
					), 0) +
					COALESCE((
						SELECT
							SUM(language_table.changing_value)
						FROM account_languages
						LEFT JOIN language_table ON account_languages.language_id = language_table.language_id AND account_languages.language_level = language_table.language_level
						WHERE account_languages.account_id = " . $result['id'] . " AND language_table.changing = 'TIME'
						GROUP BY language_table.changing
					), 0)
				) AS oszes_TIME
			")->fetch_assoc();

		$this->close();
		
			if ( !$result || !$sum_EXP || !$sum_TIME )
			{
				return false;
			}

		$this->account_id = $result['id'];
		$this->current_level = $result['current_level'];
		$this->current_exp = $result['current_exp'];
		$this->full_exp = $result['full_exp'];
		$this->current_money = $result['current_money'];
		$this->status = $result['status'];
		$this->computer_id = $result['computer_id'];

		$this->sum_EXP_bon = $sum_EXP['oszes_EXP'];
		$this->sum_TIME_bon = $sum_TIME['oszes_TIME'];
		
		return true;
	}
}