<?php

class SkillListDB extends DataBase
{
	public function __construct() {}

	# nincs ESCAPE-elve!!!
	public function getSkillsList( $skill_id, $skill_level, $price, $requirement_skill, $requirement_skill_level, $changing, $changing_value, $order_by )
	{

		if ( $skill_id == null )
			$skill_id = "1 OR 1 = 1";						//	ha 'null' van megadva, akkor egy inject szerű értéket ad neki, és így nem veszi figyelembe az adott WHERE statement-et

		if ( $skill_level == null )
			$skill_level = "1 OR 1 = 1";					//	ha 'null' van megadva, akkor egy inject szerű értéket ad neki, és így nem veszi figyelembe az adott WHERE statement-et

		if ( $price == null )
			$price = "1 OR 1 = 1";							//	ha 'null' van megadva, akkor egy inject szerű értéket ad neki, és így nem veszi figyelembe az adott WHERE statement-et

		if ( $requirement_skill == null )
			$requirement_skill = "1 OR 1 = 1";							//	ha 'null' van megadva, akkor egy inject szerű értéket ad neki, és így nem veszi figyelembe az adott WHERE statement-et

		if ( $requirement_skill_level == null )
			$requirement_skill_level = "1 OR 1 = 1";							//	ha 'null' van megadva, akkor egy inject szerű értéket ad neki, és így nem veszi figyelembe az adott WHERE statement-et

		if ( $changing == null )
			$changing = "' OR 1 = 1) AND ('' = '";							//	ha 'null' van megadva, akkor egy inject szerű értéket ad neki, és így nem veszi figyelembe az adott WHERE statement-et

		if ( $changing_value == null )
			$changing_value = "1 OR 1 = 1";							//	ha 'null' van megadva, akkor egy inject szerű értéket ad neki, és így nem veszi figyelembe az adott WHERE statement-et

		if ( $order_by == null )
			$order_by = "skill_list.order ASC, skill_table.skill_level ASC";

		$this->connect();

			$result = $this->query("
									SELECT
										skill_table.*
									FROM skill_table
									LEFT JOIN skill_list ON skill_table.skill_id = skill_list.skill_id
									WHERE
										( skill_table.skill_id = " . $skill_id . " ) AND
										( skill_table.skill_level = " . $skill_level . " ) AND
										( skill_table.price = " . $price . " ) AND
										( skill_table.requirement_skill = " . $requirement_skill . " ) AND
										( skill_table.requirement_skill_level = " . $requirement_skill_level . " ) AND
										( skill_table.changing = '" . strtoupper( $changing ) . "' ) AND
										( skill_table.changing_value = " . $changing_value . " )
									ORDER BY " . $order_by
									);

		$this->close();

		return $result;
	}

	public function updateOneRow( $skill_id, $skill_level, $skill_tooltip, $skill_description, $price, $requirement_skill, $requirement_skill_level, $changing, $changing_value )
	{
		$this->connect();

			$skill_id = $this->escape( $skill_id );
			$skill_level = $this->escape( $skill_level );
			$price = $this->escape( $price );
			$requirement_skill = $this->escape( $requirement_skill );
			$requirement_skill_level = $this->escape( $requirement_skill_level );
			$changing = $this->escape( $changing );
			$changing_value = $this->escape( $changing_value );

			$result = $this->query("
									UPDATE skill_table
									SET
										skill_tooltip = " . $skill_tooltip . ",
										skill_description = " . $skill_description . ",
										price = " . $price . ",
										requirement_skill = " . $requirement_skill . ",
										requirement_skill_level = " . $requirement_skill_level . ",
										changing = " . $changing . ",
										changing_value = " . $changing_value . ",
									WHERE skill_id = " . $skill_id . " AND skill_level = " . $skill_level . " LIMIT 1
									");

		$this->close();

		return $result;
	}
}