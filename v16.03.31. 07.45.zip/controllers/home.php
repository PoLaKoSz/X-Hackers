<?php

class Home
{
	public function __construct ()
	{
		require_once 'models/home.php';
		
			$db = new HomeDB;
			$result = $db->getNews();

		require_once 'views/home.php';								// továbbirányítás a megfelelő oldalra
	}
}