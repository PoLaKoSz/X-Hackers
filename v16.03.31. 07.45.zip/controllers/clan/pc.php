<?php

class PC
{
	public function __construct()
	{
		require_once 'views/clan/pc.php';
	}
}