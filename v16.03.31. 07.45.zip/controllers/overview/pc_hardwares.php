<?php

class PC_Hardwares
{
	public function __construct ()
	{
		$list = array(
			0 => "Alaplap",
			1 => "CPU",
			2 => "Ram",
			3 => "Videókártya",
			4 => "Hálózati kártya",
			5 => "HDD",
			6 => "SSD",
			7 => "XY Router"
		);
		
		require_once 'views/overview/pc_hardwares.php';								// továbbirányítás a megfelelő oldalra
	}
}