<?php

function checkLoggedIn()
{
	if ( !isset( $_SESSION['status'] ) )
	{
		return false;
	}
	if ( $_SESSION['status'] < 0 )
	{
		return false;
	}
	if ( !isset( $_SESSION['account_id'] ) )
	{
		return false;
	}
	return true;
}

function formatInt( $int )
{
	return number_format($int, 0, ',', ' ');
}