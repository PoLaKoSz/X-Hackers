<?php
/*
      ugy kene megcsinalni, hogy csak olyan kuldik legyenek itt, amik az account_skill-ben is benne van(nak)

      lista betöltése account_id-vel megjelölve egy ideiglenes táblába, és amint újratölti az oldalt, törli az előzőt, illetve belerakja az újat
*/
?>
<!--
<form action="#" method="POST">
	<table class="nice-table">
		<tr>
			<td>Munkaadó</td>
			<td>Leírás</td>
			<td>EXP</td>
			<td>Pénz</td>
			<td>Folyamat hossza</td>
			<td> </td>
		</tr>
		<tr>
			<td>Munkaadó</td>
			<td>Leírás</td>
			<td>EXP</td>
			<td>Pénz</td>
			<td>Folyamat hossza</td>
			<td><input type="button" name="ID_JÖN_IDE"></button></td>
		</tr>
	</table>
</form>
-->
<h3>Munkák</h3>
<div class="nice-table">
	<?php
		while ( $row = $job_result->fetch_assoc() )
		{
			if ( $row['requirement_skill_level'] == -2)    // <--- ezt atirni arra, amivel jelolni fogom a befejezett munkakat
			{
				$imgORUpgrade = "<img src='images/tick.png' class='status'>";
			}
			else
			{
				$imgORUpgrade = '<input type="submit" ' . $disable . ' name="' . $row['skill_id'] . '" value="' . formatInt( $row['price'] ) .'Ft">';
			}
			
			echo '
			<form action="index.php?url=overview/skills" method="POST">
				<div id="container" data-id="' . $row['skill_id'] . '">
					<input type="text" hidden name="skill_id" value="' . $row['skill_id'] . '">
					<div class="m_top_title"><div class="title">' . $row['SK_curr_level'] . ' -> ' . $row['SK_next_level'] . ' | ' . $row['skill_description'] . '</div>' . $imgORUpgrade . '</div>
					<div class="row-1">( <a class="tooltip"> ? </a>) | ' . $row['SK_curr_level'] . ' -> ' . $row['SK_next_level'] . ' | ' . $row['skill_description'] . '</div>
					<div class="content">' . $row['skill_tooltip'] . '</div>
					<div class="m_details"><p>30.000 Ft</p><p>592 EXP</p><p>84 sec</p></div>
					<div class="row-2"><img src="images/' . $row['changing'] . '.png" alt="' . $row['changing'] . '" title="' . $row['changing'] . '">' . $row['changing_value'] . ' ' . $imgORUpgrade . '</div>
				</div>
			</form>
			';
		}
	?>
</div>
<!--
CREATE TABLE IF NOT EXISTS `jobs` (
  `account_id` mediumint(8) unsigned NOT NULL,
  `job_id` mediumint(8) unsigned NOT NULL,
  `employer` tinyint(3) unsigned NOT NULL,
  `description_id` tinyint(3) unsigned NOT NULL,
  `money` mediumint(8) unsigned NOT NULL,
  `time` datetime NOT NULL COMMENT 'munka teljesitesenek ideje',
  `exp` smallint(5) unsigned NOT NULL,
  `generated_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

CREATE TABLE IF NOT EXISTS `job_finished` (
  `job_id` smallint(5) unsigned NOT NULL,
  `deadline` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

        10 feladatot general (account_id, job_id, megrendelo, tooltip, money, time, EXP, generated_time
        job_finish TABLE (job_id, deadline)
        
        profilban lesz egy opcio, hogy munkak 5percenkenti automatikus frissitese
        
        SQL procedure:
             torli az 5 percnel regebbi generated_time-mal rendelkezo accounthoz tartozo kuldiket
             lekerdezi a jobs_finish tablaval osszefesult jobs tabla tartalmat account_id-vel szurve
             ha ez kevesebb, mint 10, akkor generalnia kell
        
        ( ? ) -ben lesz a feladat leirasa: pl.: segits egy baratodnak weblapot kesziteni
        ( ? ) Cegnev       20.000Ft     TIME 10perc    EXP 500   Elfogad (button) IMG kuka (feladat torlese)
                 ha mar visszaszamol (dolgozik, akkor legyen egy kuka jel a munka megszakitasahoz (elkezdi a munkat, feluton abbahagyja, meg benne marad a listaban, de visszaszamol, mert addig el a munka szamara