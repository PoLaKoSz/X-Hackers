<form action="index.php?url=clan" method="POST">
	Add meg a Klán nevét: <input type="text" name="clan_name">
	<input type="submit" name="clan" value="Létrehozás">
</form>