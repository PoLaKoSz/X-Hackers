<link rel="stylesheet" href="css/jquery-ui.css">
<script src="http://code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
<script>
	$(function() {
		$( "#accordion" ).accordion({
			heightStyle: "content"
		});
	});
</script>

<div id="accordion">
<?php
	while ( $row = $result->fetch_assoc() )
	{
		$title = array_slice( explode(" ", $row['text']), 0, 3);
		echo "<h6 class='clearfix'>".$title[0]." ".$title[1]." ".$title[2]."... <span class='fRight'>".$row['date']."</span></h6><div><p>".$row['text']."</p></div>";
	}
?>
</div>