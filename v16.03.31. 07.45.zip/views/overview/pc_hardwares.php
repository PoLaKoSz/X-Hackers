<table class="nice-table">
				<tr>
					<td>Hardver név</td>
					<td>Fejleszt</td>
				</tr>
			<?php
				foreach($list as $item) {
					echo "<tr><td class='padding-left'>(<a href='#' class='tip'>?</a>) ".$item."</td>
							  <td><button>20,000Ft</button></td>
						 </tr>";
				}
			?>
			</table>
			<style>
			input[type="checkbox"], #tipp {
				display: none;
			}

			#tipp {
				position: absolute;
			    max-width: 300px;
			    height: 100px;
			    background: black;
			    color: white;
			    margin: -20px 0 0 14px;
			}

			.ani {
				width: 10px;
				height: 20px;
				background: red;
				display: block;
			}

			input[type="checkbox"]:checked + #tipp {
				display: block;
			}
			</style>

			<div>
				(<label class="ani" for="efghbfhbf">?</label>)
				<input type="checkbox" id="efghbfhbf">
				<div id="tipp" class="borderedBox">Lorem ipsum dolorez száncsez</div>
			</div>

			<div>
				(<label class="ani" for="efghbfhbf123123saf">?</label>)
				<input type="checkbox" id="efghbfhbf123123saf">
				<div id="tipp" class="borderedBox">Lorem ipsum dolorez száncsez</div>
			</div>