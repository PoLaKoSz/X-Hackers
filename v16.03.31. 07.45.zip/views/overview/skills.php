<h3>Képességek</h3>
<div class="nice-table">
	<?php
		while ( $row = $skill_result->fetch_assoc() )
		{
			if ( $_SESSION['current_money'] < $row['price'] )
			{
				$disable = 'disable';
			}

			if ( $row['requirement_skill_level'] == -2)
			{
				$imgORUpgrade = "<img src='images/tick.png' class='status'>";
			}
			else
			{
				$imgORUpgrade = '<input type="submit" ' . $disable . ' name="' . $row['skill_id'] . '" value="' . formatInt( $row['price'] ) .'Ft">';
			}
			
			echo '
			<form action="index.php?url=overview/skills" method="POST">
				<div id="container" data-id="' . $row['skill_id'] . '">
					<input type="text" hidden name="skill_id" value="' . $row['skill_id'] . '">
					<div class="m_top_title"><div class="title">' . $row['SK_curr_level'] . ' -> ' . $row['SK_next_level'] . ' | ' . $row['skill_description'] . '</div>' . $imgORUpgrade . '</div>
					<div class="row-1">( <a class="tooltip"> ? </a>) | ' . $row['SK_curr_level'] . ' -> ' . $row['SK_next_level'] . ' | ' . $row['skill_description'] . '</div>
					<div class="content">' . $row['skill_tooltip'] . '</div>
					<div class="m_details"><p>30.000 Ft</p><p>592 EXP</p><p>84 sec</p></div>
					<div class="row-2"><img src="images/' . $row['changing'] . '.png" alt="' . $row['changing'] . '" title="' . $row['changing'] . '">' . $row['changing_value'] . ' ' . $imgORUpgrade . '</div>
				</div>
			</form>
			';
		}
	?>
</div>

<br>
<br>
<br>

<h3>Nyelvek</h3>
<div class="nice-table">
	<?php
		while ( $row = $language_result->fetch_assoc() )
		{
			if ( $_SESSION['current_money'] < $row['price'] )
			{
				$disable = 'disable';
			}

			if ( $row['requirement_language_level'] == -2)
			{
				$imgORUpgrade = "<img src='images/tick.png' class='status'>";
			}
			else
			{
				$imgORUpgrade = '<input type="submit" ' . $disable . ' name="' . $row['language_id'] . '" value="' . formatInt( $row['price'] ) .'Ft">';
			}
			
			echo '
			<form action="index.php?url=overview/languages" method="POST">
				<div id="container" data-id="' . $row['language_id'] . '">
					<input type="text" hidden name="language_id" value="' . $row['language_id'] . '">
					<div class="m_top_title"><div class="title">' . $row['SK_curr_level'] . ' -> ' . $row['SK_next_level'] . ' | ' . $row['language_description'] . '</div>' . $imgORUpgrade . '</div>
					<div class="row-1">( <a class="tooltip"> ? </a>) | ' . $row['SK_curr_level'] . ' -> ' . $row['SK_next_level'] . ' | ' . $row['language_description'] . '</div>
					<div class="content">TOOLTIP</div>
					<div class="m_details"><p>30.000 Ft</p><p>592 EXP</p><p>84 sec</p></div>
					<div class="row-2"><img src="images/' . $row['changing'] . '.png" alt="' . $row['changing'] . '" title="' . $row['changing'] . '">' . $row['changing_value'] . ' ' . $imgORUpgrade . '</div>
				</div>
			</form>
			';
		}
	?>
</div>

<script>
	var width = $(window).width();
	var visible_tooltip;

	$(window).resize(function(){width = $(window).width();});

	$('.nice-table .tooltip').click(function()
	{
		if ( visible_tooltip == null)
		{
			$(this).parent().parent().find('.content').css("display","block");

			visible_tooltip = $(this).parent().parent().attr("data-id");

			return false;
		}

		$("div[data-id="+visible_tooltip+"]").find('.content').css("display","none");

		visible_tooltip = $(this).parent().parent().attr("data-id");

		$(this).parent().parent().find('.content').css("display","block");
	});

	$('.nice-table .content').click(function()
	{
		if ( width >= 830)
		{
			$(this).css("display","none");
		}
	});

	$('.nice-table .title').click(function()
	{
		if ( visible_tooltip == null)
		{
			visible_tooltip = $(this).parent().parent().attr("data-id");
			
			$(this).parent().parent().children('.content').animate({"height" : $(this).height()+50}, 400).css("display","block");
			return false;
		}
		
		$("div[data-id="+visible_tooltip+"]").find('.content').animate({"height" : 0}, 400).css("color","transparent");

		visible_tooltip = $(this).parent().parent().attr("data-id");

		$(this).parent().parent().children('.content').animate({"height" : $(this).height()+50}, 400).css({"display":"block","color":"white"});
	});

/*
	AJAX skill update
	$("input[type='button']").click(function() {
		var skill_id = $(this).attr("skill_id");
		var skill_level = $(this).attr("skill_level");
		$.ajax({
			type: "POST",
			url:"models/overview/ajax_skill.php",
  			context: this,
  			dataType:"json",
  			data: {
  				"skill_id" : skill_id,
  				"skill_level" : skill_level
  			},
			error: function(result) {
				console.log(result);
			},
			success:function(result){
				$(this).parent().parent().fadeOut(1000).promise().done(function(){
					var new_row = $(this).after("<tr><td>"+result[0]+"</td><td>"+result[1]+"</td><td>"+result[2]+"</td></tr>");
					$(this).remove();
				});
			}
		});
		return false;
	});
*/
</script>