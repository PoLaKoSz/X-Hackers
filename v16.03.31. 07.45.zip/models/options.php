<?php

class OptionsDB extends DataBase
{
	private $password;
	private $newPassword;

	public function __construct( $password )
	{
		$this->password = $password;
	}

	public function changePassword( $newPassword )
	{
		$this->connect();
			$this->password = $this->escape( $this->password );
			$this->newPassword = $this->escape( $newPassword );

			$result = $this->query("SELECT updatePassword(" . $_SESSION['account_id']. ", '" . $this->password . "', '" . $this->newPassword . "') AS updatePassword")->fetch_assoc();
		
		$this->close();
		return $result['updatePassword'];
	}
}