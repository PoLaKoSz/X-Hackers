<?php

class ClanDB extends DataBase
{
	private $status;

	public function __construct() {}
	
	public function getClanMates()
	{
		$this->connect();
			$result = $this->query(
			"
			SELECT
				clan_members.account_id,
				COALESCE(hacker_name.hacker_name, accounts.username) AS clan_member_name
			FROM clan_members
			LEFT JOIN hacker_name ON clan_members.account_id = hacker_name.acc_id
			LEFT JOIN accounts ON clan_members.account_id = accounts.id
			WHERE clan_id = 
							(
								SELECT
								clan_id
								FROM clan_members
								WHERE account_id = " . $_SESSION['account_id'] . "
							)
			GROUP BY clan_members.account_id
			ORDER BY joined_date ASC, hacker_name.change_date DESC
			");

		$this->close();

		return $result;
	}

	public function getClanInformations()
	{
		$this->connect();
			$result = $this->query(
			"SELECT
				clan_name,clan_start_date
			FROM clans
			WHERE id = 
						(
							SELECT
							clan_id
							FROM clan_members
							WHERE account_id = " . $_SESSION['account_id'] . "
						)
			");

		$this->close();

		return $result;
	}
}