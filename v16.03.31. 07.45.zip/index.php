<?php

	session_start();
	
	//require_once 'sql/generate_database.php';$db = new createDataBase;$db->createAndFillTables("sql/mobile/xHackers.sql");return false;die();

	error_reporting(E_ALL);

	header("Content-Type: text/html; charset=utf-8");
	
	$_SESSION['status'] = 0; $_SESSION['account_id'] = 1; $_SESSION['current_level'] = 2; $_SESSION['current_money'] = 25000; $_SESSION['current_exp'] = 4853;  $_SESSION['full_exp'] = 44948; // mobil miatt
	
	include_once 'models/database.php';				// mint pl. Android-nál az import package
	# csak azért példányosítunk, hogyha nincs szerver, akkor ne töltsön be tovább az oldal
	$db = new DataBase;								// példányosítás, a konstruktor meghívása
	$db->close();									// DB kapcsolat bezárása

	include_once 'core/Functions.php';				// mint pl. Android-nál az import package

	include_once 'core/Controller.php';				// mint pl. Android-nál az import package
	$controller = new Controller;					// példányosítás, a konstruktor meghívása