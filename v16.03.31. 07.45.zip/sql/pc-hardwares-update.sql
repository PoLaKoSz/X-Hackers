CREATE TABLE CPUs (
    cpu_id int  NOT NULL,
    cpu_name varchar(20)  NOT NULL,
    cpu_core int  NOT NULL,
    cpu_thread int  NOT NULL,
    CONSTRAINT CPUs_pk PRIMARY KEY (cpu_id)
);

CREATE TABLE RAMs (
    ram_id int  NOT NULL,
    ram_manufacturer varchar(20)  NOT NULL,
    ram_capacity int  NOT NULL,
    ram_type int  NOT NULL,
    CONSTRAINT RAMs_pk PRIMARY KEY (ram_id)
);

CREATE TABLE VGAs (
    vga_id int  NOT NULL,
    vga_core_speed int  NOT NULL,
    vga_memory_speed int  NOT NULL,
    vga_memory_bus_speed int  NOT NULL,
    vga_memory_type varchar(20)  NOT NULL,
    vga_technology int  NOT NULL,
    CONSTRAINT VGAs_pk PRIMARY KEY (vga_id)
);

CREATE TABLE computer (
    account_id int  NOT NULL,
    computer_id int  NOT NULL
);

CREATE TABLE computer_peaces (
    computer_id int  NOT NULL,
    CPU_id int  NOT NULL,
    VGA_id int  NOT NULL,
    RAM_id int  NOT NULL
);