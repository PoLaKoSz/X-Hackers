<?php

error_reporting(E_ALL);

/*

FELTETELEK          !!!!!
Importalasnak megjegyzesek, timestamp
nelkul kell megtortennie, illetve az INSERT
parancs egy tablanal csak egyszer szere-
pelhet!!!!

ez a file az sql mappaban lesz, es az
index.php-ban lesz meghivva egy
kikommentelt sorban es az ott levo
.sql fajlt darabolja fel \n\n-eknel es igy
adja majd tombbe, illetve query-be
az utasitasokat.
*/

class createDataBase
{
	private $sqlHost = '127.0.0.1';

	private $sqlUserName = 'root';

	private $sqlPassword = '';

	private $sqlDB = 'xHackers';

	private $mysqli;
	
	public $querys;

	public function __construct() {}

	protected function connect()
	{
		$this->mysqli = new mysqli($this->sqlHost, $this->sqlUserName, $this->sqlPassword, $this->sqlDB);
		$this->mysqli->set_charset("utf8mb4");												// kell, hogy ékezetes karaktereket is tudjunk SELECT-elni				

		$this->connectError();
	}

	protected function connectError()
	{
		if ($this->mysqli->connect_error) {
		    exit( require_once 'views/offlineServer.php' );
		}
	}
	
	public function createAndFillTables( $file )
	{
		$res = file_get_contents( $file ) or die("A fájl nem létezik!");

		$this->querys = explode( "\n\n", $res );

		$this->connect();

			for ($i = 0; $i < count($this->querys)-1; $i++)
			{
				$this->mysqli->query( $this->querys[$i] );
			}

		$this->mysqli->close();

		echo "Adatbázis sikeresen feltöltve táblákkal és adatokkal!";
	}

	protected function query( $query_string )
	{	
		return $this->mysqli->query( $query_string ) or die($this->mysqli->error);
	}

	protected function close()
	{
		$this->mysqli->close();
	}
}