$(document).ready(function() {
	var value;
	
	// Minden <input name="username"> fieldet ellenõriz
	$("input[name='username']").blur(function() {
		var value = $(this).val();
			
		if(value.length < 5 || value.length > 20) {
			var hibalista = "A felhasználónévnek min. 5, max. 20 karakter hosszúnak kell lennie!";
		
			$(".error_msg.username").remove();
			$(this).after( "<div id='validate' class='error_msg username'>"+hibalista+"</div>");
		}
	});
	
	// Minden <input name="password"> fieldet ellenõriz
	$("input[name='password']").blur(function() {
		value = $(this).val();
			
		if(value.length < 5 || value.length > 20) {
			var hibalista = "A jelszónak min. 5, max. 20 karakter hosszúnak kell lennie!";
		
			$(".error_msg.password").remove();
			$(this).after( "<div id='validate' class='error_msg password'>"+hibalista+"</div>");
		}
		
		hibalista = "";
	});

	// Minden <input name="email"> fieldet ellenõriz
	$("input[name='email']").blur(function() {
		value = $(this).val();
		var hibalista = "";
		
		if(value.length > 50) {
			hibalista = "Az email címnek max. 50 karakter hosszúnak kell lennie!";
		}
		
		if(value.indexOf('@') === -1 || value.indexOf('.') === -1)
		{
			if(hibalista !== "")
				hibalista += "<br>";
			
			hibalista += "Érvénytelen email cím!";
		}
		
		$("label").parent('div').remove();
		$(this).after( "<div id='validate' class='error_msg email'>"+hibalista+"</div>");
	});
});