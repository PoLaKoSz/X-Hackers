<?php

	require_once 'models/database.php';

class DB_2_SQL_lib extends Database
{
	
}