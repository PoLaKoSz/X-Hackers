<?php

class Registration
{
	private $message;																						//  felhasznalo fele kozvetitett uzenet (error, success)

	private $status;																						//  success / error (milyen típusú üzenetet kell megjelenítenie a view-nak)

	public function __construct ()
	{
		if ( isset( $_POST['registration'] ) )
		{
			if ( $reg = $this->formValidating() )
			{
				include_once 'models/registration.php';														//  felhasználói fiók létének ellenőrzése
				$reg = new RegistrationDB( $_POST['username'], $_POST['password'], $_POST['email']  );

				if ( $result = $reg->checkFreeUserName() == 0 )												//	ha nincs még ilyen nevű felhasználó
				{
					if ( $result = $reg->createUser() )														//	sikeres regisztráció
					{
						header('Location: index.php');
					}
				}
			}

			$this->status = "error_msg";
			$this->message = "Regisztráció sikertelen! Ez a felhasználónév már létezik!";
		}
		require_once 'views/registration.php';																//  továbbirányítás a megfelelő oldalra
	}

	private function formValidating()
	{
		include_once 'helper/formValidating.php';															//  ősosztály betöltése

		include_once 'helper/checkUsername.php';															//  felhasználónév-ellenőrző betöltése
		include_once 'helper/checkPassword.php';															//  jelszóellenőrző betöltése
		include_once 'helper/checkEmail.php';																//  emailellenőrző betöltése

		$userName = new checkUsername( $_POST['username'] );
			$result = $userName->checking();

			if ( !$result )
			{
				return false;
			}

		$password = new checkPassword( $_POST['password'] );
			$result = $password->checking();

			if ( !$result )
			{
				return false;
			}

		$email = new checkEmail( $_POST['email'] );
			$result = $email->checking();

			if ( !$result )
			{
				return false;
			}

		return true;
	}
}