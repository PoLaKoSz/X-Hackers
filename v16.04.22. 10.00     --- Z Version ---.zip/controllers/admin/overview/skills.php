<?php

class Skills
{
	public function __construct()
	{
		require_once 'models/admin/overview/skills.php';
		$db = new SkillsDB;
			if ( isset( $_POST['update'] ) && isset( $_POST['skill_id'] ) && isset( $_POST['skill_level'] ) && isset( $_POST['skill_description'] ) && isset( $_POST['tooltip'] ) )
			{
				$db->updateSkill( $_POST['skill_id'], $_POST['skill_level'], $_POST['skill_description'], $_POST['tooltip'] );
			}
			else if ( isset( $_POST['insert'] ) && isset( $_POST['skill_id'] ) && isset( $_POST['skill_description'] ) && isset( $_POST['tooltip'] ) )
			{
				echo "uj skill_level";
				$db->insertOneSkill( $_POST['skill_id'], $_POST['skill_description'], $_POST['tooltip'] );
			}
		$skill_result = $db->getSkills();
		require_once 'views/admin/overview/skills.php';
	}
}