<h3 class="fLeft">Képességek</h3>
<select class="fRight">
	<option>HTML</option>
	<option>CSS</option>
	<option>JavaScript</option>
	<option>jQuery</option>
</select>

<div class="nice-table">
	<?php
		while ( $row = $skill_result->fetch_assoc() )
		{
			echo '
			<form action="#" method="POST">
				<div id="container" data-id="' . $row['skill_id'] . '">
					<input type="text" hidden name="skill_id" value="' . $row['skill_id'] . '">
					<input type="text" hidden name="skill_level" value="' . $row['skill_level'] . '">


						<div class="m_top_title">
							# ' . $row['SK_next_level'] . '
							<input type="text" disabled name="skill_description" value="' . $row['skill_description'] . '">
						</div>

					<div class="row-1">( <a class="tooltip"> ? </a>) | ' . $row['skill_description'] . '</div>

					<div class="content">
						<input type="text" disabled name="skill_tooltip" value="' . $row['skill_tooltip'] . '">
					</div>

						<div class="m_details">
							<p class="edit">
								<img src="images/edit.png" />
							</p>
							<p class="title">
								<img src="images/open.png" />
							</p>
							<p>
								<input type="button" class="save" name="update" value="" skill_id=' . $row["skill_id"] . ' skill_level=' . $row["skill_level"] . ' skill_tooltip=' . $row["skill_tooltip"] . ' skill_description=' . $row["skill_description"] . '>
							</p>
						</div>
						
					<div class="row-2"><img src="images/' . $row['changing'] . '.png" alt="' . $row['changing'] . '" title="' . $row['changing'] . '">' . $row['changing_value'] . ' # ' . $row['SK_next_level'] . '</div>
				</div>
			</form>
			';
		}
	?>
</div>
<script>
	$("input[type='button'].save").click(function() {
		//alert("Save buttonra ranyomva");
		
		var skill_id = $(this).attr("skill_id");
		var skill_level = $(this).attr("skill_level");
		var skill_tooltip = $(this).attr("skill_tooltip");
		var skill_description = $(this).attr("skill_description");
		
		$.ajax({
			type: "POST",
			url:"controllers/admin/overview/ajax_skill.php",
  			context: this,
  			dataType:"json",
  			data: {
  				"skill_id" : skill_id,
  				"skill_level" : skill_level,
                  "skill_tooltip" : skill_tooltip,
                  "skill_description" : skill_description
  			},
			error:function(result) {
				console.log(result);
				/*$(this).parent().parent().fadeOut(1000).promise().done(function(){
					$(this).css("background-color","red");
				});*/
				alert("nem sikerult");
			},
			success:function(result){
				alert("Sikerult");
				$(this).parent().parent().fadeOut(1000).promise().done(function(){
					var new_row = $(this).after("<tr><td>"+result[0]+"</td><td>"+result[1]+"</td><td>"+result[2]+"</td></tr>");
					$(this).remove();
				});
			}
		});
		return false;
	});
</script>