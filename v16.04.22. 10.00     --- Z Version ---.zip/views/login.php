<html>
	<head>
		<title>X-Hackers</title>
		
		<link rel="stylesheet" type="text/css" href="./css/default_design.css">
		<link rel="stylesheet" type="text/css" href="./css/min_830px_style.css">
		
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />
		
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	</head>
	
	<body>
		<div id="LoginRegPanel" class="full_center">
			<a href="#"><div class="menu_button login active noselect">Belépés</div></a>
			<a href="index.php?url=registration"><div class="menu_button reg noselect">Regisztráció</div></a>
			
			<div class="clear"></div>
			
			<div id="loginTartalom" class="loginBox borderedBox">
				<?php
					if ( $message != null )
					{
						echo '<div class="error_msg">'.$message.'</div>';
					}
				?>
				
				<form method="POST" action="index.php?url=login">
					<label>
						Felhasználónév<br>
						<input type="text" name="username" maxlength="20" value="PoLáKoSz"><br>
					</label>
					<label>
						Jelszó<br>
						<input type="password" name="password" maxlength="20" value="admin"><br>
					</label>

					<label>
						<input type="checkbox" name="safe_login" checked>
						Biztonságos belépés ( <a href="#" alt="10 perc inaktivitás után kidob" title="10 perc inaktivitás után kidob">?</a> )
					</label>
					<br>
					<input type="submit" name="login" value="Belépés">
					<br>
					<br>
					<a href="#">Elfelejtett jelszó?</a>
				</form>
			</div>
		</div>
		
		<script src="./js/jquery-2.2.0.min.js"></script>
		<script src="./js/loginPanel.js"></script>
		<script src="./js/validate.js"></script>
	</body>
</html>