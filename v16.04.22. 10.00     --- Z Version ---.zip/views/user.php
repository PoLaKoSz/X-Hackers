<!--
	vegul is mindent meglehetne adni a
	felhasznalorol, mert ha itt adatot lat,
	az azt jelenti, hogy feltortek ...
	talan a korabbi hackerneveit ne
	lehessen listazni
	
	miket lehessen kilistazni:
		- hackerneve (ha nincs felhasznaloneve)
		- klannev
		- szamitogepalkatreszeit
		- 
--!>
<div id="user" class="clearfix">
	<div>Hackerneve</div>
	<div>Mr. Pola</div>
	<div>Klánja</div>
	<div>Programmers</div>
	<div>Specifikációja</div>
	<div>
			CPU: Intel i5 4833 2,80GHz<br>
			VGA: 3,60GHz<br>
			RAM: 16GB<br>
			Táp: 550kW
	</div>
	<div>Szoftverei</div>
			
</div>