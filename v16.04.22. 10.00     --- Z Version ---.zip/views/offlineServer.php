﻿<title>X-Hackers</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />
<div id="noServer" class="full_center">
A szerver jelenleg nem elérhető!
</div>
<link rel="stylesheet" type="text/css" href="css/noServer.css">