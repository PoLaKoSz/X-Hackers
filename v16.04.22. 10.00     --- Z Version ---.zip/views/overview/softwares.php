<h3>Szoftverek</h3>
<div class="nice-table">
	<?php
		while ( $row = $software_result->fetch_assoc() )
		{
			if ( $_SESSION['current_money'] < $row['price'] )
			{
				$disable = 'disable';
			}

			if ( $row['requirement_software_level'] == -2)
			{
				$imgORUpgrade = "<img src='images/tick.png' class='status'>";
			}
			else
			{
				$imgORUpgrade = '<input type="submit" ' . $disable . ' value="' . formatInt( $row['price'] ) .'Ft">';
			}
			
			echo '
			<form action="index.php?url=overview/softwares" method="POST">
				<div id="container" data-id="' . $row['software_id'] . '">
					<input type="text" hidden name="software_id" value="' . $row['software_id'] . '">
					<div class="m_top_title"><div class="title">' . $row['SK_curr_level'] . ' -> ' . $row['SK_next_level'] . ' | ' . $row['software_description'] . '</div>' . $imgORUpgrade . '</div>
					<div class="row-1">( <a class="tooltip"> ? </a>) | ' . $row['SK_curr_level'] . ' -> ' . $row['SK_next_level'] . ' | ' . $row['software_description'] . '</div>
					<div class="content">' . $row['software_tooltip'] . '</div>
					<div class="m_details"><p>30.000 Ft</p><p>592 EXP</p><p>84 sec</p></div>
					<div class="row-2"><img src="images/' . $row['changing'] . '.png" alt="' . $row['changing'] . '" title="' . $row['changing'] . '">' . $row['changing_value'] . ' ' . $imgORUpgrade . '</div>
				</div>
			</form>
			';
		}
	?>
</div>