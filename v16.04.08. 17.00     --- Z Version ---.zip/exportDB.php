<?php

	require_once 'models/database.php';

class ExportDB extends Database
{
	// Name of the file
	public $filename = 'backup.sql';

	public function __construct()
	{
		$myfile = fopen($this->filename, "w") or die("Unable to open file!");
		fclose($myfile);

		$this->connect();
		$backup_file = $this->sqlDB . date("Y-m-d-H-i-s") . '.gz';

			$this->query("mysqldump --opt -h $this->sqlHost -u $this->sqlUserName -p $this->sqlPassword ". "$this->sqlDB | gzip > $backup_file");
		//$command = "mysqldump --opt -h $this->sqlHost -u $this->sqlUserName -p $this->sqlPassword ". "$this->sqlDB | gzip > $backup_file";

		//system($command);
		echo "siker";
	}
}

$db = new ExportDB;