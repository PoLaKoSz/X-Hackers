<?php

	echo '
		<div id="clan" class="horizontal_center clearfix">
			<div>Klán név:</div>
			<div>' . $this->clanInfo['clan_name'] . '</div>
			<div>Alapítás dátuma:</div>
			<div>' . $this->clanInfo['clan_start_date'] . '</div>
			<div>Tagok</div>
			<div>';
				while ( $row = $this->clanMembers->fetch_assoc() )
				{
					echo '<a href="#"><img src="images/message.png"></a> <a href="index.php?url=user&gamer=' . $row["clan_member_name"] . '">' . $row["clan_member_name"] . '</a><br>';
				}
?>
			</div>
			<a href="#">Kilépés a(z) <?php echo $this->clanInfo['clan_name']; ?> nevű klánból</a>
		</div>