<form action="index.php?url=admin/skill_list" method="POST">
	<table class="horizontal_center">
		<tr>
			<td>skill_id</td>
			<td><input type="text" name="skill_id"></td>

			<td>skill_level</td>
			<td><input type="text" name="skill_level"></td>
		</tr>

			<td>szükséges skill</td>
			<td><input type="text" name="requirement_skill" placeholder="(skill_id)"></td>

			<td>szükséges skill szintje</td>
			<td><input type="text" name="requirement_skill_level"></td>
		</tr>
		<tr>
			<td>bónusz neve</td>
			<td><input type="text" name="changing"></td>

			<td>bónusz értéke</td>
			<td><input type="text" name="changing_value"></td>
		</tr>
		<tr>
			<td>price</td>
			<td><input type="text" name="price"></td>

			<td>order by</td>
			<td><input type="text" name="order_by" placeholder="pl.: skill_table.id ASC"></td>
		</tr>
	</table>
	<input type="submit" name="search" value="Keresés">
</form>

<table class="nice-table content_center">
	<tr>
		<td> </td>
		<td>skill_id</td>
		<td>skill_level</td>
		<td>skill_tooltip</td>
		<td>skill_description</td>
		<td>price</td>
		<td>szükséges skill</td>
		<td>min. skill Lv</td>
		<td>bónusz név</td>
		<td>b. érték</td>
		<td> </td>
	</tr>
<?php
		# ha ranyomunk a modosit gombra, akkor ki kene jonnie alul egy panelnek, ahol csak az adott 1-et lehet modositani, es igy latni lehet a sorrendet
			while ( $row = $result->fetch_assoc() )
			{
				 echo "<tr>
							<td>#" . $row['order'] . "</td>
							<td>" . $row['skill_id'] . "</td>
							<td>" . $row['skill_level'] . "</td>
							<td><input type='text' disabled name='skill_tooltip' value='" . $row['skill_tooltip'] . "'></td>
							<td><input type='text' disabled name='skill_description' value='" . $row['skill_description'] . "'></td>
							<td><input type='number' disabled name='price' value='" . $row['price'] . "'></td>
							<td><input type='number' disabled name='requirement_skill' value='" . $row['requirement_skill'] . "'></td>
							<td><input type='number' disabled name='requirement_skill_level' value='" . $row['requirement_skill_level'] . "'></td>
							<td><input type='text' disabled name='changing' value='" . $row['changing'] . "'></td>
							<td><input type='number' disabled name='changing_value' value='" . $row['changing_value'] . "'></td>
							<td><input type='button' skill_id='" . $row['skill_id'] . "' skill_level='" . $row['skill_level'] . "' value='Módosít'></td>
						</tr>";
			}
?>
</table>

<script>
	$("input[type='button']").click(function() {
		if ( $(this).attr("value") == "Módosít" ) {
			$(this).parent().parent().each(function() {
				$(this).children().each(function() {
					$(this).children().prop("disabled", false);
				});
				
			});
			$(this).prop("value", "Mentés");
		}
		else if ( $(this).attr("value") == "Mentés" ) {
			var skill_id = $(this).attr("skill_id");
			var skill_level = $(this).attr("skill_level");

			$.ajax({
				type: "POST",
				url:"models/admin/ajax_skill.php",
	  			context: this,
	  			dataType:"json",
	  			data: {
	  				"skill_id" : skill_id,
	  				"skill_level" : skill_level
	  			},
				error: function(result) {
					console.log("HIBAAAA");
				},
				success:function(result){
					console.log("sikeres ajax");
					$(this).parent().parent().fadeOut(1000).promise().done(function(){
						console.log("asd");
						var new_row = $(this).after("<tr><td>"+result[0]+"</td><td>"+result[1]+"</td><td>"+result[2]+"</td></tr>");
						$(this).remove();
					});
				}
			});
		}
	});
</script>