<?php

class SoftwaresDB extends DataBase
{
	public function __construct() {}

	public function getSoftwares()
	{
		$this->connect();
			$result = $this->query(
			"
			SELECT
				software_table.software_id,software_table.software_tooltip,software_table.software_description, account_softwares.software_level AS SK_curr_level,software_table.software_level AS SK_next_level, software_table.price,
				software_table.requirement_software_level, software_table.changing, software_table.changing_value
			FROM software_table
			LEFT JOIN account_softwares ON software_table.software_id = account_softwares.software_id AND software_table.software_level = account_softwares.software_level + 1
			LEFT JOIN software_list ON software_table.software_id = software_list.software_id
			WHERE account_softwares.account_id = " . $_SESSION['account_id'] . " OR account_softwares.account_id IS NULL AND software_table.requirement_software <= (SELECT COALESCE(MAX(software_id), 0) FROM account_softwares)
			GROUP BY software_list.order
			");

		$this->close();

		return $result;
	}

	public function getSoftwarePrice( $software_id )
	{
		$this->connect();
		
			$result = $this->query(
			"
			SELECT
				price
			FROM software_table
			LEFT JOIN account_softwares ON software_table.software_id = account_softwares.software_id
			WHERE software_table.software_id = " . $software_id . " AND software_table.software_level = COALESCE(account_softwares.software_level + 1, 1)
			LIMIT 1
			")->fetch_assoc();

		$this->close();

		return $result;
	}

	public function upgradeSoftware( $software_id )
	{
		$this->connect();
			$result = $this->query("CALL updateSoftware(" . $_SESSION['account_id'] . ", " . $software_id . ");");

		$this->close();

		return $result;
	}
}