<?php
	session_start();

	require_once '../database.php';
	require_once 'skills.php';
	$db = new SkillsDB;
	$result = $db->getOneSkill( $_POST['skill_id'], $_POST['skill_level'] )->fetch_array();

	echo json_encode($result);