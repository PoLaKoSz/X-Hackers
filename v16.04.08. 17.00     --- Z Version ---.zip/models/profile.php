<?php

class ProfileDB extends DataBase
{
	protected $hackerName;

	public function __construct( $hackerName )
	{
		$this->connect();
			$this->hackerName = $this->escape( $hackerName );
	}

	public function changeHackerName()
	{
			$this->query("INSERT INTO hacker_name VALUES (" . $_SESSION['account_id'] . ", '" . $this->hackerName . "', NOW())");

		$this->close();
	}
}