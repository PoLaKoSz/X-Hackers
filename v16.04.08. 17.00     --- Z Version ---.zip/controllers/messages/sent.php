<?php

class Sent
{
	public function __construct ()
	{
		$messages = new MessagesDB;
		$result = $messages->getSent();

		require_once 'views/messages/sent.php';								// továbbirányítás a megfelelő oldalra
	}
}