<?php

class OverView
{
	private $clanInfo;

	private $clanMembers;

	public function __construct ()
	{

		if ( $this->checkClan() )
		{
			require_once 'views/clan/list.php';								// továbbirányítás a megfelelő oldalra
		}
		else
		{
			require_once 'views/clan/create.php';								// továbbirányítás a megfelelő oldalra
		}
		
	}
	
	private function checkClan()
	{
		include_once 'models/clan/overview.php';
		$clan = new ClanDB;

		$this->clanMembers = $clan->getClanMates();

		if ( $this->clanMembers->num_rows > 0 )
		{
			$this->clanInfo = $clan->getClanInformations()->fetch_assoc();
			return true;
		}
		else
		{
			return false;
		}
	}
}