<?php

class Admin
{
	public function __construct ()
	{
		require_once 'views/admin/skill_update.php';
	}
}