<?php

class User
{
	protected $gamerName;

	public function __construct()
	{
		if ( isset( $_GET['gamer'] ) )
		{
			$this->gamerName = $_GET['gamer'];
			
		}
		require_once 'views/user.php';
	}
}