-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Hoszt: 127.0.0.1
-- Létrehozás ideje: 2016. Már 19. 14:08
-- Szerver verzió: 5.6.17-log
-- PHP verzió: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Adatbázis: `xhackers`
--
CREATE DATABASE IF NOT EXISTS `xhackers` DEFAULT CHARACTER SET utf8 COLLATE utf8_hungarian_ci;
USE `xhackers`;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `accounts`
--

DROP TABLE IF EXISTS `accounts`;
CREATE TABLE IF NOT EXISTS `accounts` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(30) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `password` varchar(45) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT 'MD5 kódolás',
  `email` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `status` tinyint(3) unsigned NOT NULL COMMENT '0 = aktiválásra várva | 1 = aktív | 2 = bann',
  `current_level` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `current_exp` int(10) unsigned DEFAULT NULL,
  `current_money` mediumint(8) unsigned NOT NULL,
  `computer_id` smallint(5) unsigned DEFAULT NULL COMMENT 'aktiv PC-jenek az ID-je: computers.id kerul ide',
  `reg_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci AUTO_INCREMENT=11 ;

--
-- A tábla adatainak kiíratása `accounts`
--

INSERT INTO `accounts` (`id`, `username`, `password`, `email`, `status`, `current_level`, `current_exp`, `current_money`, `computer_id`, `reg_date`) VALUES
(1, 'PoLáKoSz', '*4ACFE3202A5FF5CF467898FC58AAB1D615029441', 'polakosz@freemail.hu', 1, 2, 3450, 0, NULL, '2016-01-23 00:00:00'),
(2, 'TesztElek', '*4ACFE3202A5FF5CF467898FC58AAB1D615029441', 'polakosz@freemail.hu', 1, 1, 9345, 0, NULL, '2016-03-09 00:00:00'),
(3, 'Exodus', '*4ACFE3202A5FF5CF467898FC58AAB1D615029441', 'asdk', 1, 1, 0, 0, NULL, '2016-03-10 00:00:00'),
(4, 'admin', '*4ACFE3202A5FF5CF467898FC58AAB1D615029441', 'info@xhackers.hu', 0, 1, 0, 0, NULL, '2015-01-01 00:00:00'),
(5, 'karcsi501', '*4ACFE3202A5FF5CF467898FC58AAB1D615029441', 'info@xhackers.hu', 0, 1, 0, 0, NULL, '2015-01-01 00:00:00'),
(6, 'Mikee012', '*4ACFE3202A5FF5CF467898FC58AAB1D615029441', 'info@xhackers.hu', 0, 1, 0, 0, NULL, '2015-01-01 00:00:00'),
(7, 'boldogan', '*4ACFE3202A5FF5CF467898FC58AAB1D615029441', 'info@xhackers.hu', 0, 1, 0, 0, NULL, '2015-01-01 00:00:00'),
(8, 'jovics2012', '*4ACFE3202A5FF5CF467898FC58AAB1D615029441', 'info@xhackers.hu', 0, 1, 0, 0, NULL, '2015-01-01 00:00:00'),
(9, 'dohanyos81', '*4ACFE3202A5FF5CF467898FC58AAB1D615029441', 'info@xhackers.hu', 0, 1, 0, 0, NULL, '2015-01-01 00:00:00'),
(10, 'avermedia', '*4ACFE3202A5FF5CF467898FC58AAB1D615029441', 'info@xhackers.hu', 0, 1, 0, 0, NULL, '2015-01-01 00:00:00');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `account_computers`
--

DROP TABLE IF EXISTS `account_computers`;
CREATE TABLE IF NOT EXISTS `account_computers` (
  `account_id` smallint(5) unsigned NOT NULL,
  `computer_id` smallint(5) unsigned NOT NULL COMMENT 'rakni kell ra UNIQUE dolgot'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `account_languages`
--

DROP TABLE IF EXISTS `account_languages`;
CREATE TABLE IF NOT EXISTS `account_languages` (
  `account_id` smallint(10) unsigned NOT NULL,
  `language_id` tinyint(3) unsigned NOT NULL,
  `language_level` tinyint(3) unsigned NOT NULL,
  `upgraded_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `account_languages`
--

INSERT INTO `account_languages` (`account_id`, `language_id`, `language_level`, `upgraded_date`) VALUES
(1, 1, 8, '2016-03-16'),
(1, 2, 5, '2016-03-16'),
(1, 3, 3, '2016-03-16');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `account_skills`
--

DROP TABLE IF EXISTS `account_skills`;
CREATE TABLE IF NOT EXISTS `account_skills` (
  `account_id` smallint(5) unsigned NOT NULL,
  `skill_id` tinyint(3) unsigned NOT NULL,
  `skill_level` tinyint(3) unsigned NOT NULL,
  `upgraded_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `account_skills`
--

INSERT INTO `account_skills` (`account_id`, `skill_id`, `skill_level`, `upgraded_date`) VALUES
(1, 3, 7, '2016-03-16'),
(1, 5, 9, '2016-03-16'),
(1, 4, 5, '2016-03-16'),
(1, 2, 3, '2014-03-05');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `clans`
--

DROP TABLE IF EXISTS `clans`;
CREATE TABLE IF NOT EXISTS `clans` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `clan_name` varchar(20) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `clan_start_date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci AUTO_INCREMENT=3 ;

--
-- A tábla adatainak kiíratása `clans`
--

INSERT INTO `clans` (`id`, `clan_name`, `clan_start_date`) VALUES
(1, '[Admin]Team', '2016-03-10'),
(2, 'PlayerTeam', '2016-03-10');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `clan_members`
--

DROP TABLE IF EXISTS `clan_members`;
CREATE TABLE IF NOT EXISTS `clan_members` (
  `clan_id` smallint(5) unsigned NOT NULL,
  `account_id` smallint(5) unsigned NOT NULL,
  `joined_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `clan_members`
--

INSERT INTO `clan_members` (`clan_id`, `account_id`, `joined_date`) VALUES
(1, 1, '2016-03-10'),
(2, 2, '2016-03-10'),
(2, 3, '2016-03-10');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `computers`
--

DROP TABLE IF EXISTS `computers`;
CREATE TABLE IF NOT EXISTS `computers` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `vga` tinyint(3) unsigned NOT NULL,
  `vga_level` tinyint(3) unsigned NOT NULL,
  `cpu` tinyint(3) unsigned NOT NULL,
  `cpu_level` tinyint(3) unsigned NOT NULL,
  `ram` tinyint(3) unsigned NOT NULL,
  `ram_level` tinyint(3) unsigned NOT NULL,
  `ssd` tinyint(3) unsigned NOT NULL,
  `ssd_level` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `computer_table`
--

DROP TABLE IF EXISTS `computer_table`;
CREATE TABLE IF NOT EXISTS `computer_table` (
  `hardware_id` tinyint(3) unsigned NOT NULL,
  `hardware_level` tinyint(3) unsigned NOT NULL,
  `changing` varchar(4) COLLATE utf8_hungarian_ci NOT NULL,
  `changing_value` tinyint(3) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `hackers_name`
--

DROP TABLE IF EXISTS `hackers_name`;
CREATE TABLE IF NOT EXISTS `hackers_name` (
  `acc_id` smallint(5) unsigned NOT NULL,
  `hacker_name` varchar(20) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `change_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `hackers_name`
--

INSERT INTO `hackers_name` (`acc_id`, `hacker_name`, `change_date`) VALUES
(1, '[Admin] Mr. PoLáKoSz', '2016-03-10 00:00:00');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `jobs`
--

DROP TABLE IF EXISTS `jobs`;
CREATE TABLE IF NOT EXISTS `jobs` (
  `account_id` smallint(5) unsigned NOT NULL,
  `employer` tinyint(3) unsigned NOT NULL,
  `job_description` tinyint(3) unsigned NOT NULL,
  `exp` smallint(5) unsigned NOT NULL,
  `money` mediumint(8) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `jobs_description`
--

DROP TABLE IF EXISTS `jobs_description`;
CREATE TABLE IF NOT EXISTS `jobs_description` (
  `id` int(3) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(255) COLLATE utf8_bin NOT NULL,
  `require_skill` int(2) unsigned DEFAULT NULL COMMENT 'skill_id kerül ide',
  `require_skill_level` int(2) unsigned DEFAULT NULL COMMENT 'természetesen a skill-nek a szintje kerül ide',
  `require_language` int(2) unsigned DEFAULT NULL COMMENT 'language_id kerül ide',
  `require_language_level` int(2) unsigned DEFAULT NULL COMMENT 'természetesen a language-nek a szintje kerül ide',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=10 ;

--
-- A tábla adatainak kiíratása `jobs_description`
--

INSERT INTO `jobs_description` (`id`, `description`, `require_skill`, `require_skill_level`, `require_language`, `require_language_level`) VALUES
(1, 'Készíts egy szimpla HTML, CSS weblapot!', 2, 6, NULL, NULL),
(2, 'Készíts a cégnek weblapot, ami tartalmaz cikkírás, cikkmódosítás, cikktörlést, az ehhez tartozó adminisztrátori belépés mellé', 1, 3, NULL, NULL),
(3, 'Teszteld, hogy fel lehet-e törni', 3, 2, NULL, NULL),
(4, 'Keress 0-day hibát a cég új alkalmazásában', 3, 2, NULL, NULL),
(5, 'Fordítsd le az oldalt angolra!', NULL, NULL, 1, 5),
(6, 'Fordítsd le az oldalt németre!', NULL, NULL, 2, 5),
(7, 'Készíts C# programot', 7, 5, NULL, NULL),
(8, 'Készíts Android-on egy Hello Word-öt!', 16, 1, NULL, NULL),
(9, 'Lopd el valakinek a személyazonosságát (ugye ez valószínűleg Gray vagy Black). Úgy kéne, hogy "megtalál" valamilyen felhasználót, és betör a nevével valahova.', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `jobs_employer`
--

DROP TABLE IF EXISTS `jobs_employer`;
CREATE TABLE IF NOT EXISTS `jobs_employer` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `employer` varchar(255) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=59 ;

--
-- A tábla adatainak kiíratása `jobs_employer`
--

INSERT INTO `jobs_employer` (`id`, `employer`) VALUES
(1, 'ABAHÁZY Bt. - Fordítóiroda'),
(2, 'Alicehair fodrászat'),
(3, 'Amtech Rendszerház Kft.'),
(4, 'ANDREZOL-NET Kft.'),
(5, 'BalatonQuality Rendezvényszervező Iroda'),
(6, 'Brush Bt.'),
(7, 'Cikloid Kft.'),
(8, 'Cromkontakt Galvánipari Kft.'),
(9, 'Design I Do'),
(10, 'DMA Management Academy'),
(11, 'DomyPack & Press Kft.'),
(12, 'Eladó Lakás Kft.'),
(13, 'Electro-Heating Pro Kft.'),
(14, 'Ezüst Kaméleon Kft.'),
(15, 'Füzéri Vár és Látogatóközpont'),
(16, 'GÁZ-ÁRAM Energia Tanácsadó Kft.'),
(17, 'Gipszpalace Bau Kft.'),
(18, 'Gránátalmalé bolt'),
(19, 'Gyógyforrás Gyógycentrum'),
(20, 'Gyurján Kft.'),
(21, 'Harisnya Outlet Kft.'),
(22, 'Haus Tipp-Topp Bt.'),
(23, 'Ház-Mester 2006 Bt.'),
(24, 'HBOMEDICAL'),
(25, 'Homoktövis webáruház'),
(26, 'Humanum Auxilium'),
(27, 'Hungária Költöztetés'),
(28, 'In-Ga Társasházkezelő Kft.'),
(29, 'KataPorta'),
(30, 'Kati-Szalon'),
(31, 'Kék-Suli Oktatóközpont'),
(32, 'Kispál Sándor bútorasztalos mester'),
(33, 'Kiss József EV'),
(34, 'Kölyökvarázs'),
(35, 'KSKNet Kft.'),
(36, 'Kulcs fordítócsoport - KataPorta'),
(37, 'Lomtalanítás Budapest'),
(38, 'M1 Karosszéria Tata'),
(39, 'Molnár Levente és Társa Bt.'),
(40, 'Novaweb Kft.'),
(41, 'Pan-Gica Design'),
(42, 'Patronos bolt'),
(43, 'Perbit HR Magyarország Kft.'),
(44, 'PiperePatika Kft'),
(45, 'Pova Bt.'),
(46, 'REGIO Játékkereskedelmi Kft.'),
(47, 'RPE Kft.'),
(48, 'Stáb Építőipari Szolgáltató Bt.'),
(49, 'T-Creativ.hu'),
(50, 'Takács Gergely'),
(51, 'Tolcsvai kastély látogatóközpont'),
(52, 'Tóvizi Ferenc'),
(53, 'VILLANYÁRAM Energia Tanácsadó Bt.'),
(54, 'VIP Partners Kft.'),
(55, 'VipIT Group Kft.'),
(56, 'VITAX Bt.'),
(57, 'Xt System Épületgépészeti Kft.'),
(58, 'ZöldZóna Kertépítő, Karbantartó Szolg.');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `jobs_finished`
--

DROP TABLE IF EXISTS `jobs_finished`;
CREATE TABLE IF NOT EXISTS `jobs_finished` (
  `acc_id` smallint(5) unsigned NOT NULL,
  `exp` smallint(5) unsigned NOT NULL,
  `money` mediumint(8) unsigned NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `language_list`
--

DROP TABLE IF EXISTS `language_list`;
CREATE TABLE IF NOT EXISTS `language_list` (
  `order` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `language_id` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`order`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci AUTO_INCREMENT=4 ;

--
-- A tábla adatainak kiíratása `language_list`
--

INSERT INTO `language_list` (`order`, `language_id`) VALUES
(1, 1),
(2, 2),
(3, 3);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `language_table`
--

DROP TABLE IF EXISTS `language_table`;
CREATE TABLE IF NOT EXISTS `language_table` (
  `language_id` tinyint(3) unsigned NOT NULL,
  `language_level` tinyint(3) unsigned NOT NULL COMMENT 'Jelen pillanatban, ha az érték 11, akkor fullos ez a skill!!',
  `language_description` varchar(255) COLLATE utf8_hungarian_ci NOT NULL,
  `price` tinyint(3) unsigned NOT NULL COMMENT 'Ft',
  `requirement_skill` tinyint(3) unsigned DEFAULT NULL COMMENT 'skill_id-t kell megadni, 0 = nem szükséges hozzá követelmény (= requirement_skill_level-nek is 0-nak kell lennie)',
  `requirement_skill_level` tinyint(3) unsigned DEFAULT NULL,
  `changing` varchar(4) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL COMMENT 'EXP - TIME - OFFense - DEFFense',
  `changing_value` tinyint(3) unsigned DEFAULT NULL COMMENT 'időnél pl mínusz érték, mert csökken a feladat teljesítésének ideje'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `language_table`
--

INSERT INTO `language_table` (`language_id`, `language_level`, `language_description`, `price`, `requirement_skill`, `requirement_skill_level`, `changing`, `changing_value`) VALUES
(1, 1, 'Angol ---- ', 10, 0, 0, 'TIME', 0),
(1, 2, 'Angol ---- ', 20, 1, 1, 'TIME', 0),
(1, 3, 'Angol ---- ', 255, 1, 2, 'TIME', 0),
(1, 3, 'Angol ---- ', 255, 1, 3, 'TIME', 0),
(1, 5, 'Angol ---- ', 255, 1, 4, 'TIME', 0),
(1, 6, 'Angol ---- ', 255, 1, 5, 'TIME', 0),
(1, 7, 'Angol ---- ', 255, 1, 6, 'TIME', 0),
(1, 8, 'Angol ---- ', 255, 1, 7, 'TIME', 0),
(1, 9, 'Angol ---- ', 255, 1, 8, 'TIME', 0),
(1, 10, 'Angol ---- ', 255, 1, 9, 'TIME', 0),
(1, 11, 'Angol --- ', 0, 0, 0, '', 0),
(2, 1, 'Német --- ', 12, 1, 1, 'TIME', 0),
(2, 2, 'Német --- ', 123, 2, 1, 'TIME', 0),
(2, 3, 'Német --- ', 255, 2, 2, 'TIME', 0),
(2, 4, 'Német --- ', 255, 2, 3, 'TIME', 0),
(2, 5, 'Német --- ', 255, 2, 4, 'TIME', 0),
(2, 6, 'Német --- ', 255, 2, 5, 'TIME', 0),
(2, 7, 'Német --- ', 255, 2, 6, 'TIME', 0),
(2, 8, 'Német --- ', 255, 2, 7, 'TIME', 0),
(2, 9, 'Német --- ', 255, 2, 8, 'TIME', 0),
(2, 10, 'Német --- ', 255, 2, 9, 'TIME', 0),
(2, 11, 'Német --- ', 0, 0, 0, '', 0),
(3, 1, 'Orosz --- ', 12, 1, 1, 'TIME', 0),
(3, 2, 'Orosz --- ', 123, 3, 1, 'TIME', 0),
(3, 3, 'Orosz --- ', 255, 3, 2, 'TIME', 0),
(3, 4, 'Orosz --- ', 255, 3, 3, 'TIME', 0),
(3, 5, 'Orosz --- ', 255, 3, 4, 'TIME', 0),
(3, 6, 'Orosz --- ', 255, 3, 5, 'TIME', 0),
(3, 7, 'Orosz --- ', 255, 3, 6, 'TIME', 0),
(3, 8, 'Orosz --- ', 255, 3, 7, 'TIME', 0),
(3, 9, 'Orosz --- ', 255, 3, 8, 'TIME', 0),
(3, 10, 'Orosz --- ', 255, 3, 9, 'TIME', 0),
(3, 11, 'Orosz --- ', 0, 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `levels`
--

DROP TABLE IF EXISTS `levels`;
CREATE TABLE IF NOT EXISTS `levels` (
  `level` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `exp` mediumint(8) unsigned NOT NULL COMMENT 'Következő szint eléréséhez szükséges EXP-t mutatja               |               round(abs(8559/51+11-2-(93-52)-93/92/79+(36)+95/97+83/1747-31+30/15-(3/12)-7*671-36/99*1004-20/4961+(3652)) * 9.4591836734694 * $i)',
  PRIMARY KEY (`level`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci AUTO_INCREMENT=1001 ;

--
-- A tábla adatainak kiíratása `levels`
--

INSERT INTO `levels` (`level`, `exp`) VALUES
(1, 11980),
(2, 23960),
(3, 35940),
(4, 47921),
(5, 59901),
(6, 71881),
(7, 83861),
(8, 95841),
(9, 107821),
(10, 119801),
(11, 131781),
(12, 143762),
(13, 155742),
(14, 167722),
(15, 179702),
(16, 191682),
(17, 203662),
(18, 215642),
(19, 227622),
(20, 239603);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `messages`
--

DROP TABLE IF EXISTS `messages`;
CREATE TABLE IF NOT EXISTS `messages` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `msg_to` varchar(50) COLLATE utf8_hungarian_ci NOT NULL COMMENT 'account_id',
  `msg_from` varchar(50) COLLATE utf8_hungarian_ci NOT NULL COMMENT 'account_id',
  `message` varchar(255) COLLATE utf8_hungarian_ci NOT NULL,
  `date` datetime NOT NULL,
  `seen` tinyint(1) unsigned DEFAULT NULL COMMENT '0 = nem látta, 1 = látta',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `news`
--

DROP TABLE IF EXISTS `news`;
CREATE TABLE IF NOT EXISTS `news` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `text` varchar(255) COLLATE utf8_hungarian_ci NOT NULL,
  `date` datetime NOT NULL,
  `publish` tinyint(1) NOT NULL COMMENT 'rejtett, vagy nem rejtett',
  `author` int(10) unsigned NOT NULL COMMENT 'hacker_name-hez tartozó ID kerül ide',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci AUTO_INCREMENT=3 ;

--
-- A tábla adatainak kiíratása `news`
--

INSERT INTO `news` (`id`, `text`, `date`, `publish`, `author`) VALUES
(1, 'Hablablabla', '2016-03-19 00:00:00', 1, 1),
(2, 'sfsgdfgdsfg', '2016-01-19 13:50:12', 1, 1);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `skill_list`
--

DROP TABLE IF EXISTS `skill_list`;
CREATE TABLE IF NOT EXISTS `skill_list` (
  `order` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `skill_id` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`order`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci AUTO_INCREMENT=19 ;

--
-- A tábla adatainak kiíratása `skill_list`
--

INSERT INTO `skill_list` (`order`, `skill_id`) VALUES
(2, 2),
(3, 3),
(4, 4),
(5, 15),
(6, 5),
(7, 6),
(8, 14),
(9, 7),
(10, 8),
(11, 9),
(12, 10),
(13, 11),
(14, 12),
(15, 13),
(18, 16);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `skill_table`
--

DROP TABLE IF EXISTS `skill_table`;
CREATE TABLE IF NOT EXISTS `skill_table` (
  `skill_id` tinyint(3) unsigned NOT NULL,
  `skill_level` tinyint(3) unsigned NOT NULL COMMENT 'Jelen pillanatban, ha az érték 11, akkor fullos ez a skill!!',
  `skill_tooltip` varchar(2500) COLLATE utf8_hungarian_ci NOT NULL COMMENT 'Ez jelenik meg a ( ? ) jelnél',
  `skill_description` varchar(255) COLLATE utf8_hungarian_ci NOT NULL,
  `price` mediumint(8) unsigned NOT NULL COMMENT 'Ft',
  `requirement_skill` tinyint(3) unsigned NOT NULL COMMENT 'skill_id-t kell megadni, 0 = nem szükséges hozzá követelmény (= requirement_skill_level-nek is 0-nak kell lennie)',
  `requirement_skill_level` tinyint(3) unsigned NOT NULL,
  `changing` varchar(4) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL COMMENT 'EXP - TIME - OFFense - DEFFense',
  `changing_value` tinyint(3) unsigned NOT NULL COMMENT 'időnél pl mínusz érték, mert csökken a feladat teljesítésének ideje'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `skill_table`
--

INSERT INTO `skill_table` (`skill_id`, `skill_level`, `skill_tooltip`, `skill_description`, `price`, `requirement_skill`, `requirement_skill_level`, `changing`, `changing_value`) VALUES
(2, 1, '', 'HTML --- ', 10, 0, 0, 'TIME', 0),
(2, 2, '', 'HTML --- ', 20, 0, 0, 'TIME', 0),
(2, 3, '', 'HTML --- ', 342, 0, 0, 'TIME', 0),
(2, 4, '', 'HTML --- ', 43543, 0, 0, 'TIME', 0),
(2, 5, '', 'HTML --- ', 256456, 0, 0, 'TIME', 0),
(2, 6, '', 'HTML --- ', 2456555, 0, 0, 'TIME', 0),
(2, 7, '', 'HTML --- ', 16777215, 0, 0, 'TIME', 0),
(2, 8, '', 'HTML --- ', 16777215, 0, 0, 'TIME', 0),
(2, 9, '', 'HTML --- ', 16777215, 0, 0, 'TIME', 0),
(2, 10, '', 'HTML --- ', 16777215, 0, 0, 'TIME', 0),
(2, 11, '', 'HTML --- ', 0, 0, 0, '', 0),
(3, 1, '', 'CSS --- ', 12, 0, 0, 'EXP', 0),
(3, 2, '', 'CSS --- ', 123, 0, 0, 'EXP', 1),
(3, 3, '', 'CSS --- ', 1234, 0, 0, 'EXP', 2),
(3, 4, '', 'CSS --- ', 13455, 0, 0, 'EXP', 3),
(3, 5, '', 'CSS --- ', 3425, 0, 0, 'EXP', 4),
(3, 6, '', 'CSS --- ', 2345, 0, 0, 'EXP', 5),
(3, 7, '', 'CSS --- ', 16777215, 0, 0, 'EXP', 6),
(3, 8, '', 'CSS --- ', 16777215, 0, 0, 'EXP', 7),
(3, 9, '', 'CSS --- ', 16777215, 0, 0, 'EXP', 8),
(3, 10, '', 'CSS --- ', 16777215, 0, 0, 'EXP', 9),
(3, 11, '', 'CSS --- ', 0, 0, 0, '', 0),
(4, 1, '', 'JavaScript --- ', 12, 0, 0, 'EXP', 0),
(4, 2, '', 'JavaScript --- ', 123, 0, 0, 'EXP', 1),
(4, 3, '', 'JavaScript --- ', 1234, 0, 0, 'EXP', 2),
(4, 4, '', 'JavaScript --- ', 13455, 0, 0, 'EXP', 3),
(4, 5, '', 'JavaScript --- ', 3425, 0, 0, 'EXP', 4),
(4, 6, '', 'JavaScript --- ', 2345, 0, 0, 'EXP', 5),
(4, 7, '', 'JavaScript --- ', 16777215, 0, 0, 'EXP', 6),
(4, 8, '', 'JavaScript --- ', 16777215, 0, 0, 'EXP', 7),
(4, 9, '', 'JavaScript --- ', 16777215, 0, 0, 'EXP', 8),
(4, 10, '', 'JavaScript --- ', 16777215, 0, 0, 'EXP', 9),
(4, 11, '', 'JavaScript --- ', 0, 0, 0, '', 0),
(5, 1, '', 'PHP --- ', 12, 0, 0, 'EXP', 0),
(5, 2, '', 'PHP --- ', 123, 0, 0, 'EXP', 1),
(5, 3, '', 'PHP --- ', 1234, 0, 0, 'EXP', 2),
(5, 4, '', 'PHP --- ', 13455, 0, 0, 'EXP', 3),
(5, 5, '', 'PHP --- ', 3425, 0, 0, 'EXP', 4),
(5, 6, '', 'PHP --- ', 2345, 0, 0, 'EXP', 5),
(5, 7, '', 'PHP --- ', 16777215, 0, 0, 'EXP', 6),
(5, 8, '', 'PHP --- ', 16777215, 0, 0, 'EXP', 7),
(5, 9, '', 'PHP --- ', 16777215, 0, 0, 'EXP', 8),
(5, 10, '', 'PHP --- ', 16777215, 0, 0, 'EXP', 9),
(5, 11, '', 'PHP --- ', 0, 0, 0, '', 0),
(6, 1, '', 'SQL --- ', 12, 0, 0, 'EXP', 0),
(6, 2, '', 'SQL --- ', 123, 0, 0, 'EXP', 1),
(6, 3, '', 'SQL --- ', 1234, 0, 0, 'EXP', 2),
(6, 5, '', 'SQL --- ', 13455, 0, 0, 'EXP', 3),
(6, 5, '', 'SQL --- ', 3425, 0, 0, 'EXP', 4),
(6, 6, '', 'SQL --- ', 2345, 0, 0, 'EXP', 5),
(6, 7, '', 'SQL --- ', 16777215, 0, 0, 'EXP', 6),
(6, 8, '', 'SQL --- ', 16777215, 0, 0, 'EXP', 7),
(6, 9, '', 'SQL --- ', 16777215, 0, 0, 'EXP', 8),
(6, 10, '', 'SQL --- ', 16777215, 0, 0, 'EXP', 9),
(6, 11, '', 'SQL --- ', 0, 0, 0, '', 0),
(7, 1, '', 'C# --- ', 12, 0, 0, 'TIME', 0),
(7, 2, '', 'C# --- ', 123, 0, 0, 'TIME', 0),
(7, 3, '', 'C# --- ', 1234, 0, 0, 'TIME', 0),
(7, 5, '', 'C# --- ', 13455, 0, 0, 'TIME', 0),
(7, 5, '', 'C# --- ', 3425, 0, 0, 'TIME', 0),
(7, 6, '', 'C# --- ', 2345, 0, 0, 'TIME', 0),
(7, 7, '', 'C# --- ', 16777215, 0, 0, 'TIME', 0),
(7, 8, '', 'C# --- ', 16777215, 0, 0, 'TIME', 0),
(7, 9, '', 'C# --- ', 16777215, 0, 0, 'TIME', 0),
(7, 10, '', 'C# --- ', 16777215, 0, 0, 'TIME', 0),
(7, 11, '', 'C# --- ', 0, 0, 0, 'TIME', 0),
(8, 1, '', 'Java --- ', 12, 0, 0, 'EXP', 0),
(8, 2, '', 'Java --- ', 123, 0, 0, 'EXP', 1),
(8, 3, '', 'Java --- ', 1234, 0, 0, 'EXP', 2),
(8, 5, '', 'Java --- ', 13455, 0, 0, 'EXP', 3),
(8, 5, '', 'Java --- ', 3425, 0, 0, 'EXP', 4),
(8, 6, '', 'Java --- ', 2345, 0, 0, 'EXP', 5),
(8, 7, '', 'Java --- ', 16777215, 0, 0, 'EXP', 6),
(8, 8, '', 'Java --- ', 16777215, 0, 0, 'EXP', 7),
(8, 9, '', 'Java --- ', 16777215, 0, 0, 'EXP', 8),
(8, 10, '', 'Java --- ', 16777215, 0, 0, 'EXP', 9),
(8, 11, '', 'Java --- ', 0, 0, 0, '', 0),
(9, 1, '', 'Assembly --- ', 12, 0, 0, 'EXP', 0),
(9, 2, '', 'Assembly --- ', 123, 0, 0, 'EXP', 1),
(9, 3, '', 'Assembly --- ', 1234, 0, 0, 'EXP', 2),
(9, 5, '', 'Assembly --- ', 13455, 0, 0, 'EXP', 3),
(9, 5, '', 'Assembly --- ', 3425, 0, 0, 'EXP', 4),
(9, 6, '', 'Assembly --- ', 2345, 0, 0, 'EXP', 5),
(9, 7, '', 'Assembly --- ', 16777215, 0, 0, 'EXP', 6),
(9, 8, '', 'Assembly --- ', 16777215, 0, 0, 'EXP', 7),
(9, 9, '', 'Assembly --- ', 16777215, 0, 0, 'EXP', 8),
(9, 10, '', 'Assembly --- ', 16777215, 0, 0, 'EXP', 9),
(9, 11, '', 'Assembly --- ', 0, 0, 0, '', 0),
(10, 1, '', '2-es számrendszer --- ', 12, 0, 0, 'EXP', 0),
(10, 2, '', '2-es számrendszer --- ', 123, 0, 0, 'EXP', 1),
(10, 3, '', '2-es számrendszer --- ', 1234, 0, 0, 'EXP', 2),
(10, 5, '', '2-es számrendszer --- ', 13455, 0, 0, 'EXP', 3),
(10, 5, '', '2-es számrendszer --- ', 3425, 0, 0, 'EXP', 4),
(10, 6, '', '2-es számrendszer --- ', 2345, 0, 0, 'EXP', 5),
(10, 7, '', '2-es számrendszer --- ', 16777215, 0, 0, 'EXP', 6),
(10, 8, '', '2-es számrendszer --- ', 16777215, 0, 0, 'EXP', 7),
(10, 9, '', '2-es számrendszer --- ', 16777215, 0, 0, 'EXP', 8),
(10, 10, '', '2-es számrendszer --- ', 16777215, 0, 0, 'EXP', 9),
(10, 11, '', '2-es számrendszer --- ', 0, 0, 0, '', 0),
(11, 1, '', '16-os számrendszer --- ', 12, 0, 0, 'EXP', 0),
(11, 2, '', '16-os számrendszer --- ', 123, 0, 0, 'EXP', 1),
(11, 3, '', '16-os számrendszer --- ', 1234, 0, 0, 'EXP', 2),
(11, 5, '', '16-os számrendszer --- ', 13455, 0, 0, 'EXP', 3),
(11, 5, '', '16-os számrendszer --- ', 3425, 0, 0, 'EXP', 4),
(11, 6, '', '16-os számrendszer --- ', 2345, 0, 0, 'EXP', 5),
(11, 7, '', '16-os számrendszer --- ', 16777215, 0, 0, 'EXP', 6),
(11, 8, '', '16-os számrendszer --- ', 16777215, 0, 0, 'EXP', 7),
(11, 9, '', '16-os számrendszer --- ', 16777215, 0, 0, 'EXP', 8),
(11, 10, '', '16-os számrendszer --- ', 16777215, 0, 0, 'EXP', 9),
(11, 11, '', '16-os számrendszer --- ', 0, 0, 0, '', 0),
(12, 1, '', 'PowerShell --- ', 12, 0, 0, 'EXP', 0),
(12, 2, '', 'PowerShell --- ', 123, 0, 0, 'EXP', 1),
(12, 3, '', 'PowerShell --- ', 1234, 0, 0, 'EXP', 2),
(12, 5, '', 'PowerShell --- ', 13455, 0, 0, 'EXP', 3),
(12, 5, '', 'PowerShell --- ', 3425, 0, 0, 'EXP', 4),
(12, 6, '', 'PowerShell --- ', 2345, 0, 0, 'EXP', 5),
(12, 7, '', 'PowerShell --- ', 16777215, 0, 0, 'EXP', 6),
(12, 8, '', 'PowerShell --- ', 16777215, 0, 0, 'EXP', 7),
(12, 9, '', 'PowerShell --- ', 16777215, 0, 0, 'EXP', 8),
(12, 10, '', 'PowerShell --- ', 16777215, 0, 0, 'EXP', 9),
(12, 11, '', 'PowerShell --- ', 0, 0, 0, '', 0),
(13, 1, '', 'Python --- ', 12, 0, 0, 'EXP', 0),
(13, 2, '', 'Python --- ', 123, 0, 0, 'EXP', 1),
(13, 3, '', 'Python --- ', 1234, 0, 0, 'EXP', 2),
(13, 5, '', 'Python --- ', 13455, 0, 0, 'EXP', 3),
(13, 5, '', 'Python --- ', 3425, 0, 0, 'EXP', 4),
(13, 6, '', 'Python --- ', 2345, 0, 0, 'EXP', 5),
(13, 7, '', 'Python --- ', 16777215, 0, 0, 'EXP', 6),
(13, 8, '', 'Python --- ', 16777215, 0, 0, 'EXP', 7),
(13, 9, '', 'Python --- ', 16777215, 0, 0, 'EXP', 8),
(13, 10, '', 'Python --- ', 16777215, 0, 0, 'EXP', 9),
(13, 11, '', 'Python --- ', 0, 0, 0, '', 0),
(14, 1, '', 'Ajax --- ', 12, 0, 0, 'EXP', 0),
(14, 2, '', 'Ajax --- ', 123, 0, 0, 'EXP', 1),
(14, 3, '', 'Ajax --- ', 1234, 0, 0, 'EXP', 2),
(14, 5, '', 'Ajax --- ', 13455, 0, 0, 'EXP', 3),
(14, 5, '', 'Ajax --- ', 3425, 0, 0, 'EXP', 4),
(14, 6, '', 'Ajax --- ', 2345, 0, 0, 'EXP', 5),
(14, 7, '', 'Ajax --- ', 16777215, 0, 0, 'EXP', 6),
(14, 8, '', 'Ajax --- ', 16777215, 0, 0, 'EXP', 7),
(14, 9, '', 'Ajax --- ', 16777215, 0, 0, 'EXP', 8),
(14, 10, '', 'Ajax --- ', 16777215, 0, 0, 'EXP', 9),
(14, 11, '', 'Ajax --- ', 0, 0, 0, '', 0),
(15, 1, '', 'jQuery --- ', 12, 0, 0, 'EXP', 0),
(15, 2, '', 'jQuery --- ', 123, 0, 0, 'EXP', 1),
(15, 3, '', 'jQuery --- ', 1234, 0, 0, 'EXP', 2),
(15, 5, '', 'jQuery --- ', 13455, 0, 0, 'EXP', 3),
(15, 5, '', 'jQuery --- ', 3425, 0, 0, 'EXP', 4),
(15, 6, '', 'jQuery --- ', 2345, 0, 0, 'EXP', 5),
(15, 7, '', 'jQuery --- ', 16777215, 0, 0, 'EXP', 6),
(15, 8, '', 'jQuery --- ', 16777215, 0, 0, 'EXP', 7),
(15, 9, '', 'jQuery --- ', 16777215, 0, 0, 'EXP', 8),
(15, 10, '', 'jQuery --- ', 16777215, 0, 0, 'EXP', 9),
(15, 11, '', 'jQuery --- ', 0, 0, 0, '', 0),
(16, 1, '', 'Android --- ', 12, 0, 0, 'EXP', 0),
(16, 2, '', 'Android --- ', 123, 0, 0, 'EXP', 1),
(16, 3, '', 'Android --- ', 1234, 0, 0, 'EXP', 2),
(16, 5, '', 'Android --- ', 13455, 0, 0, 'EXP', 3),
(16, 5, '', 'Android --- ', 3425, 0, 0, 'EXP', 4),
(16, 6, '', 'Android --- ', 2345, 0, 0, 'EXP', 5),
(16, 7, '', 'Android --- ', 16777215, 0, 0, 'EXP', 6),
(16, 8, '', 'Android --- ', 16777215, 0, 0, 'EXP', 7),
(16, 9, '', 'Android --- ', 16777215, 0, 0, 'EXP', 8),
(16, 10, '', 'Android --- ', 16777215, 0, 0, 'EXP', 9),
(16, 11, '', 'Android --- ', 0, 0, 0, '', 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
