tamadas (es persze vedekezes) sikeresseg szamolasa
	osszeadni az osszes kulonbozo
		OFFensive skilleket tamadonal
	osszeadni az osszes kulonbozo
		DEFFensivel skilleket vedekezonel
	szazalekot szamolni a ket ertekbol
	egy VALODI randommal 0-100 kozott
		kell generalni egy szamot
	ha a % nagyobb, mint a random, akkor
		sikeres tamadas

munka, kuldetes, sikeres tamadas, sikeres vedekezes EXP szamitas
	osszeadni a kulonbozo EXP-t ado skilleket, languages-eket
	legyen mondjuk 500 az alap EXP
	500 + EXP bon * level = vegleges EXP



								KÜLDETÉSEK LISTÁJA


account_skill-ből kiszedi az elérhető képességeket/nyelveket a munkákhoz
	jobs_description-ból kiszedni a skill_id-nél <= ÉS 0 >  és skill_level-nél <= ÉS 0 > sorokat
		SELECT
			jobs_description.description,
			(
				SELECT employer FROM jobs_employer ORDER BY RAND() LIMIT 1
			) AS employer
		FROM skill_table
		LEFT JOIN account_skills ON skill_table.skill_id = account_skills.skill_id AND skill_table.skill_level = account_skills.skill_level
		CROSS JOIN jobs_description
		CROSS JOIN jobs_employer
		WHERE account_skills.account_id = 1 AND jobs_description.require_skill IS NOT NULL AND skill_table.skill_id >= jobs_description.require_skill AND skill_table.skill_level >= jobs_description.require_skill_level
		GROUP BY jobs_description.description

------------------------------------------------------------------------------------------------------------------------------------



account_languages-ből kiszedi az elérhető képességeket/nyelveket a munkákhoz
		jobs_description-ból kiszedni a language_id-nél <= ÉS 0 >  és language_level-nél <= ÉS 0 > sorokat


SELECT
	jobs_description.description AS munka_feladata,
	(
		SELECT employer FROM jobs_employer ORDER BY RAND() LIMIT 1
	) AS employer
FROM language_table
LEFT JOIN account_languages ON language_table.language_id = account_languages.language_id AND language_table.language_level = account_languages.language_level
CROSS JOIN jobs_description
CROSS JOIN jobs_employer
WHERE account_languages.account_id = 1 AND jobs_description.require_language IS NOT NULL AND language_table.language_level >= jobs_description.require_language_level
GROUP BY jobs_description.description