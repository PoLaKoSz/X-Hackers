<table id="messages" class="nice-table">
		<tr>
			<td>&nbsp;</td>
			<td>Címzett</td>
			<td>Üzenet</td>
			<td>Dátum</td>
		</tr>
		<?php
			while ( $row = $result->fetch_assoc() ) {
				if ( $row['msg_from'] == null )					//	ha nincs hackernév megadva
				{
					$row['msg_from'] = $row['username'];		//	a felhasználóneve lesz megadva
				}
				echo '
					<tr>
						<td><input type="checkbox"></td>
						<td>' . $row['msg_from'] . '</td>
						<td>' . $row['message'] . '</td>
						<td>' . $row['date'] . '</td>
					</tr>
				';
			}
		?>
</table>
<br>
<a href="#">Mind kijelölése</a> - 
<a href="#">Kijelölt(ek) törlése</a>