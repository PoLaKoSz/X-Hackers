<?php
/*
      ugy kene megcsinalni, hogy csak olyan kuldik legyenek itt, amik az account_skill-ben is benne van(nak)

      lista betöltése account_id-vel megjelölve egy ideiglenes táblába, és amint újratölti az oldalt, törli az előzőt, illetve belerakja az újat
*/
?>
<form action="#" method="POST">
	<table class="nice-table">
		<tr>
			<td>Munkaadó</td>
			<td>Leírás</td>
			<td>EXP</td>
			<td>Pénz</td>
			<td>Folyamat hossza</td>
			<td> </td>
		</tr>
		<tr>
			<td>Munkaadó</td>
			<td>Leírás</td>
			<td>EXP</td>
			<td>Pénz</td>
			<td>Folyamat hossza</td>
			<td><input type="button" name="ID_JÖN_IDE"></button></td>
		</tr>
	</table>
</form>