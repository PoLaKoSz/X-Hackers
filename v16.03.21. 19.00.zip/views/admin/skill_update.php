<form action="index.php?url=admin/skill_update" method="POST">
	<table class="nice-table">
		<tr>
			<td>Szkill ID</td>
			<td>Szikll Szint</td>
			<td>Szkill Buborék</td>
			<td>Szkill Leírás</td>
			<td>Szükséges Szkill</td>
			<td>Szükséges Szkill Szint</td>
		</tr>
		<tr>
			<td>1</td>
			<td>1</td>
			<td><textarea name="skill_tooltipp"></textarea></td>
			<td><textarea name="skill_description"></textarea></td>
			<td><input type="number" name="requirement_skill"></td>
			<td><input type="number" name="requirement_skill_level"></td>
		</tr>
	</table>
	<input type="submit" name="update_1_row" value="Frissítés">
</form>