<ul>
	<a href="index.php?url=admin/skill_list"><li>Skill lista</li></a>
</ul>