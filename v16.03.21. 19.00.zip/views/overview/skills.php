<form action="index.php?url=skills">
	<table class="nice-table">
		<tr>
			<td>Képesség neve</td>
			<td> </td>
			<td> </td>
			<td> </td>
			<td>Fejleszt</td>
		</tr>
		<?php
			while ( $row = $skill_result->fetch_assoc() )
			{
				$imgORUpgrade = ( $row['skill_level'] == 11) ?  "<img src='images/tick.png'>" : '<input type="button" disabled skill_id = "' . $row['skill_id'] . '" skill_level = "' . $row['skill_level'] . '" value="' . formatInt($row['price']) .'Ft">';
				echo '<tr>
					<td>(<a href="#" title="asdasd">?</a>) ' . $row['skill_description'] . '</td>
					<td>' . ( $row['skill_level'] - 1 ) . ' -> #' . $row['skill_level'] . '</td>
					<td><img src="images/' . $row['changing'] . '.png" alt="' . $row['changing'] . '" title="' . $row['changing'] . '">' . $row['changing_value'] . '</td>
					<td>REQ_SKILL: ' . $row['requirement_skill'] . ' ---- REQ_SK_LEVEL' . $row['requirement_skill_level'] . '</td>
					<td>' . $imgORUpgrade . '</td>
				</tr>';
			}
		?>
	</table>
	<br>
	<table class="nice-table">
		<tr>
			<td>Nyelv neve</td>
			<td></td>
			<td>Fejleszt</td>
		</tr>
		<?php
			while ( $row = $languages_result->fetch_assoc() )
			{
				$imgORUpgrade = ( $row['language_level'] == 11) ?  "<img src='images/tick.png'>" : '<input type="button" name="' . $row['language_id'] . '" value="' . formatInt($row['price']) .'Ft">';
				echo '<tr name="akjfghhdfg">
					<td>' . $row['language_description'] . '</td>
					<td>' . ( $row['language_level'] - 1 ) . ' -> #' . $row['language_level'] . '</td>
					<td>' . $imgORUpgrade . '</td>
				</tr>';
			}
		?>
	</table>
</form>

<script>
	$("input[type='button']").click(function() {
		var skill_id = $(this).attr("skill_id");
		var skill_level = $(this).attr("skill_level");
		$.ajax({
			type: "POST",
			url:"models/overview/ajax_skill.php",
  			context: this,
  			dataType:"json",
  			data: {
  				"skill_id" : skill_id,
  				"skill_level" : skill_level
  			},
			error: function(result) {
				console.log(result);
			},
			success:function(result){
				$(this).parent().parent().fadeOut(1000).promise().done(function(){
					var new_row = $(this).after("<tr><td>"+result[0]+"</td><td>"+result[1]+"</td><td>"+result[2]+"</td></tr>");
					$(this).remove();
				});
			}
		});
		return false;
	});

	function showPopUp(element) {
		document.getElementById(element).style.display = 'block';
	}

	function closePopUp(element) {
		document.getElementById(element).style.display = 'none';
	}
</script>