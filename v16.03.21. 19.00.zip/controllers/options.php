<?php

class Options
{
	public function __construct()
	{
		require_once 'models/options.php';

		if ( isset( $_POST['changePassword'] ) )
		{
			$db = new OptionsDB();

			if ( $db->validateCurrentPassword( $_POST['curr_PW'] ) == 1 )
			{
				if ( $result = $db->changePassword( $_POST['newPW1'] ) )
				{
					$message = "Sikeres jelszóváltoztatás!";
				}
				else
				{
					$message = "Hibásan megadott jelenlegi jelszó!";
				}
			}
			else
			{
				$message = "Hibásan megadott jelenlegi jelszó!";
			}
		}
		else if ( isset( $_POST['account_holiday'] ) )
		{
			echo "fiók felfüggesztése";
		}
		else if ( isset( $_POST['account_delete'] ) )
		{
			echo "fiók törlése";
		}

		require_once 'views/options.php';
	}
}