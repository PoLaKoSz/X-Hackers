<?php

class Skills
{
	public function __construct ()
	{
		include_once 'models/overview/skills.php';
		$skills = new SkillsDB;
		$skill_result = $skills->getSkills();

		$languages_result = $skills->getLanguages();

		require_once 'views/overview/skills.php';								// továbbirányítás a megfelelő oldalra
	}
}