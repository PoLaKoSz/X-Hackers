<?php

class PC_Softwares
{
	public function __construct ()
	{
		require_once 'views/overview/pc_softwares.php';								// továbbirányítás a megfelelő oldalra
	}
}