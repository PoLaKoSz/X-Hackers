<?php

class Login
{
	public function __construct ()
	{
		if ( isset( $_POST['login'] ) )
		{
			if ( $this->checkLogin() )
			{
				require_once 'views/fix/menu.php';
				require_once 'views/home.php';									// továbbirányítás a kezdőlapra
				require_once 'views/fix/footer.php';
				return false;
			}
			$message = "Hibás felhasználónév vagy jelszó!";
		}
		require_once 'views/login.php';											// továbbirányítás a belépésre
	}

	private function checkLogin()
	{
		require_once 'helper/formValidating.php';								// hogy a szarmaztatott osztalyok mukodjenek
		
		require_once 'helper/checkUsername.php';
		if ( !$username = new checkUsername( $_POST['username'] ) )
		{
			return false;
		}

		require_once 'helper/checkPassword.php';
        if ( !$password = new checkPassword( $_POST['password'] ) )
		{
			return false;
		}

		require_once 'models/login.php';
		$login = new LoginDB( $_POST['username'], $_POST['password'] );
		
		if ( $login->logIn() )
		{
			$_SESSION['account_id'] = $login->account_id;
			$_SESSION['current_level'] = $login->current_level;
			$_SESSION['current_exp'] = $login->current_exp;
			$_SESSION['full_exp'] = $login->full_exp;
			$_SESSION['current_money'] = $login->current_money;
			$_SESSION['status'] = $login->status;
			$_SESSION['computer_id'] = $login->computer_id;

			$_SESSION['sum_EXP_bon'] = $login->sum_EXP_bon;
			$_SESSION['sum_TIME_bon'] = $login->sum_TIME_bon;
			return true;
		}
		else
		{
			return false;
		}
	}
}