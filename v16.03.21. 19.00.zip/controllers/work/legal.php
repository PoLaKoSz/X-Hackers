<?php

class Legal
{
	public function __construct ()
	{
		require_once 'models/work/legal.php';
		$db = new LegalDB();

		require_once 'views/work/legal.php';
	}
}