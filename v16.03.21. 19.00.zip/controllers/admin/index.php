<?php

class Index
{
	public function __construct ()
	{
		require_once 'views/admin/index.php';								// továbbirányítás a megfelelő oldalra
		
	}
}