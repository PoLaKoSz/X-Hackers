$(document).ready(function() {
	$("#LoginRegPanel").fadeIn(1000);
});
