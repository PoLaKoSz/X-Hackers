<?php

class OptionsDB extends DataBase
{
	public $current_password;
	
	public $new_password;
	
	public function validateCurrentPassword( $current_password )
	{
		$this->connect();

			$this->current_password = $this->escape( $current_password );

			$result = $this->query("SELECT id FROM accounts WHERE id = 1 AND password LIKE PASSWORD('" . $this->current_password ."') LIMIT 1")->num_rows;

		$this->close();
		
		return $result;
	}
	
	public function changePassword( $new_password )
	{
		$this->connect();

			$this->new_password = $this->escape( $new_password );

			$result = $this->query("UPDATE accounts SET password = PASSWORD('" . $this->new_password . "') WHERE id = " . $_SESSION['account_id'] . " LIMIT 1");

		$this->close();
		
		return $result;
	}
}