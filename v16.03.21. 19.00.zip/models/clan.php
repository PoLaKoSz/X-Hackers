<?php

class ClanDB extends DataBase
{
	private $status;

	public function __construct() {}
	
	public function getClanMates()
	{
		$this->connect();
			# Klán áttekintése, minden klán-tag kilistázása a nevével együtt (van, akinek nincs hacker neve, annak null-t ad vissza!!!)
			$result = $this->query(
			"SELECT
				clan_members.account_id,
			    accounts.username,
			    hackers_name.hacker_name
			FROM clan_members
			LEFT JOIN hackers_name ON clan_members.account_id = hackers_name.acc_id
			LEFT JOIN accounts ON clan_members.account_id = accounts.id
			WHERE clan_id = 
							(
								SELECT
								clan_id
								FROM clan_members
								WHERE account_id = " . $_SESSION['account_id'] . "
							)
			ORDER BY joined_date ASC");

		$this->close();

		return $result;
	}

	public function getClanInformations()
	{
		$this->connect();
			$result = $this->query(
			"SELECT
				clan_name,clan_start_date
			FROM clans
			WHERE id = 
						(
							SELECT
							clan_id
							FROM clan_members
							WHERE account_id = " . $_SESSION['account_id'] . "
						)
			");

		$this->close();

		return $result;
	}
}


