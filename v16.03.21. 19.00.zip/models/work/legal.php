<?php

class LegalDB extends DataBase
{
	public function __construct() {}

	public function getAvailableJobs()
	{
		$this->connet();

			$this->query("
			SELECT
				account_skills.account_id,
				account_skills.skill_id, account_skills.skill_level,
				skill_table.skill_description, skill_table.price,
				skill_table.skill_id, skill_table.skill_level
			FROM skill_table
			LEFT JOIN account_skills ON skill_table.skill_id = account_skills.skill_id AND skill_table.skill_level = account_skills.skill_level
			WHERE account_skills.account_id = " . $_SESSION['account_id'] . "
			");

		$this->close();
	}
}