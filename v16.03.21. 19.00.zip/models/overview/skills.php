<?php

class SkillsDB extends DataBase
{
	public function __construct() {}

	public function getSkills()
	{
		$this->connect();
			/*

					SKILL_ID-T KELL FOLYAMATOSAN VÁLTOZTATNI, ÉS NEM EGY KAPCSOLÓTÁBLÁVAL KELL A SORRENDET BEÁLLÍTANI, ÍGY JÓ LESZ A REQUIREMENT_SKILL <= AZ ACCOUNT LEGNAGYOBB SKILL_ID-JE
			SELECT
				account_skills.skill_id, account_skills.skill_level,
				skill_table.skill_id,skill_table.skill_description, skill_table.skill_level, skill_table.price,
				skill_table.requirement_skill, skill_table.requirement_skill_level
			FROM skill_table
			LEFT JOIN account_skills ON skill_table.skill_id = account_skills.skill_id AND skill_table.skill_level = account_skills.skill_level
			LEFT JOIN skill_list ON skill_table.skill_id = skill_list.skill_id
			WHERE
				account_skills.account_id = 1 OR account_skills.account_id IS NULL
				AND skill_table.requirement_skill <= ( (SELECT MAX(skill_id) FROM account_skills) -1 )
			GROUP BY skill_list.order

			*/
			$result = $this->query(
			"
			SELECT
				skill_table.skill_id,skill_table.skill_description, skill_table.skill_level, skill_table.price,
				skill_table.requirement_skill, skill_table.requirement_skill_level, skill_table.changing, skill_table.changing_value
			FROM skill_table
			LEFT JOIN account_skills ON skill_table.skill_id = account_skills.skill_id AND skill_table.skill_level = account_skills.skill_level
			LEFT JOIN skill_list ON skill_table.skill_id = skill_list.skill_id
			WHERE account_skills.account_id = " . $_SESSION['account_id'] . " OR account_skills.account_id IS NULL
			GROUP BY skill_list.order
			");

		$this->close();

		return $result;
	}
	
	public function getOneSkill( $skill_id, $skill_level )
	{
		$this->connect();

			$skill_id = $this->escape( $skill_id );
			$skill_level = $this->escape( $skill_level );

			$result = $this->query(
			"
			SELECT
				skill_table.skill_id,skill_table.skill_description, skill_table.skill_level, skill_table.price
			FROM skill_table
			LEFT JOIN account_skills ON skill_table.skill_id = account_skills.skill_id AND skill_table.skill_level = account_skills.skill_level
			WHERE account_skills.account_id = " . $_SESSION['account_id'] . " AND skill_table.skill_id = " . $skill_id . " AND skill_table.skill_level = " . $skill_level . " LIMIT 1
			");

		$this->close();

		return $result;
	}

	public function getLanguages()
	{
		$this->connect();
		
			$result = $this->query(
			"
			SELECT
				account_languages.language_id, language_table.language_description, account_languages.language_level, language_table.price
			FROM language_table
			LEFT JOIN account_languages ON language_table.language_id = account_languages.language_id AND language_table.language_level = account_languages.language_level
			LEFT JOIN language_list ON language_table.language_id = language_list.language_id
			WHERE account_languages.account_id = " . $_SESSION['account_id'] . " OR account_languages.account_id IS NULL
			GROUP BY language_list.order
			");

		$this->close();

		return $result;
	}
}