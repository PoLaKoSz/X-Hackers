<?php

class Controller
{
	private $controller;

	public function __construct()
	{
		$this->chooseControllerFile( $_GET['url'] );								// megfelelo kontroller betoltese

		require_once 'controllers/' . $this->controller . '.php';					//  Controller betöltése

		if ( $this->controller === 'login' || $this->controller === 'registration')
		{
			$this->controller = new $this->controller;								//  Controller meghívása
		}
		else
		{
			include_once 'models/messages.php';										//	későbbi beérkező üzenet jelzéséhez

			require_once 'views/fix/menu.php';										//  oldal keretjének betöltése
			$url = $this->parseUrl();												//  URL szétszedése darabokra: pl.: index.php?url=contact/phone
			$url[ count( $url )  - 1 ] = new $url[ count( $url ) - 1 ];												//  Controller meghívása
			require_once 'views/fix/footer.php';									//  oldal keretjének betöltése
		}
	}

	private function chooseControllerFile( $url )
	{
		if ( !checkLoggedIn() && $url !== "registration" )
		{
			//echo "kilepve, es nem regisztracio<br>";
			$this->controller = 'login';
		}
		else if ( !file_exists( 'controllers/' . $url . '.php' ) || !file_exists( 'views/' . $url . '.php' ) )
		{
			//echo "nem letezik a controller &/ view<br>";
			$this->controller = 'home';
		}
		else if ( checkLoggedIn() && $url === "registration" || $url === "login" )
		{
			//echo "belépve, de regisztralni, vagy belepni szeretne<br>";
			$this->controller = 'home';
		}
		else
		{
			//echo "van controller + view";
			$this->controller = $url;
		}
	}

	private function parseUrl()
	{
		if ( isset( $_GET['url'] ) )
		{
			return $url = explode('/', filter_var(rtrim($_GET['url'], '/'), FILTER_SANITIZE_URL));  //  URL szetszedese
		}
	}
}