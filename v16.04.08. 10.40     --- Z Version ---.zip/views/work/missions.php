<div class="nice-table">
	<?php
		while ( $row = $mission_result->fetch_assoc() )
		{
			echo '
			<form action="index.php?url=overview/languages" method="POST">
				<div id="container" data-id="' . $row['language_id'] . '">
					<input type="text" hidden name="language_id" value="' . $row['language_id'] . '">
					<div class="m_top_title"><div class="title">' . $row['SK_curr_level'] . ' -> ' . $row['SK_next_level'] . ' | ' . $row['language_description'] . '</div>' . $imgORUpgrade . '</div>
					<div class="row-1">( <a class="tooltip"> ? </a>) | ' . $row['SK_curr_level'] . ' -> ' . $row['SK_next_level'] . ' | ' . $row['language_description'] . '</div>
					<div class="content">TOOLTIP</div>
					<div class="m_details"><p>30.000 Ft</p><p>592 EXP</p><p>84 sec</p></div>
					<div class="row-2"><img src="images/' . $row['changing'] . '.png" alt="' . $row['changing'] . '" title="' . $row['changing'] . '">' . $row['changing_value'] . ' ' . $imgORUpgrade . '</div>
				</div>
			</form>
			';
		}
	?>
</div>

<script>
	var width = $(window).width();
	var visible_tooltip;

	$(window).resize(function(){width = $(window).width();});

	$('.nice-table .tooltip').click(function()
	{
		if ( visible_tooltip == null)
		{
			$(this).parent().parent().find('.content').css("display","block");

			visible_tooltip = $(this).parent().parent().attr("data-id");

			return false;
		}

		$("div[data-id="+visible_tooltip+"]").find('.content').css("display","none");

		visible_tooltip = $(this).parent().parent().attr("data-id");

		$(this).parent().parent().find('.content').css("display","block");
	});

	$('.nice-table .content').click(function()
	{
		if ( width >= 830)
		{
			$(this).css("display","none");
		}
	});

	$('.nice-table .title').click(function()
	{
		if ( visible_tooltip == null)
		{
			visible_tooltip = $(this).parent().parent().attr("data-id");
			
			$(this).parent().parent().children('.content').animate({"height" : $(this).height()+50}, 400).css("display","block");
			return false;
		}
		
		$("div[data-id="+visible_tooltip+"]").find('.content').animate({"height" : 0}, 400).css("color","transparent");

		visible_tooltip = $(this).parent().parent().attr("data-id");

		$(this).parent().parent().children('.content').animate({"height" : $(this).height()+50}, 400).css({"display":"block","color":"white"});
	});
</script>