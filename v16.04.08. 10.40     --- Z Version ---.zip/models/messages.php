<?php

class MessagesDB extends DataBase
{
	public function __construct() {}

	public function getNew()
	{
		$this->connect();
		
			$result = $this->query(
			"
			SELECT
				hacker_name.hacker_name AS msg_from,
				accounts.username,
				messages.message, messages.date
			FROM messages
			LEFT JOIN hacker_name ON messages.msg_from = hacker_name.acc_id
			LEFT JOIN accounts ON messages.msg_From = accounts.id
			WHERE msg_to = " . $_SESSION['account_id'] . " AND seen = 0
			LIMIT 1
			")->num_rows;

		$this->close();

		return $result;
	}

	public function getReceived()
	{
		$this->connect();
		
			$result = $this->query(
			"
			SELECT
				accounts.username AS msg_from,
				messages.message, messages.date,messages.seen
			FROM messages
			LEFT JOIN accounts ON messages.msg_From = accounts.id
			WHERE msg_to = " . $_SESSION['account_id'] . "
			ORDER BY messages.date DESC
			");

		$this->close();

		return $result;
	}

	public function getSent()
	{
		$this->connect();
		
			$result = $this->query(
			"
			SELECT
				hacker_name.hacker_name AS msg_from,
				accounts.username,
				messages.message, messages.date,messages.seen
			FROM messages
			LEFT JOIN hacker_name ON messages.msg_from = hacker_name.acc_id
			LEFT JOIN accounts ON messages.msg_From = accounts.id
			WHERE msg_from = " . $_SESSION['account_id'] . "
			ORDER BY messages.date DESC
			");

		$this->close();

		return $result;
	}

	public function sendMessage( $msg_to, $message )
	{
		$this->connect();
		
			$result = $this->query(
			"
			INSERT INTO messages VALUES
			('', '" . $msg_to . "', " . $_SESSION['account_id'] . ", '" . $message . "', NOW(), '')
			");

		$this->close();
	}
}