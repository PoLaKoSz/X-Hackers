<?php

class DataBase
{
	protected $sqlHost = '127.0.0.1';

	protected $sqlUserName = 'root';

	protected $sqlPassword = '';

	protected $sqlDB = 'xHackers';

	private $mysqli;

	public function __construct()
	{
		// ez igazából csak a fő index.php-hoz kell, hogy leellenőrizzük, van egyáltalán adatbázis kapcsolat
		$this->connect();
	}

	public function connect()
	{
		$this->mysqli = new mysqli($this->sqlHost, $this->sqlUserName, $this->sqlPassword, $this->sqlDB);
		$this->mysqli->set_charset("utf8mb4");												// kell, hogy ékezetes karaktereket is tudjunk SELECT-elni				

		$this->connectError();
	}

	protected function connectError()
	{
		if ($this->mysqli->connect_error) {
		    exit( require_once 'views/offlineServer.php' );
		}
	}

	protected function query( $query_string )
	{	
		return $this->mysqli->query( $query_string );
	}

	public function close()
	{
		$this->mysqli->close();
	}
	
	protected function escape( $string )
	{
		return $this->mysqli->real_escape_string( $string );
	}

	protected function createBackUpTable( $tableName )
	{
		$result = $this->query("CREATE TABLE " . $tableName . "___" . date("Y_m_d__G_i_s") . " AS (SELECT * FROM " . $tableName . ")");
	}
}