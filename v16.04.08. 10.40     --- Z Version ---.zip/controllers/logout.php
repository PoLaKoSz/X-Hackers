<?php

class Logout
{
	public function __construct()
	{
		// remove all session variables
		session_unset(); 

		// destroy the session 
		session_destroy(); 
		
		header('Location: index.php');
	}
}