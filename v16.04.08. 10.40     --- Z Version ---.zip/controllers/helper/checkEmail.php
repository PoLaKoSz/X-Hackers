<?php

class checkEmail extends FormValidating
{
	public function __construct( $string )
	{
		$this->string = $string;
		$this->min =10;
		$this->max = 50;
	}

	public function checking()
	{
		if ( !$this->checkLength() )
		{
			return false;
		}
		if ( !filter_var($this->string, FILTER_VALIDATE_EMAIL ) )
		{
			return false;
		}
		return true;
	}
}