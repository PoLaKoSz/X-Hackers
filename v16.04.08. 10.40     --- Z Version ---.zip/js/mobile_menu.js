var w = window.innerWidth;
if(w < 830) {	
	var doc = document.body;
	var menuList = document.getElementById("menuList");

		function hideShowMenu(object) {
			if(menuList.style.display !== 'block' && object == "mobile-menu") {
				menuList.style.display = 'block';
			}
			else if(menuList.style.display === 'block' && object == "menuList") {}
			else
			{
				menuList.style.display = 'none';
			}
		}

		function controlMenu(evt) {
			var id = evt.target.id;
			
			if((id) !== "menuList") {
				hideShowMenu(id);
			}
			else {
				hideShowMenu(id);
			}
		}

	doc.addEventListener("click", controlMenu, false);
}